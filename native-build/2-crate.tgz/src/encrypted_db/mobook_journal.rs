//! Disabled native journal candidate. SQLCipher connection is owned by upstream.
//! Not exported through FRB. No schema changes without explicit initialize().
use super::{EncryptedDb, StorageUpdates};
use rusqlite::{params, OptionalExtension};

#[derive(Clone, PartialEq, Eq)]
pub(crate) struct Owner {
    pub account: String,
    pub device: String,
    pub generation: i64,
}
#[derive(Clone)]
pub(crate) struct Record {
    pub group: Vec<u8>,
    pub id: String,
    pub request_digest: Vec<u8>,
    pub epoch: i64,
    pub position: i64,
    pub policy: String,
    pub payload: Vec<u8>,
}
impl Drop for Record {
    fn drop(&mut self) {use zeroize::Zeroize;self.payload.zeroize();self.request_digest.zeroize();}
}
#[derive(Clone, Copy)]
pub(crate) enum Direction { Outbox, Inbox }
impl Direction {
    fn table(self)-> &'static str {match self {Self::Outbox=>"mobook_outbox_v1",Self::Inbox=>"mobook_inbox_v1"}}
}
fn valid_owner(o:&Owner)->bool {
    [&o.account,&o.device].iter().all(|s| !s.is_empty() && s.len()<=256 && s.trim()==s.as_str()) && (1..=9007199254740990).contains(&o.generation)
}
fn valid(r:&Record)->bool {
    !r.group.is_empty() && r.group.len()<=256 && (16..=128).contains(&r.id.len()) && r.id.bytes().all(|b|b.is_ascii_alphanumeric()||b==b'_'||b==b'-') && r.request_digest.len()==32 && r.epoch>=0 && r.position>=0 && !r.policy.is_empty() && r.policy.len()<=256 && !r.payload.is_empty() && r.payload.len()<=131072
}
fn owner_check(conn:&rusqlite::Connection,o:&Owner)->Result<(), &'static str> {
    if !valid_owner(o) {return Err("journal-owner-invalid");}
    let stored:Option<(String,String,i64,i64)>=conn.query_row("SELECT account,device,generation,version FROM mobook_journal_owner WHERE singleton=1",[],|r|Ok((r.get(0)?,r.get(1)?,r.get(2)?,r.get(3)?))).optional().map_err(|_|"journal-schema-unavailable")?;
    match stored {Some((a,d,g,1)) if a==o.account && d==o.device && g==o.generation=>Ok(()),_=>Err("journal-owner-mismatch")}
}
impl EncryptedDb {
    pub(crate) fn mobook_initialize(&self, owner:&Owner)->Result<(), &'static str> {
        if !valid_owner(owner) {return Err("journal-owner-invalid");}
        let conn=self.conn.lock().map_err(|_|"journal-lock")?;
        let tx=conn.unchecked_transaction().map_err(|_|"journal-begin")?;
        tx.execute_batch("CREATE TABLE IF NOT EXISTS mobook_journal_owner(singleton INTEGER PRIMARY KEY CHECK(singleton=1),version INTEGER NOT NULL,account TEXT NOT NULL,device TEXT NOT NULL,generation INTEGER NOT NULL);
          CREATE TABLE IF NOT EXISTS mobook_outbox_v1(group_id BLOB NOT NULL,operation_id TEXT NOT NULL,request_digest BLOB NOT NULL,epoch INTEGER NOT NULL,position INTEGER NOT NULL,policy TEXT NOT NULL,payload BLOB NOT NULL,receipt BLOB,PRIMARY KEY(group_id,operation_id));
          CREATE TABLE IF NOT EXISTS mobook_inbox_v1(group_id BLOB NOT NULL,operation_id TEXT NOT NULL,request_digest BLOB NOT NULL,epoch INTEGER NOT NULL,position INTEGER NOT NULL,policy TEXT NOT NULL,payload BLOB NOT NULL,receipt BLOB,PRIMARY KEY(group_id,operation_id));").map_err(|_|"journal-migration")?;
        tx.execute("INSERT OR IGNORE INTO mobook_journal_owner(singleton,version,account,device,generation) VALUES(1,1,?1,?2,?3)",params![owner.account,owner.device,owner.generation]).map_err(|_|"journal-migration")?;
        owner_check(&tx,owner)?;
        tx.commit().map_err(|_|"journal-commit")
    }
    pub(crate) fn mobook_lookup(&self,owner:&Owner,direction:Direction,request:&Record)->Result<Option<Record>, &'static str> {
        if !valid(request) {return Err("journal-request-invalid");}
        let conn=self.conn.lock().map_err(|_|"journal-lock")?;owner_check(&conn,owner)?;
        let sql=format!("SELECT request_digest,epoch,position,policy,payload FROM {} WHERE group_id=?1 AND operation_id=?2",direction.table());
        let old:Option<Record>=conn.query_row(&sql,params![request.group,request.id],|r|Ok(Record{group:request.group.clone(),id:request.id.clone(),request_digest:r.get(0)?,epoch:r.get(1)?,position:r.get(2)?,policy:r.get(3)?,payload:r.get(4)?})).optional().map_err(|_|"journal-read")?;
        if let Some(ref r)=old {if !valid(r)||r.request_digest!=request.request_digest||r.epoch!=request.epoch||r.position!=request.position||r.policy!=request.policy {return Err("journal-request-conflict");}}
        Ok(old)
    }
    /// Caller MUST hold the upstream group-operation lock from lookup through
    /// MLS computation to this commit. Duplicate insert is an error, not replace.
    pub(crate) fn mobook_atomic_commit(&self,owner:&Owner,direction:Direction,r:&Record,updates:StorageUpdates)->Result<(), &'static str> {
        if !valid(r) {return Err("journal-request-invalid");}
        let conn=self.conn.lock().map_err(|_|"journal-lock")?;
        let tx=conn.unchecked_transaction().map_err(|_|"journal-begin")?;owner_check(&tx,owner)?;
        Self::apply_updates(&tx,&updates,Some(&r.group)).map_err(|_|"journal-snapshot-write")?;
        let sql=format!("INSERT INTO {}(group_id,operation_id,request_digest,epoch,position,policy,payload) VALUES(?1,?2,?3,?4,?5,?6,?7)",direction.table());
        tx.execute(&sql,params![r.group,r.id,r.request_digest,r.epoch,r.position,r.policy,r.payload]).map_err(|_|"journal-insert-conflict")?;
        #[cfg(test)]
        if std::env::var("MOBOOK_V1_CRASH").as_deref()==Ok("before") {std::process::exit(81);}
        tx.commit().map_err(|_|"journal-commit")?;
        #[cfg(test)]
        if std::env::var("MOBOOK_V1_CRASH").as_deref()==Ok("after") {std::process::exit(82);}
        Ok(())
    }
    /// Snapshot-only atomic write (e.g. merging a staged commit). When `discard`
    /// is given, that UNRECEIPTED outbox row is deleted in the same transaction.
    pub(crate) fn mobook_atomic_snapshot(&self,owner:&Owner,group:&[u8],updates:StorageUpdates,discard:Option<&Record>)->Result<(), &'static str> {
        if group.is_empty()||group.len()>256 {return Err("journal-group-invalid");}
        let conn=self.conn.lock().map_err(|_|"journal-lock")?;
        let tx=conn.unchecked_transaction().map_err(|_|"journal-begin")?;owner_check(&tx,owner)?;
        Self::apply_updates(&tx,&updates,Some(group)).map_err(|_|"journal-snapshot-write")?;
        if let Some(r)=discard {
            if !valid(r)||r.group!=group {return Err("journal-request-invalid");}
            let n=tx.execute("DELETE FROM mobook_outbox_v1 WHERE group_id=?1 AND operation_id=?2 AND request_digest=?3 AND receipt IS NULL",params![r.group,r.id,r.request_digest]).map_err(|_|"journal-discard")?;
            if n!=1 {return Err("journal-discard-conflict");}
        }
        tx.commit().map_err(|_|"journal-commit")
    }
    /// Metadata-only recovery list. Does not submit or decrypt anything.
    pub(crate) fn mobook_pending(&self,owner:&Owner,group:&[u8],after:Option<&str>,limit:u32)->Result<Vec<String>, &'static str> {
        if group.is_empty()||group.len()>256||!(1..=100).contains(&limit)||after.is_some_and(|v|v.len()>128) {return Err("journal-page-invalid");}
        let conn=self.conn.lock().map_err(|_|"journal-lock")?;owner_check(&conn,owner)?;
        let mut stmt=conn.prepare("SELECT operation_id FROM mobook_outbox_v1 WHERE group_id=?1 AND receipt IS NULL AND operation_id>?2 ORDER BY operation_id LIMIT ?3").map_err(|_|"journal-read")?;
        let rows=stmt.query_map(params![group,after.unwrap_or(""),limit],|row|row.get(0)).map_err(|_|"journal-read")?;
        rows.collect::<Result<Vec<String>,_>>().map_err(|_|"journal-read")
    }
    /// The engine must verify receipt identity, ciphertext digest and ordered
    /// acceptance before calling this. This method only provides durable CAS.
    pub(crate) fn mobook_record_receipt(&self,owner:&Owner,r:&Record,receipt:&[u8])->Result<(), &'static str> {
        if !valid(r)||receipt.is_empty()||receipt.len()>8192 {return Err("journal-receipt-invalid");}
        let conn=self.conn.lock().map_err(|_|"journal-lock")?;
        let tx=conn.unchecked_transaction().map_err(|_|"journal-begin")?;owner_check(&tx,owner)?;
        let stored:(Vec<u8>,Vec<u8>,Option<Vec<u8>>,i64,i64,String)=tx.query_row("SELECT request_digest,payload,receipt,epoch,position,policy FROM mobook_outbox_v1 WHERE group_id=?1 AND operation_id=?2",params![r.group,r.id],|row|Ok((row.get(0)?,row.get(1)?,row.get(2)?,row.get(3)?,row.get(4)?,row.get(5)?))).map_err(|_|"journal-receipt-missing")?;
        if stored.0!=r.request_digest||stored.1!=r.payload||stored.3!=r.epoch||stored.4!=r.position||stored.5!=r.policy||stored.2.as_deref().is_some_and(|old|old!=receipt) {return Err("journal-receipt-conflict");}
        tx.execute("UPDATE mobook_outbox_v1 SET receipt=?3 WHERE group_id=?1 AND operation_id=?2",params![r.group,r.id,receipt]).map_err(|_|"journal-receipt-write")?;
        tx.commit().map_err(|_|"journal-commit")
    }
    /// Locally purge one group and its journals atomically. Does not revoke a
    /// remote device, destroy its wrapping key or erase a peer's copied history.
    pub(crate) fn mobook_purge_group(&self,owner:&Owner,group:&[u8])->Result<(), &'static str> {
        if group.is_empty()||group.len()>256 {return Err("journal-group-invalid");}
        let conn=self.conn.lock().map_err(|_|"journal-lock")?;
        let tx=conn.unchecked_transaction().map_err(|_|"journal-begin")?;owner_check(&tx,owner)?;
        for table in ["mobook_outbox_v1","mobook_inbox_v1","mls_storage"] {
            tx.execute(&format!("DELETE FROM {table} WHERE group_id=?1"),params![group]).map_err(|_|"journal-purge")?;
        }
        tx.commit().map_err(|_|"journal-commit")
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use futures::executor::block_on;
    fn setup()->(EncryptedDb,Owner,Record) {
        let db=block_on(EncryptedDb::open(":memory:".into(),vec![0x5a;32])).unwrap();
        let o=Owner{account:"account".into(),device:"device".into(),generation:1};db.mobook_initialize(&o).unwrap();
        let r=Record{group:b"group".to_vec(),id:"operation_12345678".into(),request_digest:vec![2;32],epoch:1,position:2,policy:"p1".into(),payload:vec![7;64]};(db,o,r)
    }
    fn updates(value:u8)->StorageUpdates {StorageUpdates{upserts:vec![(b"MessageSecrets-fixture".to_vec(),vec![value])],deletes:vec![]}}
    #[test] fn mobook_v1_scope_and_version_fail_closed() {
        let (db,o,r)=setup();db.mobook_initialize(&o).unwrap();let mut other=o.clone();other.generation=2;
        assert!(db.mobook_initialize(&other).is_err());assert!(db.mobook_lookup(&other,Direction::Outbox,&r).is_err());
        db.conn.lock().unwrap().execute("UPDATE mobook_journal_owner SET version=2",[]).unwrap();assert!(db.mobook_initialize(&o).is_err());
    }
    #[test] fn mobook_v1_duplicate_insert_rolls_back_snapshot() {
        let (db,o,r)=setup();db.mobook_atomic_commit(&o,Direction::Outbox,&r,updates(1)).unwrap();
        assert!(db.mobook_atomic_commit(&o,Direction::Outbox,&r,updates(2)).is_err());
        assert_eq!(block_on(db.load_for_group(&r.group)).unwrap()[0].1,vec![1]);
        assert_eq!(db.mobook_lookup(&o,Direction::Outbox,&r).unwrap().unwrap().payload,r.payload);
        let mut conflict=r.clone();conflict.request_digest[0]=3;assert!(db.mobook_lookup(&o,Direction::Outbox,&conflict).is_err());
    }
    #[test] fn mobook_v1_receipt_cas_and_direction_isolation() {
        let (db,o,r)=setup();assert!(db.mobook_record_receipt(&o,&r,b"receipt").is_err());
        db.mobook_atomic_commit(&o,Direction::Outbox,&r,updates(1)).unwrap();
        assert!(db.mobook_lookup(&o,Direction::Inbox,&r).unwrap().is_none());
        db.mobook_record_receipt(&o,&r,b"receipt").unwrap();db.mobook_record_receipt(&o,&r,b"receipt").unwrap();
        assert!(db.mobook_record_receipt(&o,&r,b"changed").is_err());
    }
    #[test] fn mobook_v1_purge_keeps_other_group_and_global_keys() {
        let (db,o,r)=setup();db.mobook_atomic_commit(&o,Direction::Outbox,&r,updates(1)).unwrap();
        db.mobook_atomic_commit(&o,Direction::Inbox,&r,StorageUpdates{upserts:vec![],deletes:vec![]}).unwrap();
        let mut other=r.clone();other.group=b"other".to_vec();db.mobook_atomic_commit(&o,Direction::Outbox,&other,StorageUpdates{upserts:vec![(b"Tree-other".to_vec(),vec![5]),(b"SignatureKeyPair-fixture".to_vec(),vec![6])],deletes:vec![]}).unwrap();
        db.mobook_purge_group(&o,&r.group).unwrap();
        assert!(db.mobook_lookup(&o,Direction::Outbox,&r).unwrap().is_none());assert!(db.mobook_lookup(&o,Direction::Inbox,&r).unwrap().is_none());
        assert!(db.mobook_lookup(&o,Direction::Outbox,&other).unwrap().is_some());assert_eq!(block_on(db.load_global()).unwrap().len(),1);
    }
    #[test] fn mobook_v1_pending_is_bounded_and_receipted_rows_disappear() {
        let (db,o,mut r)=setup();
        for n in 0..4 {r.id=format!("operation_{n:08}");db.mobook_atomic_commit(&o,Direction::Outbox,&r,updates(1)).unwrap();}
        assert_eq!(db.mobook_pending(&o,&r.group,None,2).unwrap(),vec!["operation_00000000","operation_00000001"]);
        assert_eq!(db.mobook_pending(&o,&r.group,Some("operation_00000001"),2).unwrap(),vec!["operation_00000002","operation_00000003"]);
        db.mobook_record_receipt(&o,&r,b"receipt").unwrap();assert_eq!(db.mobook_pending(&o,&r.group,None,100).unwrap().len(),3);
        assert!(db.mobook_pending(&o,&r.group,None,101).is_err());
    }
    #[test] fn mobook_v1_crash_child() {
        let Ok(path)=std::env::var("MOBOOK_V1_PATH") else {return;};
        let db=block_on(EncryptedDb::open(path,vec![0x5a;32])).unwrap();
        let (_,o,r)=setup();let d=if std::env::var("MOBOOK_V1_DIRECTION").as_deref()==Ok("in"){Direction::Inbox}else{Direction::Outbox};
        db.mobook_atomic_commit(&o,d,&r,updates(9)).unwrap();panic!("missing exit boundary");
    }
    #[test] fn mobook_v1_process_exit_both_directions() {
        let (_,o,r)=setup();
        for direction in ["in","out"] { for point in ["before","after"] {
            let path=std::env::temp_dir().join(format!("mobook_v1_crash_{}_{direction}_{point}.db",std::process::id()));
            let _=std::fs::remove_file(&path);
            let db=block_on(EncryptedDb::open(path.to_str().unwrap().into(),vec![0x5a;32])).unwrap();db.mobook_initialize(&o).unwrap();drop(db);
            let status=std::process::Command::new(std::env::current_exe().unwrap()).args(["--exact","encrypted_db::mobook_journal::tests::mobook_v1_crash_child"])
              .env("MOBOOK_V1_PATH",&path).env("MOBOOK_V1_DIRECTION",direction).env("MOBOOK_V1_CRASH",point).output().unwrap();
            assert_eq!(status.status.code(),Some(if point=="before"{81}else{82}));
            let db=block_on(EncryptedDb::open(path.to_str().unwrap().into(),vec![0x5a;32])).unwrap();db.mobook_initialize(&o).unwrap();
            let found=db.mobook_lookup(&o,if direction=="in"{Direction::Inbox}else{Direction::Outbox},&r).unwrap();
            assert_eq!(found.is_some(),point=="after");
            let entries=block_on(db.load_for_group(&r.group)).unwrap();assert_eq!(entries.len(),if point=="after"{1}else{0});
            if let Some(found)=found {assert_eq!(found.payload,r.payload);assert_eq!(entries[0].1,vec![9]);}
            drop(db);for suffix in ["",".lock","-journal"] {let _=std::fs::remove_file(format!("{}{suffix}",path.display()));}
        }}
    }

    #[test] fn mobook_v1_corrupt_rows_and_malformed_migration_refuse_without_reset() {
        let (db,o,r)=setup();db.mobook_atomic_commit(&o,Direction::Outbox,&r,updates(1)).unwrap();
        db.conn.lock().unwrap().execute("UPDATE mobook_outbox_v1 SET request_digest=x'01'",[]).unwrap();
        assert!(db.mobook_lookup(&o,Direction::Outbox,&r).is_err());
        assert_eq!(db.conn.lock().unwrap().query_row("SELECT count(*) FROM mobook_outbox_v1",[],|row|row.get::<_,i64>(0)).unwrap(),1);
        let malformed=block_on(EncryptedDb::open(":memory:".into(),vec![0x5a;32])).unwrap();
        malformed.conn.lock().unwrap().execute_batch("CREATE TABLE mobook_journal_owner(singleton INTEGER PRIMARY KEY,version INTEGER);").unwrap();
        assert!(malformed.mobook_initialize(&o).is_err());
        assert_eq!(malformed.conn.lock().unwrap().query_row("SELECT count(*) FROM mobook_journal_owner",[],|row|row.get::<_,i64>(0)).unwrap(),0);
    }

}
