//! SnapshotStorageProvider — HashMap-based OpenMLS StorageProvider.
//!
//! Loaded from caller-owned storage entries, provides sync read/write/delete
//! on an in-memory HashMap. After OpenMLS operations, diff the initial
//! vs current state to produce StorageUpdates for the caller to persist.
//!
//! Key format matches MemoryStorage: `[LABEL || serde_json(key) || VERSION_BE_U16]`

use openmls_traits::OpenMlsProvider;
use openmls_traits::storage::{CURRENT_VERSION, StorageProvider, traits};
use parking_lot::Mutex;
use std::collections::HashMap;
use zeroize::{Zeroize, Zeroizing};

use crate::encrypted_db::StorageUpdates;

// ═══════════════════════════════════════════════════════════════
// ERROR TYPE
// ═══════════════════════════════════════════════════════════════

#[derive(thiserror::Error, Debug)]
pub enum SnapshotStorageError {
    #[error("Serialization error: {0}")]
    Serialization(String),
}

// ═══════════════════════════════════════════════════════════════
// LABELS (matching MemoryStorage exactly)
// ═══════════════════════════════════════════════════════════════

const KEY_PACKAGE_LABEL: &[u8] = b"KeyPackage";
const PSK_LABEL: &[u8] = b"Psk";
const ENCRYPTION_KEY_PAIR_LABEL: &[u8] = b"EncryptionKeyPair";
const SIGNATURE_KEY_PAIR_LABEL: &[u8] = b"SignatureKeyPair";
const EPOCH_KEY_PAIRS_LABEL: &[u8] = b"EpochKeyPairs";
const TREE_LABEL: &[u8] = b"Tree";
const GROUP_CONTEXT_LABEL: &[u8] = b"GroupContext";
const INTERIM_TRANSCRIPT_HASH_LABEL: &[u8] = b"InterimTranscriptHash";
const CONFIRMATION_TAG_LABEL: &[u8] = b"ConfirmationTag";
const JOIN_CONFIG_LABEL: &[u8] = b"MlsGroupJoinConfig";
const OWN_LEAF_NODES_LABEL: &[u8] = b"OwnLeafNodes";
const GROUP_STATE_LABEL: &[u8] = b"GroupState";
const QUEUED_PROPOSAL_LABEL: &[u8] = b"QueuedProposal";
const PROPOSAL_QUEUE_REFS_LABEL: &[u8] = b"ProposalQueueRefs";
const OWN_LEAF_NODE_INDEX_LABEL: &[u8] = b"OwnLeafNodeIndex";
const EPOCH_SECRETS_LABEL: &[u8] = b"EpochSecrets";
const RESUMPTION_PSK_STORE_LABEL: &[u8] = b"ResumptionPsk";
const MESSAGE_SECRETS_LABEL: &[u8] = b"MessageSecrets";

/// The labels of entries that belong to one group: every label above except
/// the four `encrypted_db::GLOBAL_LABELS`.
const GROUP_LABELS: &[&[u8]] = &[
    EPOCH_KEY_PAIRS_LABEL,
    TREE_LABEL,
    GROUP_CONTEXT_LABEL,
    INTERIM_TRANSCRIPT_HASH_LABEL,
    CONFIRMATION_TAG_LABEL,
    JOIN_CONFIG_LABEL,
    OWN_LEAF_NODES_LABEL,
    GROUP_STATE_LABEL,
    QUEUED_PROPOSAL_LABEL,
    PROPOSAL_QUEUE_REFS_LABEL,
    OWN_LEAF_NODE_INDEX_LABEL,
    EPOCH_SECRETS_LABEL,
    RESUMPTION_PSK_STORE_LABEL,
    MESSAGE_SECRETS_LABEL,
];

/// Whether `key` is an entry this provider writes for `group_id`.
///
/// A group's key is its label, then the group ID as serde_json writes it,
/// then whatever else tells its entries apart (epoch and leaf for epoch key
/// pairs). A queued proposal is the exception: its key is the pair
/// (group ID, proposal ref), so the ID comes after the `[` that opens it. A
/// serialized ID ends in a closing bracket and is therefore never a prefix
/// of another one: `group` does not match the keys of `group-2`, nor the
/// other way round.
///
/// IndexedDB keys carry no group column, so on the Web this is how
/// `deleteGroup` finds the rows OpenMLS leaves behind. On both targets it is
/// how an external join that replaces a stored group finds that group's rows
/// in its snapshot, which keeps no column either. A key it does not recognise
/// is kept rather than deleted — a stray row can be cleaned up later, another
/// group's state cannot be brought back.
pub(crate) fn key_belongs_to_group(key: &[u8], group_id: &[u8]) -> bool {
    let group_id = openmls::prelude::GroupId::from_slice(group_id);
    // Serialized exactly as the writers below do: through `build_key_serde`
    // for a plain group key, through `serde_json::to_value` first inside the
    // proposal pair.
    let (Ok(plain), Ok(in_pair)) = (
        serde_json::to_vec(&group_id),
        serde_json::to_value(&group_id).and_then(|value| serde_json::to_vec(&value)),
    ) else {
        return false;
    };
    GROUP_LABELS.iter().any(|label| match key.strip_prefix(*label) {
        Some(rest) if *label == QUEUED_PROPOSAL_LABEL => rest
            .strip_prefix(b"[")
            .and_then(|rest| rest.strip_prefix(in_pair.as_slice()))
            .is_some_and(|rest| rest.starts_with(b",")),
        Some(rest) => rest.starts_with(&plain),
        None => false,
    })
}

/// The prefix of the one entry every stored group has exactly once: its join
/// configuration, keyed by the group ID alone.
///
/// OpenMLS cannot load a group without that entry, and creating, joining
/// and deleting a group write or remove it in the same transaction as the
/// rest of the group's state — so listing these keys lists the stored
/// groups, without reading any value.
pub(crate) const STORED_GROUP_KEY_PREFIX: &[u8] = JOIN_CONFIG_LABEL;

/// The group ID in a key that starts with `STORED_GROUP_KEY_PREFIX`.
///
/// `None` for any other key, and for one written under another storage
/// version than the current one: this provider never reads such an entry,
/// so its group would not load either.
pub(crate) fn stored_group_id(key: &[u8]) -> Option<Vec<u8>> {
    let rest = key.strip_prefix(STORED_GROUP_KEY_PREFIX)?;
    let (json, version) = rest.split_at_checked(rest.len().checked_sub(2)?)?;
    if version != CURRENT_VERSION.to_be_bytes().as_slice() {
        return None;
    }
    let group_id: openmls::prelude::GroupId = serde_json::from_slice(json).ok()?;
    Some(group_id.as_slice().to_vec())
}

// ═══════════════════════════════════════════════════════════════
// SNAPSHOT STORAGE PROVIDER
// ═══════════════════════════════════════════════════════════════

pub struct SnapshotStorageProvider {
    initial: HashMap<Vec<u8>, Vec<u8>>,
    current: Mutex<HashMap<Vec<u8>, Vec<u8>>>,
}

impl Drop for SnapshotStorageProvider {
    fn drop(&mut self) {
        for (_k, v) in self.initial.drain() {
            let mut v = v;
            v.zeroize();
        }
        for (_k, v) in self.current.get_mut().drain() {
            let mut v = v;
            v.zeroize();
        }
    }
}

impl SnapshotStorageProvider {
    /// Create a snapshot from DB entries.
    pub fn from_entries(entries: Vec<(Vec<u8>, Vec<u8>)>) -> Self {
        let initial: HashMap<Vec<u8>, Vec<u8>> = entries.into_iter().collect();
        let current = Mutex::new(initial.clone());
        Self { initial, current }
    }

    /// Takes every entry of the group `group_id` out of the snapshot, wiping
    /// what it held. An entry that was loaded and is no longer here is a
    /// delete when the snapshot is written back, so the write that stores
    /// what replaces the group also deletes all of it — the entries OpenMLS
    /// itself would not delete included.
    pub(crate) fn forget_group(&self, group_id: &[u8]) {
        self.current.lock().retain(|key, value| {
            if key_belongs_to_group(key, group_id) {
                value.zeroize();
                false
            } else {
                true
            }
        });
    }

    /// Diff initial vs current to produce StorageUpdates.
    pub fn into_updates(mut self) -> StorageUpdates {
        let mut upserts = Vec::new();
        let mut deletes = Vec::new();
        let current = self.current.get_mut();

        // Find new or changed entries.
        for (key, value) in current.iter() {
            match self.initial.get(key) {
                Some(old_value) if old_value == value => {} // unchanged
                _ => upserts.push((key.clone(), value.clone())),
            }
        }

        // Find deleted entries.
        for key in self.initial.keys() {
            if !current.contains_key(key) {
                deletes.push(key.clone());
            }
        }

        // Zeroize before dropping.
        for (_k, v) in self.initial.drain() {
            let mut v = v;
            v.zeroize();
        }
        for (_k, v) in current.drain() {
            let mut v = v;
            v.zeroize();
        }

        StorageUpdates { upserts, deletes }
    }
}

// ═══════════════════════════════════════════════════════════════
// INTERNAL HELPERS
// ═══════════════════════════════════════════════════════════════

/// Build composite key: `[label || key_bytes || version_be_u16]`
fn build_key<const V: u16>(label: &[u8], key_bytes: &[u8]) -> Vec<u8> {
    let mut out = Vec::with_capacity(label.len() + key_bytes.len() + 2);
    out.extend_from_slice(label);
    out.extend_from_slice(key_bytes);
    out.extend_from_slice(&u16::to_be_bytes(V));
    out
}

/// Serialize a key via serde_json, then build the composite storage key.
fn build_key_serde<const V: u16>(
    label: &[u8],
    key: &impl serde::Serialize,
) -> Result<Vec<u8>, SnapshotStorageError> {
    let key_bytes =
        serde_json::to_vec(key).map_err(|e| SnapshotStorageError::Serialization(e.to_string()))?;
    Ok(build_key::<V>(label, &key_bytes))
}

/// Build composite key for epoch key pairs (group_id + epoch + leaf_index).
fn build_epoch_key<const V: u16>(
    group_id: &impl serde::Serialize,
    epoch: &impl serde::Serialize,
    leaf_index: u32,
) -> Result<Vec<u8>, SnapshotStorageError> {
    let mut key_bytes = serde_json::to_vec(group_id)
        .map_err(|e| SnapshotStorageError::Serialization(e.to_string()))?;
    key_bytes.extend_from_slice(
        &serde_json::to_vec(epoch)
            .map_err(|e| SnapshotStorageError::Serialization(e.to_string()))?,
    );
    key_bytes.extend_from_slice(
        &serde_json::to_vec(&leaf_index)
            .map_err(|e| SnapshotStorageError::Serialization(e.to_string()))?,
    );
    Ok(build_key::<V>(EPOCH_KEY_PAIRS_LABEL, &key_bytes))
}

impl SnapshotStorageProvider {
    // -- low-level operations --

    fn kv_write(&self, key: Vec<u8>, value: Vec<u8>) {
        if let Some(mut previous) = self.current.lock().insert(key, value) {
            previous.zeroize();
        }
    }

    /// Read a value out of the snapshot.
    ///
    /// The return is wrapped rather than a bare `Vec<u8>` because every value
    /// in this map is MLS key material and this is the one operation that
    /// hands a *copy* of it out. `kv_write` and `kv_delete` already wipe the
    /// copy they displace; the read path was the one that did not, so each
    /// read left a plaintext copy in freed heap memory that nothing ever
    /// overwrote — reads of `EpochSecrets` and `MessageSecrets` included.
    ///
    /// The wrapper is what makes it structural instead of a convention: a
    /// caller cannot bind the value to a plain `Vec<u8>` without unwrapping it
    /// on purpose, and the wipe runs on every path out of the caller, `?`
    /// included.
    fn kv_read(&self, key: &[u8]) -> Option<Zeroizing<Vec<u8>>> {
        self.current.lock().get(key).cloned().map(Zeroizing::new)
    }

    fn kv_delete(&self, key: &[u8]) {
        if let Some(mut removed) = self.current.lock().remove(key) {
            removed.zeroize();
        }
    }

    // -- higher-level helpers --

    fn write_val<const V: u16>(
        &self,
        label: &[u8],
        key: &impl serde::Serialize,
        value: &impl serde::Serialize,
    ) -> Result<(), SnapshotStorageError> {
        let storage_key = build_key_serde::<V>(label, key)?;
        let val_bytes = serde_json::to_vec(value)
            .map_err(|e| SnapshotStorageError::Serialization(e.to_string()))?;
        self.kv_write(storage_key, val_bytes);
        Ok(())
    }

    fn read_val<const V: u16, Val: serde::de::DeserializeOwned>(
        &self,
        label: &[u8],
        key: &impl serde::Serialize,
    ) -> Result<Option<Val>, SnapshotStorageError> {
        let storage_key = build_key_serde::<V>(label, key)?;
        match self.kv_read(&storage_key) {
            Some(bytes) => {
                let val = serde_json::from_slice(&bytes)
                    .map_err(|e| SnapshotStorageError::Serialization(e.to_string()))?;
                Ok(Some(val))
            }
            None => Ok(None),
        }
    }

    fn delete_val<const V: u16>(
        &self,
        label: &[u8],
        key: &impl serde::Serialize,
    ) -> Result<(), SnapshotStorageError> {
        let storage_key = build_key_serde::<V>(label, key)?;
        self.kv_delete(&storage_key);
        Ok(())
    }

    fn append_to_list<const V: u16>(
        &self,
        label: &[u8],
        key: &impl serde::Serialize,
        item: Vec<u8>,
    ) -> Result<(), SnapshotStorageError> {
        let storage_key = build_key_serde::<V>(label, key)?;
        // Wrapped for the same reason `kv_read` wraps its return, one level
        // down: the elements are the decoded plaintext items, and they are
        // dropped here rather than stored. `item` is moved in, so it rides
        // out on the same wipe.
        let mut list: Zeroizing<Vec<Vec<u8>>> = Zeroizing::new(match self.kv_read(&storage_key) {
            Some(bytes) => serde_json::from_slice(&bytes)
                .map_err(|e| SnapshotStorageError::Serialization(e.to_string()))?,
            None => Vec::new(),
        });
        list.push(item);
        let val_bytes = serde_json::to_vec(&*list)
            .map_err(|e| SnapshotStorageError::Serialization(e.to_string()))?;
        self.kv_write(storage_key, val_bytes);
        Ok(())
    }

    fn read_list<const V: u16, Val: serde::de::DeserializeOwned>(
        &self,
        label: &[u8],
        key: &impl serde::Serialize,
    ) -> Result<Vec<Val>, SnapshotStorageError> {
        let storage_key = build_key_serde::<V>(label, key)?;
        match self.kv_read(&storage_key) {
            Some(bytes) => {
                let raw_list: Zeroizing<Vec<Vec<u8>>> = Zeroizing::new(
                    serde_json::from_slice(&bytes)
                        .map_err(|e| SnapshotStorageError::Serialization(e.to_string()))?,
                );
                let mut result = Vec::with_capacity(raw_list.len());
                // Borrowed, not consumed. Moving the elements out of the list
                // would take them past the wrapper and drop them unwiped,
                // which is exactly what the wrapper is here to prevent. The
                // decoded `Val`s are OpenMLS types and wipe themselves or not
                // on their own terms — that part is not ours to decide.
                for item_bytes in raw_list.iter() {
                    let item: Val = serde_json::from_slice(item_bytes)
                        .map_err(|e| SnapshotStorageError::Serialization(e.to_string()))?;
                    result.push(item);
                }
                Ok(result)
            }
            None => Ok(Vec::new()),
        }
    }

    fn remove_from_list<const V: u16>(
        &self,
        label: &[u8],
        key: &impl serde::Serialize,
        item: Vec<u8>,
    ) -> Result<(), SnapshotStorageError> {
        let storage_key = build_key_serde::<V>(label, key)?;
        // The needle is a serialized item too — plaintext this function owns
        // and, unlike in `append_to_list`, never moves into the list.
        let item = Zeroizing::new(item);
        let mut list: Zeroizing<Vec<Vec<u8>>> = Zeroizing::new(match self.kv_read(&storage_key) {
            Some(bytes) => serde_json::from_slice(&bytes)
                .map_err(|e| SnapshotStorageError::Serialization(e.to_string()))?,
            None => return Ok(()),
        });
        if let Some(pos) = list.iter().position(|x| *x == *item) {
            // `remove` hands the element back instead of dropping it in place,
            // so it leaves the wrapper's reach. Wipe it on the way out.
            list.remove(pos).zeroize();
        }
        let val_bytes = serde_json::to_vec(&*list)
            .map_err(|e| SnapshotStorageError::Serialization(e.to_string()))?;
        self.kv_write(storage_key, val_bytes);
        Ok(())
    }
}

// ═══════════════════════════════════════════════════════════════
// STORAGE PROVIDER TRAIT IMPLEMENTATION
// ═══════════════════════════════════════════════════════════════

impl StorageProvider<{ CURRENT_VERSION }> for SnapshotStorageProvider {
    type Error = SnapshotStorageError;

    // ═══════════════════════════════════════════════════════════
    // A. WRITERS — GROUP STATE
    // ═══════════════════════════════════════════════════════════

    fn write_mls_join_config<
        GroupId: traits::GroupId<{ CURRENT_VERSION }>,
        MlsGroupJoinConfig: traits::MlsGroupJoinConfig<{ CURRENT_VERSION }>,
    >(
        &self,
        group_id: &GroupId,
        config: &MlsGroupJoinConfig,
    ) -> Result<(), Self::Error> {
        self.write_val::<{ CURRENT_VERSION }>(JOIN_CONFIG_LABEL, group_id, config)
    }

    fn append_own_leaf_node<
        GroupId: traits::GroupId<{ CURRENT_VERSION }>,
        LeafNode: traits::LeafNode<{ CURRENT_VERSION }>,
    >(
        &self,
        group_id: &GroupId,
        leaf_node: &LeafNode,
    ) -> Result<(), Self::Error> {
        let item = serde_json::to_vec(leaf_node)
            .map_err(|e| SnapshotStorageError::Serialization(e.to_string()))?;
        self.append_to_list::<{ CURRENT_VERSION }>(OWN_LEAF_NODES_LABEL, group_id, item)
    }

    fn queue_proposal<
        GroupId: traits::GroupId<{ CURRENT_VERSION }>,
        ProposalRef: traits::ProposalRef<{ CURRENT_VERSION }>,
        QueuedProposal: traits::QueuedProposal<{ CURRENT_VERSION }>,
    >(
        &self,
        group_id: &GroupId,
        proposal_ref: &ProposalRef,
        proposal: &QueuedProposal,
    ) -> Result<(), Self::Error> {
        let composite_key = (
            serde_json::to_value(group_id)
                .map_err(|e| SnapshotStorageError::Serialization(e.to_string()))?,
            serde_json::to_value(proposal_ref)
                .map_err(|e| SnapshotStorageError::Serialization(e.to_string()))?,
        );
        self.write_val::<{ CURRENT_VERSION }>(QUEUED_PROPOSAL_LABEL, &composite_key, proposal)?;

        let ref_bytes = serde_json::to_vec(proposal_ref)
            .map_err(|e| SnapshotStorageError::Serialization(e.to_string()))?;
        self.append_to_list::<{ CURRENT_VERSION }>(PROPOSAL_QUEUE_REFS_LABEL, group_id, ref_bytes)
    }

    fn write_tree<
        GroupId: traits::GroupId<{ CURRENT_VERSION }>,
        TreeSync: traits::TreeSync<{ CURRENT_VERSION }>,
    >(
        &self,
        group_id: &GroupId,
        tree: &TreeSync,
    ) -> Result<(), Self::Error> {
        self.write_val::<{ CURRENT_VERSION }>(TREE_LABEL, group_id, tree)
    }

    fn write_interim_transcript_hash<
        GroupId: traits::GroupId<{ CURRENT_VERSION }>,
        InterimTranscriptHash: traits::InterimTranscriptHash<{ CURRENT_VERSION }>,
    >(
        &self,
        group_id: &GroupId,
        interim_transcript_hash: &InterimTranscriptHash,
    ) -> Result<(), Self::Error> {
        self.write_val::<{ CURRENT_VERSION }>(
            INTERIM_TRANSCRIPT_HASH_LABEL,
            group_id,
            interim_transcript_hash,
        )
    }

    fn write_context<
        GroupId: traits::GroupId<{ CURRENT_VERSION }>,
        GroupContext: traits::GroupContext<{ CURRENT_VERSION }>,
    >(
        &self,
        group_id: &GroupId,
        group_context: &GroupContext,
    ) -> Result<(), Self::Error> {
        self.write_val::<{ CURRENT_VERSION }>(GROUP_CONTEXT_LABEL, group_id, group_context)
    }

    fn write_confirmation_tag<
        GroupId: traits::GroupId<{ CURRENT_VERSION }>,
        ConfirmationTag: traits::ConfirmationTag<{ CURRENT_VERSION }>,
    >(
        &self,
        group_id: &GroupId,
        confirmation_tag: &ConfirmationTag,
    ) -> Result<(), Self::Error> {
        self.write_val::<{ CURRENT_VERSION }>(CONFIRMATION_TAG_LABEL, group_id, confirmation_tag)
    }

    fn write_group_state<
        GroupState: traits::GroupState<{ CURRENT_VERSION }>,
        GroupId: traits::GroupId<{ CURRENT_VERSION }>,
    >(
        &self,
        group_id: &GroupId,
        group_state: &GroupState,
    ) -> Result<(), Self::Error> {
        self.write_val::<{ CURRENT_VERSION }>(GROUP_STATE_LABEL, group_id, group_state)
    }

    fn write_message_secrets<
        GroupId: traits::GroupId<{ CURRENT_VERSION }>,
        MessageSecrets: traits::MessageSecrets<{ CURRENT_VERSION }>,
    >(
        &self,
        group_id: &GroupId,
        message_secrets: &MessageSecrets,
    ) -> Result<(), Self::Error> {
        self.write_val::<{ CURRENT_VERSION }>(MESSAGE_SECRETS_LABEL, group_id, message_secrets)
    }

    fn write_resumption_psk_store<
        GroupId: traits::GroupId<{ CURRENT_VERSION }>,
        ResumptionPskStore: traits::ResumptionPskStore<{ CURRENT_VERSION }>,
    >(
        &self,
        group_id: &GroupId,
        resumption_psk_store: &ResumptionPskStore,
    ) -> Result<(), Self::Error> {
        self.write_val::<{ CURRENT_VERSION }>(
            RESUMPTION_PSK_STORE_LABEL,
            group_id,
            resumption_psk_store,
        )
    }

    fn write_own_leaf_index<
        GroupId: traits::GroupId<{ CURRENT_VERSION }>,
        LeafNodeIndex: traits::LeafNodeIndex<{ CURRENT_VERSION }>,
    >(
        &self,
        group_id: &GroupId,
        own_leaf_index: &LeafNodeIndex,
    ) -> Result<(), Self::Error> {
        self.write_val::<{ CURRENT_VERSION }>(OWN_LEAF_NODE_INDEX_LABEL, group_id, own_leaf_index)
    }

    fn write_group_epoch_secrets<
        GroupId: traits::GroupId<{ CURRENT_VERSION }>,
        GroupEpochSecrets: traits::GroupEpochSecrets<{ CURRENT_VERSION }>,
    >(
        &self,
        group_id: &GroupId,
        group_epoch_secrets: &GroupEpochSecrets,
    ) -> Result<(), Self::Error> {
        self.write_val::<{ CURRENT_VERSION }>(EPOCH_SECRETS_LABEL, group_id, group_epoch_secrets)
    }

    // ═══════════════════════════════════════════════════════════
    // B. WRITERS — CRYPTO OBJECTS
    // ═══════════════════════════════════════════════════════════

    fn write_signature_key_pair<
        SignaturePublicKey: traits::SignaturePublicKey<{ CURRENT_VERSION }>,
        SignatureKeyPair: traits::SignatureKeyPair<{ CURRENT_VERSION }>,
    >(
        &self,
        public_key: &SignaturePublicKey,
        signature_key_pair: &SignatureKeyPair,
    ) -> Result<(), Self::Error> {
        self.write_val::<{ CURRENT_VERSION }>(
            SIGNATURE_KEY_PAIR_LABEL,
            public_key,
            signature_key_pair,
        )
    }

    fn write_encryption_key_pair<
        EncryptionKey: traits::EncryptionKey<{ CURRENT_VERSION }>,
        HpkeKeyPair: traits::HpkeKeyPair<{ CURRENT_VERSION }>,
    >(
        &self,
        public_key: &EncryptionKey,
        key_pair: &HpkeKeyPair,
    ) -> Result<(), Self::Error> {
        self.write_val::<{ CURRENT_VERSION }>(ENCRYPTION_KEY_PAIR_LABEL, public_key, key_pair)
    }

    fn write_encryption_epoch_key_pairs<
        GroupId: traits::GroupId<{ CURRENT_VERSION }>,
        EpochKey: traits::EpochKey<{ CURRENT_VERSION }>,
        HpkeKeyPair: traits::HpkeKeyPair<{ CURRENT_VERSION }>,
    >(
        &self,
        group_id: &GroupId,
        epoch: &EpochKey,
        leaf_index: u32,
        key_pairs: &[HpkeKeyPair],
    ) -> Result<(), Self::Error> {
        let storage_key = build_epoch_key::<{ CURRENT_VERSION }>(group_id, epoch, leaf_index)?;
        let val_bytes = serde_json::to_vec(key_pairs)
            .map_err(|e| SnapshotStorageError::Serialization(e.to_string()))?;
        self.kv_write(storage_key, val_bytes);
        Ok(())
    }

    fn write_key_package<
        HashReference: traits::HashReference<{ CURRENT_VERSION }>,
        KeyPackage: traits::KeyPackage<{ CURRENT_VERSION }>,
    >(
        &self,
        hash_ref: &HashReference,
        key_package: &KeyPackage,
    ) -> Result<(), Self::Error> {
        self.write_val::<{ CURRENT_VERSION }>(KEY_PACKAGE_LABEL, hash_ref, key_package)
    }

    fn write_psk<
        PskId: traits::PskId<{ CURRENT_VERSION }>,
        PskBundle: traits::PskBundle<{ CURRENT_VERSION }>,
    >(
        &self,
        psk_id: &PskId,
        psk: &PskBundle,
    ) -> Result<(), Self::Error> {
        self.write_val::<{ CURRENT_VERSION }>(PSK_LABEL, psk_id, psk)
    }

    // ═══════════════════════════════════════════════════════════
    // C. READERS — GROUP STATE
    // ═══════════════════════════════════════════════════════════

    fn mls_group_join_config<
        GroupId: traits::GroupId<{ CURRENT_VERSION }>,
        MlsGroupJoinConfig: traits::MlsGroupJoinConfig<{ CURRENT_VERSION }>,
    >(
        &self,
        group_id: &GroupId,
    ) -> Result<Option<MlsGroupJoinConfig>, Self::Error> {
        self.read_val::<{ CURRENT_VERSION }, _>(JOIN_CONFIG_LABEL, group_id)
    }

    fn own_leaf_nodes<
        GroupId: traits::GroupId<{ CURRENT_VERSION }>,
        LeafNode: traits::LeafNode<{ CURRENT_VERSION }>,
    >(
        &self,
        group_id: &GroupId,
    ) -> Result<Vec<LeafNode>, Self::Error> {
        self.read_list::<{ CURRENT_VERSION }, _>(OWN_LEAF_NODES_LABEL, group_id)
    }

    fn queued_proposal_refs<
        GroupId: traits::GroupId<{ CURRENT_VERSION }>,
        ProposalRef: traits::ProposalRef<{ CURRENT_VERSION }>,
    >(
        &self,
        group_id: &GroupId,
    ) -> Result<Vec<ProposalRef>, Self::Error> {
        self.read_list::<{ CURRENT_VERSION }, _>(PROPOSAL_QUEUE_REFS_LABEL, group_id)
    }

    fn queued_proposals<
        GroupId: traits::GroupId<{ CURRENT_VERSION }>,
        ProposalRef: traits::ProposalRef<{ CURRENT_VERSION }>,
        QueuedProposal: traits::QueuedProposal<{ CURRENT_VERSION }>,
    >(
        &self,
        group_id: &GroupId,
    ) -> Result<Vec<(ProposalRef, QueuedProposal)>, Self::Error> {
        let refs: Vec<ProposalRef> =
            self.read_list::<{ CURRENT_VERSION }, _>(PROPOSAL_QUEUE_REFS_LABEL, group_id)?;
        let mut result = Vec::with_capacity(refs.len());
        for prop_ref in refs {
            let composite_key = (
                serde_json::to_value(group_id)
                    .map_err(|e| SnapshotStorageError::Serialization(e.to_string()))?,
                serde_json::to_value(&prop_ref)
                    .map_err(|e| SnapshotStorageError::Serialization(e.to_string()))?,
            );
            if let Some(proposal) = self.read_val::<{ CURRENT_VERSION }, QueuedProposal>(
                QUEUED_PROPOSAL_LABEL,
                &composite_key,
            )? {
                result.push((prop_ref, proposal));
            }
        }
        Ok(result)
    }

    fn tree<
        GroupId: traits::GroupId<{ CURRENT_VERSION }>,
        TreeSync: traits::TreeSync<{ CURRENT_VERSION }>,
    >(
        &self,
        group_id: &GroupId,
    ) -> Result<Option<TreeSync>, Self::Error> {
        self.read_val::<{ CURRENT_VERSION }, _>(TREE_LABEL, group_id)
    }

    fn group_context<
        GroupId: traits::GroupId<{ CURRENT_VERSION }>,
        GroupContext: traits::GroupContext<{ CURRENT_VERSION }>,
    >(
        &self,
        group_id: &GroupId,
    ) -> Result<Option<GroupContext>, Self::Error> {
        self.read_val::<{ CURRENT_VERSION }, _>(GROUP_CONTEXT_LABEL, group_id)
    }

    fn interim_transcript_hash<
        GroupId: traits::GroupId<{ CURRENT_VERSION }>,
        InterimTranscriptHash: traits::InterimTranscriptHash<{ CURRENT_VERSION }>,
    >(
        &self,
        group_id: &GroupId,
    ) -> Result<Option<InterimTranscriptHash>, Self::Error> {
        self.read_val::<{ CURRENT_VERSION }, _>(INTERIM_TRANSCRIPT_HASH_LABEL, group_id)
    }

    fn confirmation_tag<
        GroupId: traits::GroupId<{ CURRENT_VERSION }>,
        ConfirmationTag: traits::ConfirmationTag<{ CURRENT_VERSION }>,
    >(
        &self,
        group_id: &GroupId,
    ) -> Result<Option<ConfirmationTag>, Self::Error> {
        self.read_val::<{ CURRENT_VERSION }, _>(CONFIRMATION_TAG_LABEL, group_id)
    }

    fn group_state<
        GroupState: traits::GroupState<{ CURRENT_VERSION }>,
        GroupId: traits::GroupId<{ CURRENT_VERSION }>,
    >(
        &self,
        group_id: &GroupId,
    ) -> Result<Option<GroupState>, Self::Error> {
        self.read_val::<{ CURRENT_VERSION }, _>(GROUP_STATE_LABEL, group_id)
    }

    fn message_secrets<
        GroupId: traits::GroupId<{ CURRENT_VERSION }>,
        MessageSecrets: traits::MessageSecrets<{ CURRENT_VERSION }>,
    >(
        &self,
        group_id: &GroupId,
    ) -> Result<Option<MessageSecrets>, Self::Error> {
        self.read_val::<{ CURRENT_VERSION }, _>(MESSAGE_SECRETS_LABEL, group_id)
    }

    fn resumption_psk_store<
        GroupId: traits::GroupId<{ CURRENT_VERSION }>,
        ResumptionPskStore: traits::ResumptionPskStore<{ CURRENT_VERSION }>,
    >(
        &self,
        group_id: &GroupId,
    ) -> Result<Option<ResumptionPskStore>, Self::Error> {
        self.read_val::<{ CURRENT_VERSION }, _>(RESUMPTION_PSK_STORE_LABEL, group_id)
    }

    fn own_leaf_index<
        GroupId: traits::GroupId<{ CURRENT_VERSION }>,
        LeafNodeIndex: traits::LeafNodeIndex<{ CURRENT_VERSION }>,
    >(
        &self,
        group_id: &GroupId,
    ) -> Result<Option<LeafNodeIndex>, Self::Error> {
        self.read_val::<{ CURRENT_VERSION }, _>(OWN_LEAF_NODE_INDEX_LABEL, group_id)
    }

    fn group_epoch_secrets<
        GroupId: traits::GroupId<{ CURRENT_VERSION }>,
        GroupEpochSecrets: traits::GroupEpochSecrets<{ CURRENT_VERSION }>,
    >(
        &self,
        group_id: &GroupId,
    ) -> Result<Option<GroupEpochSecrets>, Self::Error> {
        self.read_val::<{ CURRENT_VERSION }, _>(EPOCH_SECRETS_LABEL, group_id)
    }

    // ═══════════════════════════════════════════════════════════
    // D. READERS — CRYPTO OBJECTS
    // ═══════════════════════════════════════════════════════════

    fn signature_key_pair<
        SignaturePublicKey: traits::SignaturePublicKey<{ CURRENT_VERSION }>,
        SignatureKeyPair: traits::SignatureKeyPair<{ CURRENT_VERSION }>,
    >(
        &self,
        public_key: &SignaturePublicKey,
    ) -> Result<Option<SignatureKeyPair>, Self::Error> {
        self.read_val::<{ CURRENT_VERSION }, _>(SIGNATURE_KEY_PAIR_LABEL, public_key)
    }

    fn encryption_key_pair<
        HpkeKeyPair: traits::HpkeKeyPair<{ CURRENT_VERSION }>,
        EncryptionKey: traits::EncryptionKey<{ CURRENT_VERSION }>,
    >(
        &self,
        public_key: &EncryptionKey,
    ) -> Result<Option<HpkeKeyPair>, Self::Error> {
        self.read_val::<{ CURRENT_VERSION }, _>(ENCRYPTION_KEY_PAIR_LABEL, public_key)
    }

    fn encryption_epoch_key_pairs<
        GroupId: traits::GroupId<{ CURRENT_VERSION }>,
        EpochKey: traits::EpochKey<{ CURRENT_VERSION }>,
        HpkeKeyPair: traits::HpkeKeyPair<{ CURRENT_VERSION }>,
    >(
        &self,
        group_id: &GroupId,
        epoch: &EpochKey,
        leaf_index: u32,
    ) -> Result<Vec<HpkeKeyPair>, Self::Error> {
        let storage_key = build_epoch_key::<{ CURRENT_VERSION }>(group_id, epoch, leaf_index)?;
        match self.kv_read(&storage_key) {
            Some(bytes) => {
                let val: Vec<HpkeKeyPair> = serde_json::from_slice(&bytes)
                    .map_err(|e| SnapshotStorageError::Serialization(e.to_string()))?;
                Ok(val)
            }
            None => Ok(Vec::new()),
        }
    }

    fn key_package<
        KeyPackageRef: traits::HashReference<{ CURRENT_VERSION }>,
        KeyPackage: traits::KeyPackage<{ CURRENT_VERSION }>,
    >(
        &self,
        hash_ref: &KeyPackageRef,
    ) -> Result<Option<KeyPackage>, Self::Error> {
        self.read_val::<{ CURRENT_VERSION }, _>(KEY_PACKAGE_LABEL, hash_ref)
    }

    fn psk<
        PskBundle: traits::PskBundle<{ CURRENT_VERSION }>,
        PskId: traits::PskId<{ CURRENT_VERSION }>,
    >(
        &self,
        psk_id: &PskId,
    ) -> Result<Option<PskBundle>, Self::Error> {
        self.read_val::<{ CURRENT_VERSION }, _>(PSK_LABEL, psk_id)
    }

    // ═══════════════════════════════════════════════════════════
    // E. DELETERS — GROUP STATE
    // ═══════════════════════════════════════════════════════════

    fn remove_proposal<
        GroupId: traits::GroupId<{ CURRENT_VERSION }>,
        ProposalRef: traits::ProposalRef<{ CURRENT_VERSION }>,
    >(
        &self,
        group_id: &GroupId,
        proposal_ref: &ProposalRef,
    ) -> Result<(), Self::Error> {
        let composite_key = (
            serde_json::to_value(group_id)
                .map_err(|e| SnapshotStorageError::Serialization(e.to_string()))?,
            serde_json::to_value(proposal_ref)
                .map_err(|e| SnapshotStorageError::Serialization(e.to_string()))?,
        );
        self.delete_val::<{ CURRENT_VERSION }>(QUEUED_PROPOSAL_LABEL, &composite_key)?;

        let ref_bytes = serde_json::to_vec(proposal_ref)
            .map_err(|e| SnapshotStorageError::Serialization(e.to_string()))?;
        self.remove_from_list::<{ CURRENT_VERSION }>(PROPOSAL_QUEUE_REFS_LABEL, group_id, ref_bytes)
    }

    fn delete_own_leaf_nodes<GroupId: traits::GroupId<{ CURRENT_VERSION }>>(
        &self,
        group_id: &GroupId,
    ) -> Result<(), Self::Error> {
        self.delete_val::<{ CURRENT_VERSION }>(OWN_LEAF_NODES_LABEL, group_id)
    }

    fn delete_group_config<GroupId: traits::GroupId<{ CURRENT_VERSION }>>(
        &self,
        group_id: &GroupId,
    ) -> Result<(), Self::Error> {
        self.delete_val::<{ CURRENT_VERSION }>(JOIN_CONFIG_LABEL, group_id)
    }

    fn delete_tree<GroupId: traits::GroupId<{ CURRENT_VERSION }>>(
        &self,
        group_id: &GroupId,
    ) -> Result<(), Self::Error> {
        self.delete_val::<{ CURRENT_VERSION }>(TREE_LABEL, group_id)
    }

    fn delete_confirmation_tag<GroupId: traits::GroupId<{ CURRENT_VERSION }>>(
        &self,
        group_id: &GroupId,
    ) -> Result<(), Self::Error> {
        self.delete_val::<{ CURRENT_VERSION }>(CONFIRMATION_TAG_LABEL, group_id)
    }

    fn delete_group_state<GroupId: traits::GroupId<{ CURRENT_VERSION }>>(
        &self,
        group_id: &GroupId,
    ) -> Result<(), Self::Error> {
        self.delete_val::<{ CURRENT_VERSION }>(GROUP_STATE_LABEL, group_id)
    }

    fn delete_context<GroupId: traits::GroupId<{ CURRENT_VERSION }>>(
        &self,
        group_id: &GroupId,
    ) -> Result<(), Self::Error> {
        self.delete_val::<{ CURRENT_VERSION }>(GROUP_CONTEXT_LABEL, group_id)
    }

    fn delete_interim_transcript_hash<GroupId: traits::GroupId<{ CURRENT_VERSION }>>(
        &self,
        group_id: &GroupId,
    ) -> Result<(), Self::Error> {
        self.delete_val::<{ CURRENT_VERSION }>(INTERIM_TRANSCRIPT_HASH_LABEL, group_id)
    }

    fn delete_message_secrets<GroupId: traits::GroupId<{ CURRENT_VERSION }>>(
        &self,
        group_id: &GroupId,
    ) -> Result<(), Self::Error> {
        self.delete_val::<{ CURRENT_VERSION }>(MESSAGE_SECRETS_LABEL, group_id)
    }

    fn delete_all_resumption_psk_secrets<GroupId: traits::GroupId<{ CURRENT_VERSION }>>(
        &self,
        group_id: &GroupId,
    ) -> Result<(), Self::Error> {
        self.delete_val::<{ CURRENT_VERSION }>(RESUMPTION_PSK_STORE_LABEL, group_id)
    }

    fn delete_own_leaf_index<GroupId: traits::GroupId<{ CURRENT_VERSION }>>(
        &self,
        group_id: &GroupId,
    ) -> Result<(), Self::Error> {
        self.delete_val::<{ CURRENT_VERSION }>(OWN_LEAF_NODE_INDEX_LABEL, group_id)
    }

    fn delete_group_epoch_secrets<GroupId: traits::GroupId<{ CURRENT_VERSION }>>(
        &self,
        group_id: &GroupId,
    ) -> Result<(), Self::Error> {
        self.delete_val::<{ CURRENT_VERSION }>(EPOCH_SECRETS_LABEL, group_id)
    }

    fn clear_proposal_queue<
        GroupId: traits::GroupId<{ CURRENT_VERSION }>,
        ProposalRef: traits::ProposalRef<{ CURRENT_VERSION }>,
    >(
        &self,
        group_id: &GroupId,
    ) -> Result<(), Self::Error> {
        let refs: Vec<ProposalRef> =
            self.read_list::<{ CURRENT_VERSION }, _>(PROPOSAL_QUEUE_REFS_LABEL, group_id)?;
        for prop_ref in &refs {
            let composite_key = (
                serde_json::to_value(group_id)
                    .map_err(|e| SnapshotStorageError::Serialization(e.to_string()))?,
                serde_json::to_value(prop_ref)
                    .map_err(|e| SnapshotStorageError::Serialization(e.to_string()))?,
            );
            self.delete_val::<{ CURRENT_VERSION }>(QUEUED_PROPOSAL_LABEL, &composite_key)?;
        }
        self.delete_val::<{ CURRENT_VERSION }>(PROPOSAL_QUEUE_REFS_LABEL, group_id)
    }

    // ═══════════════════════════════════════════════════════════
    // F. DELETERS — CRYPTO OBJECTS
    // ═══════════════════════════════════════════════════════════

    fn delete_signature_key_pair<
        SignaturePublicKey: traits::SignaturePublicKey<{ CURRENT_VERSION }>,
    >(
        &self,
        public_key: &SignaturePublicKey,
    ) -> Result<(), Self::Error> {
        self.delete_val::<{ CURRENT_VERSION }>(SIGNATURE_KEY_PAIR_LABEL, public_key)
    }

    fn delete_encryption_key_pair<EncryptionKey: traits::EncryptionKey<{ CURRENT_VERSION }>>(
        &self,
        public_key: &EncryptionKey,
    ) -> Result<(), Self::Error> {
        self.delete_val::<{ CURRENT_VERSION }>(ENCRYPTION_KEY_PAIR_LABEL, public_key)
    }

    fn delete_encryption_epoch_key_pairs<
        GroupId: traits::GroupId<{ CURRENT_VERSION }>,
        EpochKey: traits::EpochKey<{ CURRENT_VERSION }>,
    >(
        &self,
        group_id: &GroupId,
        epoch: &EpochKey,
        leaf_index: u32,
    ) -> Result<(), Self::Error> {
        let storage_key = build_epoch_key::<{ CURRENT_VERSION }>(group_id, epoch, leaf_index)?;
        self.kv_delete(&storage_key);
        Ok(())
    }

    fn delete_key_package<KeyPackageRef: traits::HashReference<{ CURRENT_VERSION }>>(
        &self,
        hash_ref: &KeyPackageRef,
    ) -> Result<(), Self::Error> {
        self.delete_val::<{ CURRENT_VERSION }>(KEY_PACKAGE_LABEL, hash_ref)
    }

    fn delete_psk<PskKey: traits::PskId<{ CURRENT_VERSION }>>(
        &self,
        psk_id: &PskKey,
    ) -> Result<(), Self::Error> {
        self.delete_val::<{ CURRENT_VERSION }>(PSK_LABEL, psk_id)
    }
}

// ═══════════════════════════════════════════════════════════════
// SNAPSHOT OPENMLS PROVIDER (crypto + snapshot storage)
// ═══════════════════════════════════════════════════════════════

pub struct SnapshotOpenMlsProvider {
    crypto: crate::hybrid_crypto::HybridCrypto,
    storage: SnapshotStorageProvider,
}

impl SnapshotOpenMlsProvider {
    pub fn new(storage: SnapshotStorageProvider) -> Self {
        Self {
            crypto: crate::hybrid_crypto::HybridCrypto::new(),
            storage,
        }
    }

    /// Extract the storage provider for diffing.
    pub fn into_storage(self) -> SnapshotStorageProvider {
        self.storage
    }
}

impl OpenMlsProvider for SnapshotOpenMlsProvider {
    type CryptoProvider = crate::hybrid_crypto::HybridCrypto;
    type RandProvider = crate::hybrid_crypto::HybridCrypto;
    type StorageProvider = SnapshotStorageProvider;

    fn storage(&self) -> &Self::StorageProvider {
        &self.storage
    }

    fn crypto(&self) -> &Self::CryptoProvider {
        &self.crypto
    }

    fn rand(&self) -> &Self::RandProvider {
        &self.crypto
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    /// Every label this provider writes under is global or a group's, never
    /// both and never neither. A label in neither list would be kept by the
    /// Web `deleteGroup` and by a replacing external join for good, and
    /// nothing else would notice. Read from this file's source, so a label
    /// added later is checked without anyone listing it here.
    #[test]
    fn every_label_is_global_or_a_groups() {
        let labels: Vec<&[u8]> = include_str!("snapshot_storage.rs")
            .lines()
            .map(str::trim_start)
            .filter(|line| {
                ["const ", "pub const ", "pub(crate) const "].iter().any(|start| line.starts_with(start))
                    && line.contains("_LABEL: &[u8] = b\"")
            })
            .filter_map(|line| line.split('"').nth(1))
            .map(str::as_bytes)
            .collect();
        assert!(labels.len() >= GROUP_LABELS.len() + 4, "found {} labels", labels.len());
        for label in labels {
            let global = crate::encrypted_db::is_global_key(label);
            let group = GROUP_LABELS.contains(&label);
            assert!(global != group, "{}: global {global}, group {group}", String::from_utf8_lossy(label));
        }
    }

    /// `forget_group` takes every entry of the group out, wipes nothing
    /// else, and the snapshot written back deletes exactly what it took.
    #[test]
    fn forgetting_a_group_deletes_its_entries_alone() {
        let key = |label: &[u8], id: &[u8]| {
            let mut key = label.to_vec();
            key.extend(serde_json::to_vec(&openmls::prelude::GroupId::from_slice(id)).unwrap());
            key.extend(CURRENT_VERSION.to_be_bytes());
            key
        };
        let group_key = key(EPOCH_KEY_PAIRS_LABEL, b"group");
        let longer_key = key(EPOCH_KEY_PAIRS_LABEL, b"group-2");
        let global_key = key(SIGNATURE_KEY_PAIR_LABEL, b"group");
        let provider = SnapshotStorageProvider::from_entries(vec![
            (group_key.clone(), b"a".to_vec()),
            (longer_key.clone(), b"b".to_vec()),
            (global_key.clone(), b"c".to_vec()),
        ]);

        provider.forget_group(b"group");

        let updates = provider.into_updates();
        assert!(updates.upserts.is_empty());
        assert_eq!(updates.deletes, vec![group_key]);
    }

    #[test]
    fn unchanged_snapshot_has_no_updates() {
        let provider =
            SnapshotStorageProvider::from_entries(vec![(b"key".to_vec(), b"value".to_vec())]);

        let updates = provider.into_updates();
        assert!(updates.upserts.is_empty());
        assert!(updates.deletes.is_empty());
    }

    #[test]
    fn snapshot_reads_its_own_writes_and_deletes() {
        let provider = SnapshotStorageProvider::from_entries(Vec::new());

        provider.kv_write(b"key".to_vec(), b"value".to_vec());
        assert_eq!(provider.kv_read(b"key"), Some(Zeroizing::new(b"value".to_vec())));

        provider.kv_delete(b"key");
        assert_eq!(provider.kv_read(b"key"), None);
    }

    #[test]
    fn snapshot_reports_upserts_and_deletes() {
        let provider = SnapshotStorageProvider::from_entries(vec![
            (b"changed".to_vec(), b"old".to_vec()),
            (b"deleted".to_vec(), b"old".to_vec()),
        ]);
        provider.kv_write(b"changed".to_vec(), b"new".to_vec());
        provider.kv_write(b"created".to_vec(), b"new".to_vec());
        provider.kv_delete(b"deleted");

        let mut updates = provider.into_updates();
        updates.upserts.sort_by(|left, right| left.0.cmp(&right.0));
        updates.deletes.sort();

        assert_eq!(
            updates.upserts,
            vec![
                (b"changed".to_vec(), b"new".to_vec()),
                (b"created".to_vec(), b"new".to_vec()),
            ]
        );
        assert_eq!(updates.deletes, vec![b"deleted".to_vec()]);
    }

    /// The read path must keep plaintext inside a wiping wrapper.
    ///
    /// Zeroization is not observable from a test. The wipe happens in a `Drop`
    /// on memory the allocator is then free to hand out again, so an assertion
    /// about it would be an assertion about freed memory — undefined behaviour
    /// to read, and a false pass the moment the allocator reuses the page. What
    /// CAN be pinned is the shape of the code that makes the wipe happen; the
    /// manifest test in `utils.rs` guards its invariant the same way and for
    /// the same reason.
    ///
    /// Two properties, both of them things a refactor reverses without
    /// noticing:
    ///
    /// 1. `kv_read` returns the wrapper. Widen it back to a bare `Vec<u8>` and
    ///    all five call sites go back to dropping a plaintext copy unwiped.
    /// 2. Every decoded item list in this file sits inside `Zeroizing<…>`.
    ///    Those are the elements in `append_to_list`, `read_list` and
    ///    `remove_from_list`. The wrapper around the *value* does not reach
    ///    them: deserializing allocates fresh buffers, and those are what
    ///    hold the plaintext once the value is decoded.
    ///
    /// Both needles are assembled at run time on purpose. Written as literals
    /// they would appear in this file, and the test would match its own source
    /// — passing with the code it guards deleted. The cost is a rule for
    /// anyone editing this file: prose naming the item-list type has to name
    /// the wrapped form, or check 2 reads it as a violation.
    #[test]
    fn the_read_path_keeps_plaintext_wrapped() {
        let source = include_str!("snapshot_storage.rs");
        let wrapper = format!("{}<", "Zeroizing");
        let items = format!("Vec<{}>", "Vec<u8>");

        let signature = format!("fn kv_read(&self, key: &[u8]) -> Option<{wrapper}Vec<u8>>>");
        assert!(
            source.contains(&signature),
            "`kv_read` no longer reads `{signature}`. It hands a COPY of MLS key \
             material to its callers; unwrapped, that copy is dropped without a \
             wipe and the plaintext stays in freed heap memory.",
        );

        let mut from = 0;
        let mut seen = 0;
        while let Some(offset) = source[from..].find(&items) {
            let at = from + offset;
            assert!(
                source[..at].ends_with(&wrapper),
                "`{items}` appears outside `{wrapper}…>` at byte {at}. Its \
                 elements are decoded plaintext list items — dropped unwrapped, \
                 nothing wipes them.",
            );
            seen += 1;
            from = at + items.len();
        }

        // A count, because every other assertion here is vacuously true on a
        // file where the three lists have been renamed out of existence.
        assert_eq!(
            seen, 3,
            "expected the three decoded item lists (`append_to_list`, \
             `read_list`, `remove_from_list`), found {seen}. A new one needs \
             the same wrapper; a removed one needs this count moved.",
        );
    }
}
