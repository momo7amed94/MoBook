//! Disabled synthetic-roster admission source. In-memory fixture of what a
//! verified server/roster would supply. It is NOT a trust implementation:
//! nothing here verifies signed device records or talks to a server.
use super::mobook_bridge::TrustedAdmissions;
use super::mobook_private::{AcceptedReceipt,Admission,AdmissionLifetime,SenderEnvelope};
use crate::encrypted_db::mobook_journal::Owner;
use std::{collections::{HashMap,HashSet},sync::Mutex};
#[derive(Clone)]
pub(crate) struct DeviceRecord {pub generation:i64,pub key:Vec<u8>,pub credential:Vec<u8>,pub revoked:bool}
#[derive(Clone)]
pub(crate) struct Delivery {pub sender:Owner,pub epoch:i64,pub position:i64,pub policy:String,pub ciphertext_digest:Vec<u8>}
#[derive(Default)]
struct State {
    devices:HashMap<(String,String),DeviceRecord>,
    members:HashMap<Vec<u8>,(i64,String,HashSet<String>)>, // group -> (epoch,policy,accounts)
    next_pos:HashMap<Vec<u8>,i64>,
    sent:HashMap<(Vec<u8>,String),i64>,
    deliveries:HashMap<(Vec<u8>,String),Delivery>,
    expires_unix:u64,
}
pub(crate) struct SyntheticRoster {state:Mutex<State>}
impl SyntheticRoster {
    pub(crate) fn new(expires_unix:u64)->Self {let mut s=State::default();s.expires_unix=expires_unix;Self{state:Mutex::new(s)}}
    pub(crate) fn set_device(&self,account:&str,device:&str,r:DeviceRecord){self.state.lock().unwrap().devices.insert((account.into(),device.into()),r);}
    pub(crate) fn set_group(&self,g:&[u8],epoch:i64,policy:&str,accounts:&[&str]){self.state.lock().unwrap().members.insert(g.to_vec(),(epoch,policy.into(),accounts.iter().map(|a|a.to_string()).collect()));}
    pub(crate) fn record_delivery(&self,g:&[u8],id:&str,d:Delivery){self.state.lock().unwrap().deliveries.insert((g.to_vec(),id.into()),d);}
    fn live(s:&State,o:&Owner,g:&[u8])->Result<(DeviceRecord,i64,String),&'static str> {
        let d=s.devices.get(&(o.account.clone(),o.device.clone())).ok_or("roster-device-unknown")?;
        if d.revoked {return Err("roster-device-revoked");}
        if d.generation!=o.generation {return Err("roster-generation");}
        let (epoch,policy,m)=s.members.get(g).ok_or("roster-group-unknown")?;
        if !m.contains(&o.account) {return Err("roster-not-member");}
        Ok((d.clone(),*epoch,policy.clone()))
    }
    fn admission(s:&State,owner:&Owner,g:&[u8],epoch:i64,pos:i64,policy:String,d:&DeviceRecord)->Admission {
        Admission{lifetime:AdmissionLifetime::new(),owner:owner.clone(),group:g.to_vec(),epoch,position:pos,policy,expires_unix:s.expires_unix,signature_key:d.key.clone(),credential_identity:d.credential.clone()}
    }
}
impl TrustedAdmissions for SyntheticRoster {
    fn for_send(&self,owner:&Owner,g:&[u8],id:&str)->Result<Admission,&'static str> {
        let mut s=self.state.lock().unwrap();
        let (d,epoch,policy)=Self::live(&s,owner,g)?;
        // Server-assigned order: stable per operation id, strictly increasing per group.
        let key=(g.to_vec(),id.to_string());
        let pos=match s.sent.get(&key){Some(p)=>*p,None=>{let n=s.next_pos.entry(g.to_vec()).or_insert(0);*n+=1;let p=*n;s.sent.insert(key,p);p}};
        Ok(Self::admission(&s,owner,g,epoch,pos,policy,&d))
    }
    fn for_receive(&self,owner:&Owner,g:&[u8],id:&str)->Result<(Admission,SenderEnvelope),&'static str> {
        let s=self.state.lock().unwrap();
        let (_me,epoch,policy)=Self::live(&s,owner,g)?;
        let del=s.deliveries.get(&(g.to_vec(),id.to_string())).ok_or("roster-delivery-unknown")?;
        let (sd,_,_)=Self::live(&s,&del.sender,g)?;
        if del.epoch!=epoch||del.policy!=policy {return Err("roster-stale-delivery");}
        let a=Self::admission(&s,owner,g,del.epoch,del.position,del.policy.clone(),&sd);
        Ok((a,SenderEnvelope{owner:del.sender.clone(),group:g.to_vec(),id:id.into(),epoch:del.epoch,position:del.position,policy:del.policy.clone()}))
    }
    fn for_receipt(&self,owner:&Owner,g:&[u8],id:&str)->Result<(Admission,AcceptedReceipt),&'static str> {
        let s=self.state.lock().unwrap();
        let (d,epoch,policy)=Self::live(&s,owner,g)?;
        let del=s.deliveries.get(&(g.to_vec(),id.to_string())).ok_or("roster-delivery-unknown")?;
        if del.sender!=*owner {return Err("roster-receipt-not-sender");}
        if del.epoch!=epoch||del.policy!=policy {return Err("roster-stale-delivery");}
        let a=Self::admission(&s,owner,g,del.epoch,del.position,policy,&d);
        Ok((a,AcceptedReceipt{owner:owner.clone(),group:g.to_vec(),id:id.into(),epoch:del.epoch,position:del.position,policy:del.policy.clone(),ciphertext_digest:del.ciphertext_digest.clone()}))
    }
}
#[cfg(test)]
mod tests {
    use super::*;
    fn o(a:&str,gn:i64)->Owner{Owner{account:format!("{a}-account"),device:format!("{a}-device"),generation:gn}}
    fn dev(k:u8,gn:i64)->DeviceRecord{DeviceRecord{generation:gn,key:vec![k;32],credential:vec![k],revoked:false}}
    fn fixture()->SyntheticRoster {
        let r=SyntheticRoster::new(u64::MAX);
        r.set_device("alice-account","alice-device",dev(1,1));r.set_device("bob-account","bob-device",dev(2,1));
        r.set_group(b"g",1,"p1",&["alice-account","bob-account"]);r
    }
    fn delivery(pos:i64)->Delivery{Delivery{sender:o("alice",1),epoch:1,position:pos,policy:"p1".into(),ciphertext_digest:vec![9;32]}}
    #[test] fn mobook_v1_roster_send_order_and_membership() {
        let r=fixture();
        let a1=r.for_send(&o("alice",1),b"g","operation_1").unwrap();
        let a2=r.for_send(&o("alice",1),b"g","operation_2").unwrap();
        assert_eq!((a1.position,a2.position),(1,2));
        assert_eq!(r.for_send(&o("alice",1),b"g","operation_1").unwrap().position,1); // stable on retry
        assert_eq!(r.for_send(&o("carol",1),b"g","x").err(),Some("roster-device-unknown"));
        assert_eq!(r.for_send(&o("alice",1),b"other","x").err(),Some("roster-group-unknown"));
        r.set_group(b"g",2,"p1",&["alice-account"]); // bob removed
        assert_eq!(r.for_send(&o("bob",1),b"g","y").err(),Some("roster-not-member"));
        assert_eq!(r.for_send(&o("alice",1),b"g","z").unwrap().epoch,2);
    }
    #[test] fn mobook_v1_roster_device_revoked_and_generation_bump() {
        let r=fixture();
        assert_eq!(r.for_send(&o("alice",2),b"g","a").err(),Some("roster-generation"));
        r.set_device("alice-account","alice-device",dev(1,2));
        assert_eq!(r.for_send(&o("alice",1),b"g","a").err(),Some("roster-generation"));
        assert!(r.for_send(&o("alice",2),b"g","a").is_ok());
        let mut d=dev(1,2);d.revoked=true;r.set_device("alice-account","alice-device",d);
        assert_eq!(r.for_send(&o("alice",2),b"g","b").err(),Some("roster-device-revoked"));
    }
    #[test] fn mobook_v1_roster_receive_requires_fresh_delivery_and_live_sender() {
        let r=fixture();
        assert_eq!(r.for_receive(&o("bob",1),b"g","m1").err(),Some("roster-delivery-unknown"));
        r.record_delivery(b"g","m1",delivery(5));
        let (a,e)=r.for_receive(&o("bob",1),b"g","m1").unwrap();
        assert_eq!((a.position,e.position,e.owner.account.as_str(),a.signature_key[0]),(5,5,"alice-account",1)); // sender's key, server position
        r.set_group(b"g",2,"p1",&["alice-account","bob-account"]);
        assert_eq!(r.for_receive(&o("bob",1),b"g","m1").err(),Some("roster-stale-delivery"));
        r.set_group(b"g",1,"p1",&["alice-account","bob-account"]);
        let mut d=dev(1,1);d.revoked=true;r.set_device("alice-account","alice-device",d);
        assert_eq!(r.for_receive(&o("bob",1),b"g","m1").err(),Some("roster-device-revoked"));
    }
    #[test] fn mobook_v1_roster_receipt_only_for_sender_and_confirmed_delivery() {
        let r=fixture();
        assert_eq!(r.for_receipt(&o("alice",1),b"g","m1").err(),Some("roster-delivery-unknown"));
        r.record_delivery(b"g","m1",delivery(3));
        let (_a,rc)=r.for_receipt(&o("alice",1),b"g","m1").unwrap();
        assert_eq!((rc.position,rc.ciphertext_digest[0]),(3,9));
        assert_eq!(r.for_receipt(&o("bob",1),b"g","m1").err(),Some("roster-receipt-not-sender"));
    }
    mod mls {
        use super::*;
        use super::super::super::*;
        use super::super::super::mobook_bridge::{BridgeOp,BridgeReply,BridgeRequest,PrivateRegistry};
        use super::super::super::mobook_private::PrivateNativeScope;
        use crate::api::keys::{serialize_signer,MlsSignatureKeyPair};
        use std::sync::Arc;
        const SUITE:MlsCiphersuite=MlsCiphersuite::Mls128DhkemX25519Aes128gcmSha256Ed25519;
        fn caps()->MlsCapabilities {MlsCapabilities{versions:vec![1],ciphersuites:vec![1],extensions:vec![],proposals:vec![],credentials:vec![1]}}
        fn rq(c:&[u8],op:BridgeOp)->BridgeRequest{BridgeRequest{version:1,conversation:c.to_vec(),op}}
        #[test] fn mobook_v1_registry_with_roster_real_mls() {
            futures::executor::block_on(async {
                let a=MlsEngine::create(":memory:".into(),vec![0x5a;32]).await.unwrap();
                let b=MlsEngine::create(":memory:".into(),vec![0x6b;32]).await.unwrap();
                let ak=MlsSignatureKeyPair::generate(SUITE).unwrap();let bk=MlsSignatureKeyPair::generate(SUITE).unwrap();
                let asg=serialize_signer(SUITE,ak.private_key(),ak.public_key()).unwrap();
                let bsg=serialize_signer(SUITE,bk.private_key(),bk.public_key()).unwrap();
                let gid=a.create_group_with_builder(MlsGroupConfig::default_config(SUITE),asg.clone(),b"alice".to_vec(),ak.public_key(),None,None,None,None,Some(caps()),None).await.unwrap().group_id;
                let kp=b.create_key_package_with_options(SUITE,bsg.clone(),b"bob".to_vec(),bk.public_key(),KeyPackageOptions{lifetime_seconds:None,last_resort:false,capabilities:Some(caps()),leaf_node_extensions:None,key_package_extensions:None},None).await.unwrap().key_package_bytes;
                let w=a.add_members(gid.clone(),asg.clone(),vec![kp]).await.unwrap().welcome;
                b.join_group_from_welcome(MlsGroupConfig::default_config(SUITE),w,None,bsg.clone()).await.unwrap();
                let roster=Arc::new(SyntheticRoster::new(u64::MAX));
                roster.set_device("alice-account","alice-device",DeviceRecord{generation:1,key:ak.public_key(),credential:b"alice".to_vec(),revoked:false});
                roster.set_device("bob-account","bob-device",DeviceRecord{generation:1,key:bk.public_key(),credential:b"bob".to_vec(),revoked:false});
                roster.set_group(&gid,1,"p1",&["alice-account","bob-account"]);
                let (ao,bo)=(o("alice",1),o("bob",1));
                let ra=PrivateRegistry::new(ao.clone(),roster.clone());let rb=PrivateRegistry::new(bo.clone(),roster.clone());
                ra.register(PrivateNativeScope::adopt(a,ao.clone(),gid.clone(),asg).unwrap(),gid.clone()).await.unwrap();
                rb.register(PrivateNativeScope::adopt(b,bo.clone(),gid.clone(),bsg).unwrap(),gid.clone()).await.unwrap();
                let id="operation_12345678";let text="مرحبا بالعالم".as_bytes().to_vec();
                let wire=match ra.handle(rq(&gid,BridgeOp::Send{id:id.into(),text:text.clone()})).await.unwrap(){BridgeReply::Wire(w)=>w,_=>panic!()};
                // no delivery recorded yet: receive and receipt refuse
                assert_eq!(rb.handle(rq(&gid,BridgeOp::Receive{id:id.into(),wire:wire.clone()})).await.err(),Some("roster-delivery-unknown"));
                assert_eq!(ra.handle(rq(&gid,BridgeOp::Receipt{id:id.into(),text:text.clone()})).await.err(),Some("roster-delivery-unknown"));
                let digest=crate::hybrid_crypto::HybridCrypto::new().hash(openmls_traits::types::HashType::Sha2_256,&wire).unwrap();
                roster.record_delivery(&gid,id,Delivery{sender:ao.clone(),epoch:1,position:1,policy:"p1".into(),ciphertext_digest:digest});
                assert!(matches!(ra.handle(rq(&gid,BridgeOp::Receipt{id:id.into(),text:text.clone()})).await.unwrap(),BridgeReply::Done));
                // revoked sender refused on receive
                let mut rev=DeviceRecord{generation:1,key:ak.public_key(),credential:b"alice".to_vec(),revoked:true};
                roster.set_device("alice-account","alice-device",rev.clone());
                assert_eq!(rb.handle(rq(&gid,BridgeOp::Receive{id:id.into(),wire:wire.clone()})).await.err(),Some("roster-device-revoked"));
                rev.revoked=false;roster.set_device("alice-account","alice-device",rev);
                match rb.handle(rq(&gid,BridgeOp::Receive{id:id.into(),wire:wire.clone()})).await.unwrap(){BridgeReply::Text(t)=>assert_eq!(t,text),_=>panic!()}
                // bob removed from roster: cannot receive again, cannot send
                roster.set_group(&gid,1,"p1",&["alice-account"]);
                assert_eq!(rb.handle(rq(&gid,BridgeOp::Receive{id:id.into(),wire})).await.err(),Some("roster-not-member"));
                assert_eq!(rb.handle(rq(&gid,BridgeOp::Send{id:"operation_87654321".into(),text:b"x".to_vec()})).await.err(),Some("roster-not-member"));
            });
        }
    }
}
