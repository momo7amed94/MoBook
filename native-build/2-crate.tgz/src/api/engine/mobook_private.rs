//! Disabled native engine adapter. No bridge export or shipping caller.
use super::*;
use crate::encrypted_db::mobook_journal::{Direction, Owner, Record};
use openmls_traits::{crypto::OpenMlsCrypto, types::HashType};
use zeroize::Zeroizing;
#[derive(Clone)]
pub(crate) struct AdmissionLifetime(std::sync::Arc<std::sync::RwLock<bool>>);
impl AdmissionLifetime {
    pub(crate) fn new()->Self {Self(std::sync::Arc::new(std::sync::RwLock::new(true)))}
    pub(crate) fn revoke(&self)->Result<(), &'static str> {*self.0.write().map_err(|_|"private-lifetime-lock")?=false;Ok(())}
    fn active(&self)->Result<std::sync::RwLockReadGuard<'_,bool>, &'static str> {
        let guard=self.0.read().map_err(|_|"private-lifetime-lock")?;
        if !*guard {return Err("private-admission-revoked");} Ok(guard)
    }
}

#[derive(Clone)]
pub(crate) struct Admission {
    pub owner: Owner,
    pub lifetime: AdmissionLifetime,
    pub group: Vec<u8>,
    pub epoch: i64,
    pub position: i64,
    pub policy: String,
    pub expires_unix: u64,
    /// Accepted current local or remote key, supplied by verified key admission.
    pub signature_key: Vec<u8>,
    pub credential_identity: Vec<u8>,
}
impl Admission {
    fn check(&self)->Result<(), &'static str> {
        let _active=self.lifetime.active()?;
        let now=SystemTime::now().duration_since(UNIX_EPOCH).map_err(|_|"private-clock")?.as_secs();
        if self.group.is_empty()||self.group.len()>256||self.epoch<0||self.position<0||self.policy.is_empty()||self.policy.len()>256||self.signature_key.len()!=32||self.credential_identity.is_empty()||self.credential_identity.len()>256||now>=self.expires_unix {return Err("private-admission-invalid");}
        Ok(())
    }
    fn context(&self,id:&str)->Result<Vec<u8>, &'static str> {
        if !(16..=128).contains(&id.len())||!id.bytes().all(|b|b.is_ascii_alphanumeric()||b==b'_'||b==b'-') {return Err("private-operation-id");}
        serde_json::to_vec(&("mobook-private-v1",&self.owner.account,&self.owner.device,self.owner.generation,&self.group,id,self.epoch,self.position,&self.policy)).map_err(|_|"private-context")
    }
}
/// Verified sender scope from the ordered envelope. Construction alone is not
/// verification. Must be matched to accepted peer key and current device grant.
#[derive(Clone)]
pub(crate) struct SenderEnvelope {
    pub owner:Owner,
    pub group:Vec<u8>,
    pub id:String,
    pub epoch:i64,
    pub position:i64,
    pub policy:String,
}
impl SenderEnvelope {
    fn aad(&self,a:&Admission,id:&str)->Result<Vec<u8>, &'static str> {
        if self.group!=a.group||self.id!=id||self.epoch!=a.epoch||self.position!=a.position||self.policy!=a.policy||self.owner.account.is_empty()||self.owner.account.len()>256||self.owner.device.is_empty()||self.owner.device.len()>256||!(1..=9007199254740990).contains(&self.owner.generation) {return Err("private-envelope-mismatch");}
        serde_json::to_vec(&("mobook-private-v1",&self.owner.account,&self.owner.device,self.owner.generation,&self.group,id,self.epoch,self.position,&self.policy)).map_err(|_|"private-context")
    }
}
fn hash(provider:&SnapshotOpenMlsProvider,domain:&str,context:&[u8],body:&[u8])->Result<Vec<u8>, &'static str> {
    // Canonical length-delimited JSON encoding. Standard SHA256 via existing
    // provider, not a new encryption or authentication construction.
    let material=Zeroizing::new(serde_json::to_vec(&(domain,context,body)).map_err(|_|"private-digest")?);
    provider.crypto().hash(HashType::Sha2_256,&material).map_err(|_|"private-digest")
}

/// Internal single-conversation lifecycle owner. It has no public bridge or
/// unrestricted engine getter. All peer/policy admission is still supplied by
/// a future verified adapter, never inferred here.
pub(crate) struct PrivateNativeScope {
    engine:MlsEngine,
    owner:Owner,
    group:Vec<u8>,
    lifetime:AdmissionLifetime,
    signer:Zeroizing<Vec<u8>>,
}
impl PrivateNativeScope {
    pub(crate) fn adopt(engine:MlsEngine,owner:Owner,group:Vec<u8>,signer:Vec<u8>)->Result<Self, &'static str> {
        let signer=Zeroizing::new(signer);
        signer_from_bytes(signer.to_vec()).map_err(|_|"private-signer-invalid")?;
        if group.is_empty()||group.len()>256 {return Err("private-group-invalid");}
        engine.db().map_err(|_|"private-closed")?.mobook_initialize(&owner)?;
        Ok(Self{engine,owner,group,lifetime:AdmissionLifetime::new(),signer})
    }
    fn admitted(&self,source:&Admission)->Result<Admission, &'static str> {
        {let _active=self.lifetime.active()?;}
        source.check()?;
        if source.owner!=self.owner||source.group!=self.group {return Err("private-scope-mismatch");}
        let mut scoped=source.clone();scoped.lifetime=self.lifetime.clone();Ok(scoped)
    }
    pub(crate) async fn prepare(&self,a:&Admission,id:&str,text:Vec<u8>)->Result<Record, &'static str> {
        let text=Zeroizing::new(text);
        let scoped=self.admitted(a)?;
        self.engine.mobook_prepare_text(&scoped,id,self.signer.to_vec(),text.to_vec()).await
    }
    pub(crate) async fn receive(&self,a:&Admission,id:&str,wire:Vec<u8>,envelope:&SenderEnvelope)->Result<Record, &'static str> {
        let scoped=self.admitted(a)?;self.engine.mobook_accept_text(&scoped,id,wire,envelope).await
    }
    pub(crate) async fn receipt(&self,r:&Record,receipt:&AcceptedReceipt)->Result<(), &'static str> {
        {let _active=self.lifetime.active()?;}
        if r.group!=self.group {return Err("private-scope-mismatch");}
        self.engine.mobook_accept_receipt(&self.owner,r,receipt,&self.lifetime).await
    }
    /// Guarded, journaled MLS Remove. Returns commit bytes for delivery; an exact
    /// retry with the same id and leaf returns the stored commit.
    #[cfg(test)]
    pub(crate) async fn remove(&self,a:&Admission,id:&str,leaf_index:u32)->Result<Vec<u8>, &'static str> {
        let scoped=self.admitted(a)?;
        {let _active=self.lifetime.active()?;}
        self.engine.mobook_prepare_remove(&scoped,id,self.signer.to_vec(),leaf_index).await.map(|r|r.payload.clone())
    }
    /// Remove the member the roster names by key and credential. The leaf index is
    /// derived from the MLS tree, never supplied by the caller.
    #[cfg(test)]
    pub(crate) async fn remove_device(&self,a:&Admission,id:&str,key:&[u8],credential:&[u8])->Result<Vec<u8>, &'static str> {
        let scoped=self.admitted(a)?;
        let leaf=self.engine.mobook_leaf_for(&scoped,key,credential).await?;
        self.remove(a,id,leaf).await
    }
    /// Blocked-pair / multi-device removal: every roster-named (key, credential)
    /// device is found in the MLS tree and all leaves go in ONE commit. Any
    /// unknown or ambiguous device refuses the whole request.
    #[cfg(test)]
    pub(crate) async fn remove_devices(&self,a:&Admission,id:&str,devices:&[(Vec<u8>,Vec<u8>)])->Result<(Vec<u8>,Vec<u32>), &'static str> {
        let scoped=self.admitted(a)?;
        if devices.is_empty()||devices.len()>64 {return Err("private-remove-invalid");}
        let mut leaves=Vec::new();
        for (k,c) in devices {leaves.push(self.engine.mobook_leaf_for(&scoped,k,c).await?);}
        {let _active=self.lifetime.active()?;}
        let commit=self.engine.mobook_prepare_remove_many(&scoped,id,self.signer.to_vec(),&leaves).await.map(|r|r.payload.clone())?;
        Ok((commit,leaves))
    }
    /// Exact retry by the leaves `remove_devices` returned. After the commit the
    /// devices are no longer in the tree, so the retry cannot look them up again.
    #[cfg(test)]
    pub(crate) async fn remove_leaves(&self,a:&Admission,id:&str,leaves:&[u32])->Result<Vec<u8>, &'static str> {
        let scoped=self.admitted(a)?;
        {let _active=self.lifetime.active()?;}
        self.engine.mobook_prepare_remove_many(&scoped,id,self.signer.to_vec(),leaves).await.map(|r|r.payload.clone())
    }
    /// Durable receipt for a journaled Remove commit (exact retry by leaves, then CAS).
    pub(crate) async fn receipt_remove(&self,a:&Admission,id:&str,leaves:&[u32],receipt:&AcceptedReceipt)->Result<(), &'static str> {
        let scoped=self.admitted(a)?;
        let rec={let (session,rec)=self.engine.staged_record(&scoped,id,leaves).await?;drop(session);rec};
        self.receipt(&rec,receipt).await
    }
    /// Staged removal: returns commit bytes to submit. Nothing merged yet.
    pub(crate) async fn stage_remove_leaves(&self,a:&Admission,id:&str,leaves:&[u32])->Result<Vec<u8>, &'static str> {
        let scoped=self.admitted(a)?;{let _active=self.lifetime.active()?;}
        self.engine.mobook_stage_remove_many(&scoped,id,self.signer.to_vec(),leaves).await.map(|r|r.payload.clone())
    }
    /// Server accepted: merge, then durable receipt.
    pub(crate) async fn finalize_staged(&self,a:&Admission,id:&str,leaves:&[u32],receipt:&AcceptedReceipt)->Result<(), &'static str> {
        let scoped=self.admitted(a)?;
        self.engine.mobook_finalize_staged(&scoped,id,leaves).await?;
        self.receipt_remove(a,id,leaves,receipt).await
    }
    /// Server rejected (another commit won): drop ours; caller then processes the winner.
    pub(crate) async fn discard_staged(&self,a:&Admission,id:&str,leaves:&[u32])->Result<(), &'static str> {
        let scoped=self.admitted(a)?;
        self.engine.mobook_discard_staged(&scoped,id,leaves).await
    }
    pub(crate) fn freeze(&self)->Result<(), &'static str> {self.lifetime.revoke()}
    pub(crate) async fn close(&self)->Result<(), &'static str> {
        self.freeze()?;self.engine.close().await.map_err(|_|"private-close")
    }
    pub(crate) async fn purge_and_close(&self)->Result<(), &'static str> {
        self.freeze()?;
        // Wait for the same operation lock as every MLS write. No cached handle
        // can start another scoped commit after freeze returns.
        {
            let _op=self.engine.op_lock.lock().await;
            self.engine.db().map_err(|_|"private-closed")?.mobook_purge_group(&self.owner,&self.group)?;
        }
        self.engine.close().await.map_err(|_|"private-close")
    }
}
impl Drop for PrivateNativeScope {
    fn drop(&mut self) {let _=self.lifetime.revoke();}
}

/// Parsed from an authenticated ordered-delivery response. Field validation is
/// not transport authentication; the disabled caller must provide both.
pub(crate) struct AcceptedReceipt {
    pub owner:Owner,
    pub group:Vec<u8>,
    pub id:String,
    pub epoch:i64,
    pub position:i64,
    pub policy:String,
    pub ciphertext_digest:Vec<u8>,
}
impl MlsEngine {
    pub(crate) async fn mobook_accept_receipt(&self,owner:&Owner,record:&Record,receipt:&AcceptedReceipt,lifetime:&AdmissionLifetime)->Result<(), &'static str> {
        let session=self.load_for_group(&record.group).await.map_err(|_|"private-group-unavailable")?;
        if receipt.owner!=*owner||receipt.group!=record.group||receipt.id!=record.id||receipt.epoch!=record.epoch||receipt.position!=record.position||receipt.policy!=record.policy {return Err("private-receipt-binding");}
        let digest=session.provider.crypto().hash(HashType::Sha2_256,&record.payload).map_err(|_|"private-digest")?;
        if digest!=receipt.ciphertext_digest {return Err("private-receipt-digest");}
        let encoded=serde_json::to_vec(&("mobook-receipt-v1",&owner.account,&owner.device,owner.generation,&receipt.group,&receipt.id,receipt.epoch,receipt.position,&receipt.policy,&receipt.ciphertext_digest)).map_err(|_|"private-receipt-encode")?;
        let _active=lifetime.active()?;
        self.db().map_err(|_|"private-closed")?.mobook_record_receipt(owner,record,&encoded)
    }
    pub(crate) async fn mobook_prepare_text(&self,a:&Admission,id:&str,signer:Vec<u8>,text:Vec<u8>)->Result<Record, &'static str> {
        let text=Zeroizing::new(text);a.check()?;
        let decoded=std::str::from_utf8(&text).map_err(|_|"private-text-invalid")?;
        if text.len()>65536||decoded.trim().is_empty() {return Err("private-text-invalid");}
        let context=a.context(id)?;
        let session=self.load_for_group(&a.group).await.map_err(|_|"private-group-unavailable")?;
        a.check()?;
        let scoped_context=serde_json::to_vec(&(&context,&a.signature_key,&a.credential_identity)).map_err(|_|"private-context")?;
        let digest=hash(&session.provider,"outgoing-request",&scoped_context,&text)?;
        let mut record=Record{group:a.group.clone(),id:id.into(),request_digest:digest,epoch:a.epoch,position:a.position,policy:a.policy.clone(),payload:vec![0]};
        let mut group=load_group(&a.group,&session).map_err(|_|"private-group-unavailable")?;
        if group.ciphersuite()!=openmls_traits::types::Ciphersuite::MLS_128_DHKEMX25519_AES128GCM_SHA256_Ed25519||group.epoch().as_u64()!=a.epoch as u64||group.pending_commit().is_some()||group.pending_proposals().next().is_some() {return Err("private-group-frozen");}
        let own=group.own_leaf_node().ok_or("private-leaf-missing")?;
        if own.signature_key().as_slice()!=a.signature_key||own.credential().serialized_content()!=a.credential_identity {return Err("private-identity-mismatch");}
        // Current group/identity checks precede cached send recovery too.
        // Lookup remains under the group lock, before consuming MLS randomness.
        if let Some(old)=self.db().map_err(|_|"private-closed")?.mobook_lookup(&a.owner,Direction::Outbox,&record)? {a.check()?;let _active=a.lifetime.active()?;return Ok(old);}
        let signer=signer_from_bytes(signer).map_err(|_|"private-signer-invalid")?;
        group.set_aad(context);
        let output=group.create_message(&session,&signer,&text).map_err(|_|"private-encrypt")?;
        record.payload=output.tls_serialize_detached().map_err(|_|"private-serialize")?;
        a.check()?;
        let OpSession{locks:_locks,provider}=session;
        // Revocation returns only after any already-started commit releases this
        // read guard. No new commit can pass after revoke has returned.
        let _active=a.lifetime.active()?;
        self.db().map_err(|_|"private-closed")?.mobook_atomic_commit(&a.owner,Direction::Outbox,&record,provider.into_storage().into_updates())?;
        Ok(record)
    }
    /// Journaled MLS Remove. Record epoch is the epoch BEFORE the commit. After the
    /// merge the group is at epoch+1, so an exact retry finds the stored commit.
    #[cfg(test)]
    pub(crate) async fn mobook_prepare_remove(&self,a:&Admission,id:&str,signer:Vec<u8>,leaf_index:u32)->Result<Record, &'static str> {
        self.mobook_prepare_remove_many(a,id,signer,&[leaf_index]).await
    }
    /// One commit removes every listed leaf (canonical sorted, no duplicates).
    #[cfg(test)]
    pub(crate) async fn mobook_prepare_remove_many(&self,a:&Admission,id:&str,signer:Vec<u8>,leaves:&[u32])->Result<Record, &'static str> {
        self.mobook_remove_impl(a,id,signer,leaves,false).await
    }
    /// Staged: the commit is created and journaled but NOT merged. The group
    /// keeps a pending commit (sends refuse) until finalize or discard.
    pub(crate) async fn mobook_stage_remove_many(&self,a:&Admission,id:&str,signer:Vec<u8>,leaves:&[u32])->Result<Record, &'static str> {
        self.mobook_remove_impl(a,id,signer,leaves,true).await
    }
    async fn mobook_remove_impl(&self,a:&Admission,id:&str,signer:Vec<u8>,leaves:&[u32],staged:bool)->Result<Record, &'static str> {
        let mut leaves=leaves.to_vec();leaves.sort_unstable();leaves.dedup();
        if leaves.is_empty()||leaves.len()>64 {return Err("private-remove-invalid");}
        a.check()?;
        let context=a.context(id)?;
        let session=self.load_for_group(&a.group).await.map_err(|_|"private-group-unavailable")?;
        a.check()?;
        let scoped_context=serde_json::to_vec(&("remove",&context,&a.signature_key,&a.credential_identity)).map_err(|_|"private-context")?;
        let digest=hash(&session.provider,"remove-request",&scoped_context,&leaves.iter().flat_map(|l|l.to_be_bytes()).collect::<Vec<u8>>())?;
        let mut record=Record{group:a.group.clone(),id:id.into(),request_digest:digest,epoch:a.epoch,position:a.position,policy:a.policy.clone(),payload:vec![0]};
        let mut group=load_group(&a.group,&session).map_err(|_|"private-group-unavailable")?;
        if group.ciphersuite()!=openmls_traits::types::Ciphersuite::MLS_128_DHKEMX25519_AES128GCM_SHA256_Ed25519||group.pending_proposals().next().is_some() {return Err("private-group-frozen");}
        let current=group.epoch().as_u64();
        if group.pending_commit().is_some() {
            // Only a staged exact retry may see a pending commit.
            if !staged||current!=a.epoch as u64 {return Err("private-group-frozen");}
            if let Some(old)=self.db().map_err(|_|"private-closed")?.mobook_lookup(&a.owner,Direction::Outbox,&record)? {a.check()?;let _active=a.lifetime.active()?;return Ok(old);}
            return Err("private-group-frozen");
        }
        let own=group.own_leaf_node().ok_or("private-leaf-missing")?;
        if own.signature_key().as_slice()!=a.signature_key||own.credential().serialized_content()!=a.credential_identity {return Err("private-identity-mismatch");}
        if current==(a.epoch as u64)+1 {
            if let Some(old)=self.db().map_err(|_|"private-closed")?.mobook_lookup(&a.owner,Direction::Outbox,&record)? {a.check()?;let _active=a.lifetime.active()?;return Ok(old);}
            return Err("private-group-frozen");
        }
        if current!=a.epoch as u64 {return Err("private-group-frozen");}
        if leaves.contains(&group.own_leaf_index().u32()) {return Err("private-remove-self");}
        let signer=signer_from_bytes(signer).map_err(|_|"private-signer-invalid")?;
        let (commit,_w,_gi)=group.remove_members(&session,&signer,&leaves.iter().map(|l|LeafNodeIndex::new(*l)).collect::<Vec<_>>()).map_err(|_|"private-remove")?;
        if !staged {group.merge_pending_commit(&session).map_err(|_|"private-remove")?;}
        record.payload=commit.tls_serialize_detached().map_err(|_|"private-serialize")?;
        a.check()?;
        let OpSession{locks:_locks,provider}=session;
        let _active=a.lifetime.active()?;
        self.db().map_err(|_|"private-closed")?.mobook_atomic_commit(&a.owner,Direction::Outbox,&record,provider.into_storage().into_updates())?;
        Ok(record)
    }
    /// Leaf index of the single current member whose MLS signature key and
    /// credential identity both equal the roster-supplied values.
    pub(crate) async fn mobook_leaf_for(&self,a:&Admission,key:&[u8],credential:&[u8])->Result<u32, &'static str> {
        a.check()?;
        if key.len()!=32||credential.is_empty()||credential.len()>256 {return Err("private-member-invalid");}
        let session=self.load_for_group(&a.group).await.map_err(|_|"private-group-unavailable")?;
        let group=load_group(&a.group,&session).map_err(|_|"private-group-unavailable")?;
        let mut found=group.members().filter(|m|m.signature_key.as_slice()==key&&m.credential.serialized_content()==credential).map(|m|m.index.u32());
        let first=found.next().ok_or("private-member-unknown")?;
        if found.next().is_some() {return Err("private-member-ambiguous");}
        Ok(first)
    }
    /// Merge a staged commit once the server accepted it. Idempotent if already merged.
    pub(crate) async fn mobook_finalize_staged(&self,a:&Admission,id:&str,leaves:&[u32])->Result<(), &'static str> {
        a.check()?;
        let (session,record)=self.staged_record(a,id,leaves).await?;
        let mut group=load_group(&a.group,&session).map_err(|_|"private-group-unavailable")?;
        if group.pending_commit().is_none() {return Ok(());}
        group.merge_pending_commit(&session).map_err(|_|"private-remove")?;
        a.check()?;
        let OpSession{locks:_locks,provider}=session;
        let _active=a.lifetime.active()?;
        self.db().map_err(|_|"private-closed")?.mobook_atomic_snapshot(&a.owner,&a.group,provider.into_storage().into_updates(),None)?;
        drop(record);Ok(())
    }
    /// Server rejected the staged commit: clear it and delete its unreceipted row.
    pub(crate) async fn mobook_discard_staged(&self,a:&Admission,id:&str,leaves:&[u32])->Result<(), &'static str> {
        a.check()?;
        let (session,record)=self.staged_record(a,id,leaves).await?;
        let group=load_group(&a.group,&session).map_err(|_|"private-group-unavailable")?;
        let mut group=group;
        if group.pending_commit().is_none() {
            // Superseded: a winning commit already advanced the group past the staged epoch.
            if group.epoch().as_u64()<=a.epoch as u64 {return Err("private-no-staged-commit");}
            a.check()?;
            let _active=a.lifetime.active()?;
            return self.db().map_err(|_|"private-closed")?.mobook_atomic_snapshot(&a.owner,&a.group,crate::encrypted_db::StorageUpdates{upserts:vec![],deletes:vec![]},Some(&record));
        }
        group.clear_pending_commit(session.storage()).map_err(|_|"private-remove")?;
        a.check()?;
        let OpSession{locks:_locks,provider}=session;
        let _active=a.lifetime.active()?;
        self.db().map_err(|_|"private-closed")?.mobook_atomic_snapshot(&a.owner,&a.group,provider.into_storage().into_updates(),Some(&record))
    }
    async fn staged_record(&self,a:&Admission,id:&str,leaves:&[u32])->Result<(OpSession<'_>,Record), &'static str> {
        let mut leaves=leaves.to_vec();leaves.sort_unstable();leaves.dedup();
        let context=a.context(id)?;
        let session=self.load_for_group(&a.group).await.map_err(|_|"private-group-unavailable")?;
        let scoped_context=serde_json::to_vec(&("remove",&context,&a.signature_key,&a.credential_identity)).map_err(|_|"private-context")?;
        let digest=hash(&session.provider,"remove-request",&scoped_context,&leaves.iter().flat_map(|l|l.to_be_bytes()).collect::<Vec<u8>>())?;
        let probe=Record{group:a.group.clone(),id:id.into(),request_digest:digest,epoch:a.epoch,position:a.position,policy:a.policy.clone(),payload:vec![0]};
        let stored=self.db().map_err(|_|"private-closed")?.mobook_lookup(&a.owner,Direction::Outbox,&probe)?.ok_or("private-no-staged-commit")?;
        Ok((session,stored))
    }
    pub(crate) async fn mobook_accept_text(&self,a:&Admission,id:&str,wire:Vec<u8>, envelope:&SenderEnvelope)->Result<Record, &'static str> {
        a.check()?;if wire.is_empty()||wire.len()>131072 {return Err("private-wire-invalid");}
        let context=a.context(id)?;
        let expected_sender_aad=envelope.aad(a,id)?;
        let session=self.load_for_group(&a.group).await.map_err(|_|"private-group-unavailable")?;a.check()?;
        if expected_sender_aad.is_empty()||expected_sender_aad.len()>4096 {return Err("private-aad-invalid");}
        let scoped_context=serde_json::to_vec(&(&context,&expected_sender_aad,&a.signature_key,&a.credential_identity)).map_err(|_|"private-context")?;
        let digest=hash(&session.provider,"incoming-wire",&scoped_context,&wire)?;
        let mut record=Record{group:a.group.clone(),id:id.into(),request_digest:digest,epoch:a.epoch,position:a.position,policy:a.policy.clone(),payload:vec![0]};
        let mut group=load_group(&a.group,&session).map_err(|_|"private-group-unavailable")?;
        if group.ciphersuite()!=openmls_traits::types::Ciphersuite::MLS_128_DHKEMX25519_AES128GCM_SHA256_Ed25519||group.epoch().as_u64()!=a.epoch as u64||group.pending_commit().is_some()||group.pending_proposals().next().is_some() {return Err("private-group-frozen");}
        if let Some(old)=self.db().map_err(|_|"private-closed")?.mobook_lookup(&a.owner,Direction::Inbox,&record)? {a.check()?;let _active=a.lifetime.active()?;return Ok(old);}
        let input=MlsMessageIn::tls_deserialize_exact_bytes(&wire).map_err(|_|"private-wire-invalid")?.try_into_protocol_message().map_err(|_|"private-wire-invalid")?;
        if input.content_type()!=ContentType::Application {return Err("private-application-only");}
        let processed=group.process_message(&session,input).map_err(|_|"private-decrypt")?;
        let sender=match processed.sender(){Sender::Member(index)=>*index,_=>return Err("private-sender-invalid")};
        let member=group.members().find(|m|m.index==sender).ok_or("private-sender-invalid")?;
        if member.signature_key!=a.signature_key||member.credential.serialized_content()!=a.credential_identity {return Err("private-identity-mismatch");}
        // Envelope admission must validate this sender context independently.
        if expected_sender_aad.is_empty()||expected_sender_aad.len()>4096||processed.aad()!=expected_sender_aad {return Err("private-aad-mismatch");}
        let plain=Zeroizing::new(match processed.into_content(){ProcessedMessageContent::ApplicationMessage(m)=>m.into_bytes(),_=>return Err("private-application-only")});
        let decoded=std::str::from_utf8(&plain).map_err(|_|"private-text-invalid")?;
        if plain.len()>65536||decoded.trim().is_empty() {return Err("private-text-invalid");}
        record.payload=plain.to_vec();a.check()?;
        let OpSession{locks:_locks,provider}=session;
        // Revocation returns only after any already-started commit releases this
        // read guard. No new commit can pass after revoke has returned.
        let _active=a.lifetime.active()?;
        self.db().map_err(|_|"private-closed")?.mobook_atomic_commit(&a.owner,Direction::Inbox,&record,provider.into_storage().into_updates())?;
        Ok(record)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::api::keys::{serialize_signer,MlsSignatureKeyPair};
    const SUITE:MlsCiphersuite=MlsCiphersuite::Mls128DhkemX25519Aes128gcmSha256Ed25519;
    fn caps()->MlsCapabilities {MlsCapabilities{versions:vec![1],ciphersuites:vec![1],extensions:vec![],proposals:vec![],credentials:vec![1]}}
    #[test]
    fn mobook_v1_real_engine_bound_text_and_rejections() {
        futures::executor::block_on(async {
            let a=MlsEngine::create(":memory:".into(),vec![0x5a;32]).await.unwrap();
            let b=MlsEngine::create(":memory:".into(),vec![0x6b;32]).await.unwrap();
            let ak=MlsSignatureKeyPair::generate(SUITE).unwrap();
            let bk=MlsSignatureKeyPair::generate(SUITE).unwrap();
            let a_signer=serialize_signer(SUITE,ak.private_key(),ak.public_key()).unwrap();
            let b_signer=serialize_signer(SUITE,bk.private_key(),bk.public_key()).unwrap();
            let gid=a.create_group_with_builder(MlsGroupConfig::default_config(SUITE),a_signer.clone(),b"alice".to_vec(),ak.public_key(),None,None,None,None,Some(caps()),None).await.unwrap().group_id;
            let kp=b.create_key_package_with_options(SUITE,b_signer.clone(),b"bob".to_vec(),bk.public_key(),KeyPackageOptions{lifetime_seconds:None,last_resort:false,capabilities:Some(caps()),leaf_node_extensions:None,key_package_extensions:None},None).await.unwrap().key_package_bytes;
            let w=a.add_members(gid.clone(),a_signer.clone(),vec![kp]).await.unwrap().welcome;
            b.join_group_from_welcome(MlsGroupConfig::default_config(SUITE),w,None,b_signer).await.unwrap();

            let ao=Owner{account:"alice-account".into(),device:"alice-device".into(),generation:1};
            let bo=Owner{account:"bob-account".into(),device:"bob-device".into(),generation:1};
            a.db().unwrap().mobook_initialize(&ao).unwrap();b.db().unwrap().mobook_initialize(&bo).unwrap();
            let mut sa=Admission{lifetime:AdmissionLifetime::new(),owner:ao,group:gid.clone(),epoch:1,position:1,policy:"p1".into(),expires_unix:u64::MAX,signature_key:ak.public_key(),credential_identity:b"alice".to_vec()};
            let ra=Admission{lifetime:AdmissionLifetime::new(),owner:bo,group:gid.clone(),epoch:1,position:1,policy:"p1".into(),expires_unix:u64::MAX,signature_key:ak.public_key(),credential_identity:b"alice".to_vec()};
            let id="operation_12345678";
            let text="رسالة اختبار".as_bytes().to_vec();
            let sent=a.mobook_prepare_text(&sa,id,a_signer.clone(),text.clone()).await.unwrap();
            assert_eq!(sent.payload,a.mobook_prepare_text(&sa,id,a_signer.clone(),text.clone()).await.unwrap().payload);
            assert!(a.mobook_prepare_text(&sa,id,a_signer.clone(),b"changed".to_vec()).await.is_err());
            let provider=crate::hybrid_crypto::HybridCrypto::new();
            let mut receipt=AcceptedReceipt{owner:sa.owner.clone(),group:gid.clone(),id:id.into(),epoch:1,position:1,policy:"p1".into(),ciphertext_digest:provider.hash(HashType::Sha2_256,&sent.payload).unwrap()};
            receipt.position=2;assert!(a.mobook_accept_receipt(&sa.owner,&sent,&receipt,&sa.lifetime).await.is_err());receipt.position=1;
            receipt.ciphertext_digest[0]^=1;assert!(a.mobook_accept_receipt(&sa.owner,&sent,&receipt,&sa.lifetime).await.is_err());receipt.ciphertext_digest[0]^=1;
            a.mobook_accept_receipt(&sa.owner,&sent,&receipt,&sa.lifetime).await.unwrap();a.mobook_accept_receipt(&sa.owner,&sent,&receipt,&sa.lifetime).await.unwrap();
            assert!(a.db().unwrap().mobook_pending(&sa.owner,&gid,None,10).unwrap().is_empty());
            let envelope=SenderEnvelope{owner:sa.owner.clone(),group:gid.clone(),id:id.into(),epoch:1,position:1,policy:"p1".into()};
            let mut wrong=envelope.clone();wrong.owner.device="wrong-device".into();
            assert!(b.mobook_accept_text(&ra,id,sent.payload.clone(),&wrong).await.is_err());
            let received=b.mobook_accept_text(&ra,id,sent.payload.clone(),&envelope).await.unwrap();assert_eq!(received.payload,text);
            assert_eq!(b.mobook_accept_text(&ra,id,sent.payload.clone(),&envelope).await.unwrap().payload,text);
            assert!(b.mobook_accept_text(&ra,id,sent.payload.clone(),&wrong).await.is_err());
            assert!(b.mobook_accept_text(&ra,"operation_87654321",sent.payload.clone(),&envelope).await.is_err());
            sa.signature_key=vec![5;32];assert!(a.mobook_prepare_text(&sa,"operation_22222222",a_signer.clone(),text.clone()).await.is_err());
            sa.signature_key=ak.public_key();sa.expires_unix=0;assert!(a.mobook_prepare_text(&sa,"operation_22222222",a_signer.clone(),text.clone()).await.is_err());
            sa.expires_unix=u64::MAX;sa.epoch=2;assert!(a.mobook_prepare_text(&sa,"operation_22222222",a_signer.clone(),text.clone()).await.is_err());
            sa.epoch=1;assert!(a.mobook_prepare_text(&sa,"operation_22222222",a_signer.clone(),vec![0xff]).await.is_err());
            assert!(a.mobook_prepare_text(&sa,"operation_22222222",a_signer.clone(),vec![b'x';65537]).await.is_err());
            let lifetime=sa.lifetime.clone();lifetime.revoke().unwrap();
            assert!(a.mobook_prepare_text(&sa,"operation_22222222",a_signer.clone(),b"next".to_vec()).await.is_err());
            sa.lifetime=AdmissionLifetime::new();
            let next=a.mobook_prepare_text(&sa,"operation_22222222",a_signer.clone(),b"next".to_vec()).await.unwrap();
            assert_eq!(b.mobook_accept_text(&ra,"operation_22222222",next.payload.clone(),&SenderEnvelope{id:"operation_22222222".into(),..envelope}).await.unwrap().payload,b"next");
            let scope=PrivateNativeScope::adopt(a,sa.owner.clone(),gid.clone(),a_signer.clone()).unwrap();
            let mut mismatched=sa.clone();mismatched.owner.generation=2;
            assert!(scope.prepare(&mismatched,"operation_33333333",b"blocked".to_vec()).await.is_err());
            scope.freeze().unwrap();
            assert!(scope.prepare(&sa,"operation_33333333",b"blocked".to_vec()).await.is_err());
            scope.close().await.unwrap();scope.close().await.unwrap();
            let bscope=PrivateNativeScope::adopt(b,ra.owner.clone(),gid,a_signer).unwrap();
            bscope.purge_and_close().await.unwrap();
            assert!(bscope.receive(&ra,"operation_12345678",vec![1],&SenderEnvelope{owner:sa.owner.clone(),group:ra.group.clone(),id:"operation_12345678".into(),epoch:1,position:1,policy:"p1".into()}).await.is_err());

        });
    }
    fn admission(group:Vec<u8>,key:Vec<u8>,alice:bool)->Admission {
        Admission{lifetime:AdmissionLifetime::new(),owner:Owner{account:if alice{"alice-account"}else{"bob-account"}.into(),device:if alice{"alice-device"}else{"bob-device"}.into(),generation:1},group,epoch:1,position:1,policy:"p1".into(),expires_unix:u64::MAX,signature_key:key,credential_identity:b"alice".to_vec()}
    }
    fn sender_envelope(a:&Admission,id:&str)->SenderEnvelope {SenderEnvelope{owner:a.owner.clone(),group:a.group.clone(),id:id.into(),epoch:a.epoch,position:a.position,policy:a.policy.clone()}}
    #[test] fn mobook_v1_engine_crash_child() {
        let Ok(dir)=std::env::var("MOBOOK_V1_ENGINE_DIR") else {return;};
        futures::executor::block_on(async {
            let mode=std::env::var("MOBOOK_V1_ENGINE_MODE").unwrap();
            let (gid,signer,key):(Vec<u8>,Vec<u8>,Vec<u8>)=serde_json::from_slice(&std::fs::read(format!("{dir}/fixture")).unwrap()).unwrap();
            if mode=="send" {
                let engine=MlsEngine::create(format!("{dir}/alice.db"),vec![0x5a;32]).await.unwrap();
                engine.mobook_prepare_text(&admission(gid,key,true),"operation_crash001",signer,b"synthetic crash text".to_vec()).await.unwrap();
            } else if mode=="stage" {
                let engine=MlsEngine::create(format!("{dir}/alice.db"),vec![0x5a;32]).await.unwrap();
                engine.mobook_stage_remove_many(&admission(gid,key,true),"operation_stage001",signer,&[1]).await.unwrap();
            } else if mode=="remove" {
                let engine=MlsEngine::create(format!("{dir}/alice.db"),vec![0x5a;32]).await.unwrap();
                engine.mobook_prepare_remove(&admission(gid,key,true),"operation_remove001",signer,1).await.unwrap();
            } else {
                let engine=MlsEngine::create(format!("{dir}/bob.db"),vec![0x6b;32]).await.unwrap();
                let sa=admission(gid.clone(),key.clone(),true);
                engine.mobook_accept_text(&admission(gid,key,false),"operation_crash001",std::fs::read(format!("{dir}/wire")).unwrap(),&sender_envelope(&sa,"operation_crash001")).await.unwrap();
            }
        });panic!("missing exit boundary");
    }
    fn run_child(dir:&std::path::Path,mode:&str,point:&str) {
        let output=std::process::Command::new(std::env::current_exe().unwrap()).args(["--exact","api::engine::mobook_private::tests::mobook_v1_engine_crash_child"])
          .env("MOBOOK_V1_ENGINE_DIR",dir).env("MOBOOK_V1_ENGINE_MODE",mode).env("MOBOOK_V1_CRASH",point).output().unwrap();
        assert_eq!(output.status.code(),Some(if point=="before"{81}else{82}),"{}",String::from_utf8_lossy(&output.stderr));
    }
    #[test] fn mobook_v1_actual_engine_process_exit_recovery() {
        futures::executor::block_on(async {
            let dir=std::env::temp_dir().join(format!("mobook_v1_engine_crash_{}",std::process::id()));let _=std::fs::remove_dir_all(&dir);std::fs::create_dir(&dir).unwrap();
            use std::os::unix::fs::PermissionsExt;std::fs::set_permissions(&dir,std::fs::Permissions::from_mode(0o700)).unwrap();
            let a=MlsEngine::create(dir.join("alice.db").to_str().unwrap().into(),vec![0x5a;32]).await.unwrap();
            let b=MlsEngine::create(dir.join("bob.db").to_str().unwrap().into(),vec![0x6b;32]).await.unwrap();
            let ak=MlsSignatureKeyPair::generate(SUITE).unwrap();
            let bk=MlsSignatureKeyPair::generate(SUITE).unwrap();
            let a_signer=serialize_signer(SUITE,ak.private_key(),ak.public_key()).unwrap();
            let b_signer=serialize_signer(SUITE,bk.private_key(),bk.public_key()).unwrap();
            let gid=a.create_group_with_builder(MlsGroupConfig::default_config(SUITE),a_signer.clone(),b"alice".to_vec(),ak.public_key(),None,None,None,None,Some(caps()),None).await.unwrap().group_id;
            let kp=b.create_key_package_with_options(SUITE,b_signer.clone(),b"bob".to_vec(),bk.public_key(),KeyPackageOptions{lifetime_seconds:None,last_resort:false,capabilities:Some(caps()),leaf_node_extensions:None,key_package_extensions:None},None).await.unwrap().key_package_bytes;
            let w=a.add_members(gid.clone(),a_signer.clone(),vec![kp]).await.unwrap().welcome;
            b.join_group_from_welcome(MlsGroupConfig::default_config(SUITE),w,None,b_signer).await.unwrap();


            let sa=admission(gid.clone(),ak.public_key(),true);let ra=admission(gid.clone(),ak.public_key(),false);
            a.db().unwrap().mobook_initialize(&sa.owner).unwrap();b.db().unwrap().mobook_initialize(&ra.owner).unwrap();
            std::fs::write(dir.join("fixture"),serde_json::to_vec(&(&gid,&a_signer,&ak.public_key())).unwrap()).unwrap();
            let mut original=a.db().unwrap().load_for_group(&gid).await.unwrap();original.sort();a.close().await.unwrap();drop(a);
            run_child(&dir,"send","before");
            let a=MlsEngine::create(dir.join("alice.db").to_str().unwrap().into(),vec![0x5a;32]).await.unwrap();
            let mut restored=a.db().unwrap().load_for_group(&gid).await.unwrap();restored.sort();assert_eq!(original,restored);
            assert!(a.db().unwrap().mobook_pending(&sa.owner,&gid,None,10).unwrap().is_empty());a.close().await.unwrap();drop(a);
            run_child(&dir,"send","after");
            let a=MlsEngine::create(dir.join("alice.db").to_str().unwrap().into(),vec![0x5a;32]).await.unwrap();
            assert_eq!(a.db().unwrap().mobook_pending(&sa.owner,&gid,None,10).unwrap(),vec!["operation_crash001"]);
            let sent=a.mobook_prepare_text(&sa,"operation_crash001",a_signer.clone(),b"synthetic crash text".to_vec()).await.unwrap();
            std::fs::write(dir.join("wire"),&sent.payload).unwrap();
            let mut original=b.db().unwrap().load_for_group(&gid).await.unwrap();original.sort();b.close().await.unwrap();drop(b);
            run_child(&dir,"receive","before");
            let b=MlsEngine::create(dir.join("bob.db").to_str().unwrap().into(),vec![0x6b;32]).await.unwrap();
            let mut restored=b.db().unwrap().load_for_group(&gid).await.unwrap();restored.sort();assert_eq!(original,restored);b.close().await.unwrap();drop(b);
            run_child(&dir,"receive","after");
            let b=MlsEngine::create(dir.join("bob.db").to_str().unwrap().into(),vec![0x6b;32]).await.unwrap();
            let recovered=b.mobook_accept_text(&ra,"operation_crash001",sent.payload.clone(),&sender_envelope(&sa,"operation_crash001")).await.unwrap();assert_eq!(recovered.payload,b"synthetic crash text");
            assert!(b.process_message(gid.clone(),sent.payload.clone()).await.is_err());
            let next=a.mobook_prepare_text(&sa,"operation_crash002",a_signer,b"next".to_vec()).await.unwrap();
            assert_eq!(b.mobook_accept_text(&ra,"operation_crash002",next.payload.clone(),&sender_envelope(&sa,"operation_crash002")).await.unwrap().payload,b"next");
            a.close().await.unwrap();b.close().await.unwrap();drop(a);drop(b);std::fs::remove_dir_all(dir).unwrap();
        });
    }

    #[test] fn mobook_v1_actual_remove_process_exit_recovery() {
        futures::executor::block_on(async {
            let dir=std::env::temp_dir().join(format!("mobook_v1_remove_crash_{}",std::process::id()));let _=std::fs::remove_dir_all(&dir);std::fs::create_dir(&dir).unwrap();
            use std::os::unix::fs::PermissionsExt;std::fs::set_permissions(&dir,std::fs::Permissions::from_mode(0o700)).unwrap();
            let a=MlsEngine::create(dir.join("alice.db").to_str().unwrap().into(),vec![0x5a;32]).await.unwrap();
            let b=MlsEngine::create(dir.join("bob.db").to_str().unwrap().into(),vec![0x6b;32]).await.unwrap();
            let ak=MlsSignatureKeyPair::generate(SUITE).unwrap();let bk=MlsSignatureKeyPair::generate(SUITE).unwrap();
            let a_signer=serialize_signer(SUITE,ak.private_key(),ak.public_key()).unwrap();
            let b_signer=serialize_signer(SUITE,bk.private_key(),bk.public_key()).unwrap();
            let gid=a.create_group_with_builder(MlsGroupConfig::default_config(SUITE),a_signer.clone(),b"alice".to_vec(),ak.public_key(),None,None,None,None,Some(caps()),None).await.unwrap().group_id;
            let kp=kpo(b"bob",bk.public_key(),b_signer.clone(),&b).await;
            let w=a.add_members(gid.clone(),a_signer.clone(),vec![kp]).await.unwrap().welcome;
            b.join_group_from_welcome(MlsGroupConfig::default_config(SUITE),w,None,b_signer).await.unwrap();
            let sa=admission(gid.clone(),ak.public_key(),true);
            a.db().unwrap().mobook_initialize(&sa.owner).unwrap();
            std::fs::write(dir.join("fixture"),serde_json::to_vec(&(&gid,&a_signer,&ak.public_key())).unwrap()).unwrap();
            let epoch=a.group_epoch(gid.clone()).await.unwrap();
            let mut original=a.db().unwrap().load_for_group(&gid).await.unwrap();original.sort();a.close().await.unwrap();drop(a);b.close().await.unwrap();drop(b);
            run_child(&dir,"remove","before");
            let a=MlsEngine::create(dir.join("alice.db").to_str().unwrap().into(),vec![0x5a;32]).await.unwrap();
            let mut restored=a.db().unwrap().load_for_group(&gid).await.unwrap();restored.sort();assert_eq!(original,restored);
            assert_eq!(a.group_epoch(gid.clone()).await.unwrap(),epoch);
            assert!(a.db().unwrap().mobook_pending(&sa.owner,&gid,None,10).unwrap().is_empty());a.close().await.unwrap();drop(a);
            run_child(&dir,"remove","after");
            let a=MlsEngine::create(dir.join("alice.db").to_str().unwrap().into(),vec![0x5a;32]).await.unwrap();
            assert_eq!(a.group_epoch(gid.clone()).await.unwrap(),epoch+1);
            assert_eq!(a.db().unwrap().mobook_pending(&sa.owner,&gid,None,10).unwrap(),vec!["operation_remove001"]);
            let commit=a.mobook_prepare_remove(&sa,"operation_remove001",a_signer.clone(),1).await.unwrap();
            assert!(!commit.payload.is_empty());
            assert_eq!(a.mobook_prepare_remove(&sa,"operation_remove001",a_signer.clone(),1).await.unwrap().payload,commit.payload);
            assert!(a.mobook_prepare_remove(&sa,"operation_remove001",a_signer,2).await.is_err());
            assert_eq!(a.group_epoch(gid.clone()).await.unwrap(),epoch+1);
            a.close().await.unwrap();drop(a);std::fs::remove_dir_all(dir).unwrap();
        });
    }
    #[test]
    fn mobook_v1_blocked_pair_removed_in_one_commit() {
        use crate::api::keys::{serialize_signer,MlsSignatureKeyPair};
        const SUITE:MlsCiphersuite=MlsCiphersuite::Mls128DhkemX25519Aes128gcmSha256Ed25519;
        futures::executor::block_on(async {
            // Carol (remaining member) removes the blocked pair Alice+Bob, where Alice has two devices.
            let c=MlsEngine::create(":memory:".into(),vec![0x7c;32]).await.unwrap();
            let a1=MlsEngine::create(":memory:".into(),vec![1;32]).await.unwrap();
            let a2=MlsEngine::create(":memory:".into(),vec![2;32]).await.unwrap();
            let b=MlsEngine::create(":memory:".into(),vec![3;32]).await.unwrap();
            let d=MlsEngine::create(":memory:".into(),vec![4;32]).await.unwrap();
            let kp=|_:()|MlsSignatureKeyPair::generate(SUITE).unwrap();
            let (ck,a1k,a2k,bk,dk)=(kp(()),kp(()),kp(()),kp(()),kp(()));
            let sg=|k:&MlsSignatureKeyPair|serialize_signer(SUITE,k.private_key(),k.public_key()).unwrap();
            let (csg,a1s,a2s,bsg,dsg)=(sg(&ck),sg(&a1k),sg(&a2k),sg(&bk),sg(&dk));
            let gid=c.create_group_with_builder(MlsGroupConfig::default_config(SUITE),csg.clone(),b"carol".to_vec(),ck.public_key(),None,None,None,None,Some(caps()),None).await.unwrap().group_id;
            let k1=kpo(b"alice-1",a1k.public_key(),a1s.clone(),&a1).await;let k2=kpo(b"alice-2",a2k.public_key(),a2s.clone(),&a2).await;
            let k3=kpo(b"bob",bk.public_key(),bsg.clone(),&b).await;let k4=kpo(b"dave",dk.public_key(),dsg.clone(),&d).await;
            let w=c.add_members(gid.clone(),csg.clone(),vec![k1,k2,k3,k4]).await.unwrap().welcome;
            for (e,s) in [(&a1,a1s),(&a2,a2s),(&b,bsg),(&d,dsg)] {e.join_group_from_welcome(MlsGroupConfig::default_config(SUITE),w.clone(),None,s).await.unwrap();}
            let co=Owner{account:"carol-account".into(),device:"carol-device".into(),generation:1};
            let adm=|epoch:i64|Admission{lifetime:AdmissionLifetime::new(),owner:co.clone(),group:gid.clone(),epoch,position:1,policy:"p1".into(),expires_unix:u64::MAX,signature_key:ck.public_key(),credential_identity:b"carol".to_vec()};
            let scope=PrivateNativeScope::adopt(c,co.clone(),gid.clone(),csg).unwrap();
            let e1=scope.engine.group_epoch(gid.clone()).await.unwrap();
            let pair=vec![(a1k.public_key(),b"alice-1".to_vec()),(a2k.public_key(),b"alice-2".to_vec()),(bk.public_key(),b"bob".to_vec())];
            // one unknown device refuses the whole request; nothing changes
            let mut bad=pair.clone();bad.push((vec![9;32],b"ghost".to_vec()));
            assert!(scope.remove_devices(&adm(1),"operation_block_01",&bad).await.is_err());
            assert!(scope.remove_devices(&adm(1),"operation_block_01",&[]).await.is_err());
            assert!(scope.remove_devices(&adm(1),"operation_block_01",&[(ck.public_key(),b"carol".to_vec())]).await.is_err()); // self
            assert_eq!(scope.engine.group_epoch(gid.clone()).await.unwrap(),e1);
            let (commit,leaves)=scope.remove_devices(&adm(1),"operation_block_01",&pair).await.unwrap();
            assert_eq!(leaves.len(),3);
            assert_eq!(scope.engine.group_epoch(gid.clone()).await.unwrap(),e1+1); // ONE epoch for three leaves
            assert_eq!(scope.remove_leaves(&adm(1),"operation_block_01",&leaves).await.unwrap(),commit);
            assert!(scope.remove_leaves(&adm(1),"operation_block_01",&leaves[..2]).await.is_err()); // changed set refuses
            assert!(scope.remove_devices(&adm(1),"operation_block_01",&pair).await.is_err()); // devices gone from tree
            // receipt for the commit: wrong digest refuses, right digest accepted, pending cleared
            let dg=crate::hybrid_crypto::HybridCrypto::new().hash(HashType::Sha2_256,&commit).unwrap();
            let mut rc=AcceptedReceipt{owner:co.clone(),group:gid.clone(),id:"operation_block_01".into(),epoch:1,position:1,policy:"p1".into(),ciphertext_digest:dg};
            assert_eq!(scope.engine.db().unwrap().mobook_pending(&co,&gid,None,10).unwrap().len(),1);
            rc.ciphertext_digest[0]^=1;assert!(scope.receipt_remove(&adm(1),"operation_block_01",&leaves,&rc).await.is_err());rc.ciphertext_digest[0]^=1;
            scope.receipt_remove(&adm(1),"operation_block_01",&leaves,&rc).await.unwrap();
            scope.receipt_remove(&adm(1),"operation_block_01",&leaves,&rc).await.unwrap();
            assert!(scope.engine.db().unwrap().mobook_pending(&co,&gid,None,10).unwrap().is_empty());
            let members=scope.engine.group_members(gid.clone()).await.unwrap();assert_eq!(members.len(),2); // Carol + Dave remain
            // Dave processes the commit and still receives; removed devices cannot read.
            d.process_message(gid.clone(),commit).await.unwrap();
            let sent=scope.prepare(&adm(2),"operation_12345678","للمتبقين فقط".as_bytes().to_vec()).await.unwrap();
            for e in [&a1,&a2,&b] {assert!(e.process_message(gid.clone(),sent.payload.clone()).await.is_err());}
            assert!(d.process_message(gid.clone(),sent.payload.clone()).await.is_ok());
        });
    }
    #[test]
    fn mobook_v1_staged_remove_race_two_issuers() {
        use crate::api::keys::{serialize_signer,MlsSignatureKeyPair};
        const SUITE:MlsCiphersuite=MlsCiphersuite::Mls128DhkemX25519Aes128gcmSha256Ed25519;
        futures::executor::block_on(async {
            // Alice and Carol both try to remove Bob at the same epoch. The server accepts Alice's.
            let a=MlsEngine::create(":memory:".into(),vec![1;32]).await.unwrap();
            let b=MlsEngine::create(":memory:".into(),vec![2;32]).await.unwrap();
            let c=MlsEngine::create(":memory:".into(),vec![3;32]).await.unwrap();
            let (ak,bk,ck)=(MlsSignatureKeyPair::generate(SUITE).unwrap(),MlsSignatureKeyPair::generate(SUITE).unwrap(),MlsSignatureKeyPair::generate(SUITE).unwrap());
            let sg=|k:&MlsSignatureKeyPair|serialize_signer(SUITE,k.private_key(),k.public_key()).unwrap();
            let (asg,bsg,csg)=(sg(&ak),sg(&bk),sg(&ck));
            let gid=a.create_group_with_builder(MlsGroupConfig::default_config(SUITE),asg.clone(),b"alice".to_vec(),ak.public_key(),None,None,None,None,Some(caps()),None).await.unwrap().group_id;
            let kb=kpo(b"bob",bk.public_key(),bsg.clone(),&b).await;let kc=kpo(b"carol",ck.public_key(),csg.clone(),&c).await;
            let w=a.add_members(gid.clone(),asg.clone(),vec![kb,kc]).await.unwrap().welcome;
            b.join_group_from_welcome(MlsGroupConfig::default_config(SUITE),w.clone(),None,bsg).await.unwrap();
            c.join_group_from_welcome(MlsGroupConfig::default_config(SUITE),w,None,csg.clone()).await.unwrap();
            let mk=|n:&str|Owner{account:format!("{n}-account"),device:format!("{n}-device"),generation:1};
            let (ao,co)=(mk("alice"),mk("carol"));
            let adm=|o:&Owner,k:&MlsSignatureKeyPair,cred:&[u8],epoch:i64|Admission{lifetime:AdmissionLifetime::new(),owner:o.clone(),group:gid.clone(),epoch,position:1,policy:"p1".into(),expires_unix:u64::MAX,signature_key:k.public_key(),credential_identity:cred.to_vec()};
            let sa=PrivateNativeScope::adopt(a,ao.clone(),gid.clone(),asg).unwrap();
            let sc=PrivateNativeScope::adopt(c,co.clone(),gid.clone(),csg).unwrap();
            let e1=sa.engine.group_epoch(gid.clone()).await.unwrap();
            let dg=|bytes:&[u8]|crate::hybrid_crypto::HybridCrypto::new().hash(HashType::Sha2_256,bytes).unwrap();
            let ca=sa.stage_remove_leaves(&adm(&ao,&ak,b"alice",1),"operation_stage_a1",&[1]).await.unwrap();
            let cc=sc.stage_remove_leaves(&adm(&co,&ck,b"carol",1),"operation_stage_c1",&[1]).await.unwrap();
            assert_ne!(ca,cc);
            // staged: nothing merged, sends refuse, exact retry returns stored commit, pending listed
            assert_eq!(sa.engine.group_epoch(gid.clone()).await.unwrap(),e1);
            assert_eq!(sa.stage_remove_leaves(&adm(&ao,&ak,b"alice",1),"operation_stage_a1",&[1]).await.unwrap(),ca);
            assert!(sa.stage_remove_leaves(&adm(&ao,&ak,b"alice",1),"operation_stage_a1",&[2]).await.is_err());
            assert!(sa.prepare(&adm(&ao,&ak,b"alice",1),"operation_12345678",b"x".to_vec()).await.is_err());
            assert_eq!(sa.engine.db().unwrap().mobook_pending(&ao,&gid,None,10).unwrap(),vec!["operation_stage_a1"]);
            // Server accepts Alice's. Alice finalizes (merge + receipt); bad receipt refuses before durable receipt.
            let mut rc=AcceptedReceipt{owner:ao.clone(),group:gid.clone(),id:"operation_stage_a1".into(),epoch:1,position:1,policy:"p1".into(),ciphertext_digest:dg(&ca)};
            rc.ciphertext_digest[0]^=1;assert!(sa.finalize_staged(&adm(&ao,&ak,b"alice",1),"operation_stage_a1",&[1],&rc).await.is_err());rc.ciphertext_digest[0]^=1;
            sa.finalize_staged(&adm(&ao,&ak,b"alice",1),"operation_stage_a1",&[1],&rc).await.unwrap();
            sa.finalize_staged(&adm(&ao,&ak,b"alice",1),"operation_stage_a1",&[1],&rc).await.unwrap(); // idempotent
            assert_eq!(sa.engine.group_epoch(gid.clone()).await.unwrap(),e1+1);
            assert!(sa.engine.db().unwrap().mobook_pending(&ao,&gid,None,10).unwrap().is_empty());
            // Server rejects Carol's: discard clears the staged commit and its row, then she processes the winner.
            sc.discard_staged(&adm(&co,&ck,b"carol",1),"operation_stage_c1",&[1]).await.unwrap();
            assert!(sc.engine.db().unwrap().mobook_pending(&co,&gid,None,10).unwrap().is_empty());
            assert!(sc.discard_staged(&adm(&co,&ck,b"carol",1),"operation_stage_c1",&[1]).await.is_err()); // nothing left
            assert_eq!(sc.engine.group_epoch(gid.clone()).await.unwrap(),e1);
            sc.engine.process_message(gid.clone(),ca.clone()).await.unwrap();
            assert_eq!(sc.engine.group_epoch(gid.clone()).await.unwrap(),e1+1);
            // converged: Alice's post-removal message is readable by Carol, not by Bob
            let sent=sa.prepare(&adm(&ao,&ak,b"alice",2),"operation_12345678","بعد السباق".as_bytes().to_vec()).await.unwrap();
            let env=SenderEnvelope{owner:ao.clone(),group:gid.clone(),id:"operation_12345678".into(),epoch:2,position:1,policy:"p1".into()};
            sc.engine.db().unwrap().mobook_initialize(&co).unwrap();
            assert_eq!(sc.receive(&adm(&co,&ak,b"alice",2),"operation_12345678",sent.payload.clone(),&env).await.unwrap().payload,"بعد السباق".as_bytes());
            assert!(b.process_message(gid.clone(),sent.payload.clone()).await.is_err());
        });
    }
    #[test] fn mobook_v1_actual_staged_remove_process_exit_recovery() {
        futures::executor::block_on(async {
            let dir=std::env::temp_dir().join(format!("mobook_v1_stage_crash_{}",std::process::id()));let _=std::fs::remove_dir_all(&dir);std::fs::create_dir(&dir).unwrap();
            use std::os::unix::fs::PermissionsExt;std::fs::set_permissions(&dir,std::fs::Permissions::from_mode(0o700)).unwrap();
            let a=MlsEngine::create(dir.join("alice.db").to_str().unwrap().into(),vec![0x5a;32]).await.unwrap();
            let b=MlsEngine::create(dir.join("bob.db").to_str().unwrap().into(),vec![0x6b;32]).await.unwrap();
            let ak=MlsSignatureKeyPair::generate(SUITE).unwrap();let bk=MlsSignatureKeyPair::generate(SUITE).unwrap();
            let a_signer=serialize_signer(SUITE,ak.private_key(),ak.public_key()).unwrap();
            let b_signer=serialize_signer(SUITE,bk.private_key(),bk.public_key()).unwrap();
            let gid=a.create_group_with_builder(MlsGroupConfig::default_config(SUITE),a_signer.clone(),b"alice".to_vec(),ak.public_key(),None,None,None,None,Some(caps()),None).await.unwrap().group_id;
            let kp=kpo(b"bob",bk.public_key(),b_signer.clone(),&b).await;
            let w=a.add_members(gid.clone(),a_signer.clone(),vec![kp]).await.unwrap().welcome;
            b.join_group_from_welcome(MlsGroupConfig::default_config(SUITE),w,None,b_signer).await.unwrap();
            let sa=admission(gid.clone(),ak.public_key(),true);
            a.db().unwrap().mobook_initialize(&sa.owner).unwrap();
            std::fs::write(dir.join("fixture"),serde_json::to_vec(&(&gid,&a_signer,&ak.public_key())).unwrap()).unwrap();
            let epoch=a.group_epoch(gid.clone()).await.unwrap();
            let mut original=a.db().unwrap().load_for_group(&gid).await.unwrap();original.sort();a.close().await.unwrap();drop(a);b.close().await.unwrap();drop(b);
            run_child(&dir,"stage","before");
            let a=MlsEngine::create(dir.join("alice.db").to_str().unwrap().into(),vec![0x5a;32]).await.unwrap();
            let mut restored=a.db().unwrap().load_for_group(&gid).await.unwrap();restored.sort();assert_eq!(original,restored);
            assert!(a.db().unwrap().mobook_pending(&sa.owner,&gid,None,10).unwrap().is_empty());a.close().await.unwrap();drop(a);
            run_child(&dir,"stage","after");
            let a=MlsEngine::create(dir.join("alice.db").to_str().unwrap().into(),vec![0x5a;32]).await.unwrap();
            // after restart: NOT merged, still pending, exact retry returns the stored commit, sends refuse
            assert_eq!(a.group_epoch(gid.clone()).await.unwrap(),epoch);
            assert_eq!(a.db().unwrap().mobook_pending(&sa.owner,&gid,None,10).unwrap(),vec!["operation_stage001"]);
            let stored=a.mobook_stage_remove_many(&sa,"operation_stage001",a_signer.clone(),&[1]).await.unwrap();
            assert_eq!(a.mobook_stage_remove_many(&sa,"operation_stage001",a_signer.clone(),&[1]).await.unwrap().payload,stored.payload);
            assert!(a.mobook_stage_remove_many(&sa,"operation_stage001",a_signer.clone(),&[2]).await.is_err());
            assert!(a.mobook_prepare_text(&sa,"operation_12345678",a_signer.clone(),b"x".to_vec()).await.is_err());
            // rejected path after restart: discard leaves the original group usable
            a.mobook_discard_staged(&sa,"operation_stage001",&[1]).await.unwrap();
            assert!(a.db().unwrap().mobook_pending(&sa.owner,&gid,None,10).unwrap().is_empty());
            assert_eq!(a.group_epoch(gid.clone()).await.unwrap(),epoch);
            assert!(a.mobook_prepare_text(&sa,"operation_12345678",a_signer.clone(),b"x".to_vec()).await.is_ok());
            a.close().await.unwrap();drop(a);std::fs::remove_dir_all(dir).unwrap();
        });
    }
    #[test]
    fn mobook_v1_lost_server_answer_winner_arrives_while_staged() {
        use crate::api::keys::{serialize_signer,MlsSignatureKeyPair};
        const SUITE:MlsCiphersuite=MlsCiphersuite::Mls128DhkemX25519Aes128gcmSha256Ed25519;
        futures::executor::block_on(async {
            let a=MlsEngine::create(":memory:".into(),vec![1;32]).await.unwrap();
            let b=MlsEngine::create(":memory:".into(),vec![2;32]).await.unwrap();
            let c=MlsEngine::create(":memory:".into(),vec![3;32]).await.unwrap();
            let (ak,bk,ck)=(MlsSignatureKeyPair::generate(SUITE).unwrap(),MlsSignatureKeyPair::generate(SUITE).unwrap(),MlsSignatureKeyPair::generate(SUITE).unwrap());
            let sg=|k:&MlsSignatureKeyPair|serialize_signer(SUITE,k.private_key(),k.public_key()).unwrap();
            let (asg,bsg,csg)=(sg(&ak),sg(&bk),sg(&ck));
            let gid=a.create_group_with_builder(MlsGroupConfig::default_config(SUITE),asg.clone(),b"alice".to_vec(),ak.public_key(),None,None,None,None,Some(caps()),None).await.unwrap().group_id;
            let kb=kpo(b"bob",bk.public_key(),bsg.clone(),&b).await;let kc=kpo(b"carol",ck.public_key(),csg.clone(),&c).await;
            let w=a.add_members(gid.clone(),asg.clone(),vec![kb,kc]).await.unwrap().welcome;
            b.join_group_from_welcome(MlsGroupConfig::default_config(SUITE),w.clone(),None,bsg).await.unwrap();
            c.join_group_from_welcome(MlsGroupConfig::default_config(SUITE),w,None,csg.clone()).await.unwrap();
            let mk=|n:&str|Owner{account:format!("{n}-account"),device:format!("{n}-device"),generation:1};
            let (ao,co)=(mk("alice"),mk("carol"));
            let adm=|o:&Owner,k:&MlsSignatureKeyPair,cred:&[u8]|Admission{lifetime:AdmissionLifetime::new(),owner:o.clone(),group:gid.clone(),epoch:1,position:1,policy:"p1".into(),expires_unix:u64::MAX,signature_key:k.public_key(),credential_identity:cred.to_vec()};
            let sa=PrivateNativeScope::adopt(a,ao.clone(),gid.clone(),asg).unwrap();
            let sc=PrivateNativeScope::adopt(c,co.clone(),gid.clone(),csg).unwrap();
            let e1=sc.engine.group_epoch(gid.clone()).await.unwrap();
            let ca=sa.stage_remove_leaves(&adm(&ao,&ak,b"alice"),"operation_stage_a1",&[1]).await.unwrap();
            sc.stage_remove_leaves(&adm(&co,&ck,b"carol"),"operation_stage_c1",&[1]).await.unwrap();
            let dg=crate::hybrid_crypto::HybridCrypto::new().hash(HashType::Sha2_256,&ca).unwrap();
            let rc=AcceptedReceipt{owner:ao.clone(),group:gid.clone(),id:"operation_stage_a1".into(),epoch:1,position:1,policy:"p1".into(),ciphertext_digest:dg};
            sa.finalize_staged(&adm(&ao,&ak,b"alice"),"operation_stage_a1",&[1],&rc).await.unwrap();
            // Carol never heard back, then the winner arrives while hers is still staged.
            let raw=sc.engine.process_message(gid.clone(),ca.clone()).await;
            let epoch_after=sc.engine.group_epoch(gid.clone()).await.unwrap();
            let pending=sc.engine.db().unwrap().mobook_pending(&co,&gid,None,10).unwrap();
            eprintln!("LOSTANSWER raw_ok={} epoch_before={} epoch_after={} pending={:?}",raw.is_ok(),e1,epoch_after,pending);
            // Finding: the engine accepted the winner while ours was staged. The group moved on,
            // but our stale outbox row is still listed as pending until it is superseded.
            assert!(raw.is_ok());assert_eq!(epoch_after,e1+1);
            assert_eq!(pending,vec!["operation_stage_c1"]);
            // The staged commit can no longer be finalized or receipted at the new epoch; discard clears the stale row.
            assert!(sc.engine.mobook_finalize_staged(&sc.admitted(&adm(&co,&ck,b"carol")).unwrap(),"operation_stage_c1",&[1]).await.is_ok()); // no pending commit left: no-op, must not merge anything
            assert_eq!(sc.engine.group_epoch(gid.clone()).await.unwrap(),e1+1);
            sc.discard_staged(&adm(&co,&ck,b"carol"),"operation_stage_c1",&[1]).await.unwrap();
            assert!(sc.engine.db().unwrap().mobook_pending(&co,&gid,None,10).unwrap().is_empty());
            assert!(sc.discard_staged(&adm(&co,&ck,b"carol"),"operation_stage_c1",&[1]).await.is_err());
        });
    }
    #[test] fn mobook_v1_revocation_waits_for_commit_guard_and_closes_clones() {
        let lifetime=AdmissionLifetime::new();let guard=lifetime.active().unwrap();
        let peer=lifetime.clone();let (start_tx,start_rx)=std::sync::mpsc::channel();let (done_tx,done_rx)=std::sync::mpsc::channel();
        let thread=std::thread::spawn(move||{start_tx.send(()).unwrap();peer.revoke().unwrap();done_tx.send(()).unwrap();});
        start_rx.recv().unwrap();assert!(done_rx.try_recv().is_err());drop(guard);
        done_rx.recv_timeout(Duration::from_secs(2)).unwrap();thread.join().unwrap();assert!(lifetime.active().is_err());assert!(lifetime.clone().active().is_err());
    }


    async fn kpo(n:&[u8],pk:Vec<u8>,s:Vec<u8>,e:&MlsEngine)->Vec<u8> {
        e.create_key_package_with_options(MlsCiphersuite::Mls128DhkemX25519Aes128gcmSha256Ed25519,s,n.to_vec(),pk,KeyPackageOptions{lifetime_seconds:None,last_resort:false,capabilities:Some(caps()),leaf_node_extensions:None,key_package_extensions:None},None).await.unwrap().key_package_bytes
    }
    #[test]
    fn mobook_v1_guarded_remove_stops_removed_member() {
        use crate::api::keys::{serialize_signer,MlsSignatureKeyPair};
        const SUITE:MlsCiphersuite=MlsCiphersuite::Mls128DhkemX25519Aes128gcmSha256Ed25519;
        futures::executor::block_on(async {
            let a=MlsEngine::create(":memory:".into(),vec![0x5a;32]).await.unwrap();
            let b=MlsEngine::create(":memory:".into(),vec![0x6b;32]).await.unwrap();
            let c=MlsEngine::create(":memory:".into(),vec![0x7c;32]).await.unwrap();
            let ak=MlsSignatureKeyPair::generate(SUITE).unwrap();let bk=MlsSignatureKeyPair::generate(SUITE).unwrap();let ck=MlsSignatureKeyPair::generate(SUITE).unwrap();
            let asg=serialize_signer(SUITE,ak.private_key(),ak.public_key()).unwrap();
            let bsg=serialize_signer(SUITE,bk.private_key(),bk.public_key()).unwrap();
            let csg=serialize_signer(SUITE,ck.private_key(),ck.public_key()).unwrap();
            let gid=a.create_group_with_builder(MlsGroupConfig::default_config(SUITE),asg.clone(),b"alice".to_vec(),ak.public_key(),None,None,None,None,Some(caps()),None).await.unwrap().group_id;
            let kb=kpo(b"bob",bk.public_key(),bsg.clone(),&b).await;let kc=kpo(b"carol",ck.public_key(),csg.clone(),&c).await;
            let w=a.add_members(gid.clone(),asg.clone(),vec![kb,kc]).await.unwrap().welcome;
            b.join_group_from_welcome(MlsGroupConfig::default_config(SUITE),w.clone(),None,bsg.clone()).await.unwrap();
            c.join_group_from_welcome(MlsGroupConfig::default_config(SUITE),w,None,csg).await.unwrap();
            let ao=Owner{account:"alice-account".into(),device:"alice-device".into(),generation:1};
            let co=Owner{account:"carol-account".into(),device:"carol-device".into(),generation:1};
            let bo=Owner{account:"bob-account".into(),device:"bob-device".into(),generation:1};
            c.db().unwrap().mobook_initialize(&co).unwrap();b.db().unwrap().mobook_initialize(&bo).unwrap();
            let adm=|o:&Owner,epoch:i64|Admission{lifetime:AdmissionLifetime::new(),owner:o.clone(),group:gid.clone(),epoch,position:1,policy:"p1".into(),expires_unix:u64::MAX,signature_key:ak.public_key(),credential_identity:b"alice".to_vec()};
            let scope=PrivateNativeScope::adopt(a,ao.clone(),gid.clone(),asg).unwrap();
            let e1=scope.engine.group_epoch(gid.clone()).await.unwrap();
            // wrong-owner and expired admission refuse before touching MLS
            let mut bad=adm(&ao,1);bad.expires_unix=0;assert!(scope.remove(&bad,"operation_remove_1",1).await.is_err());
            assert!(scope.remove(&adm(&bo,1),"operation_remove_1",1).await.is_err());
            assert_eq!(scope.engine.group_epoch(gid.clone()).await.unwrap(),e1);
            // roster-style selection: unknown or wrong-key member refuses; Bob found by key+credential, not by index
            assert!(scope.remove_device(&adm(&ao,1),"operation_remove_1",&[7;32],b"bob").await.is_err());
            assert!(scope.remove_device(&adm(&ao,1),"operation_remove_1",&bk.public_key(),b"mallory").await.is_err());
            assert!(scope.remove_device(&adm(&ao,1),"operation_remove_1",&bk.public_key(),b"bob").await.is_ok_and(|c|!c.is_empty()));
            assert_eq!(scope.engine.group_epoch(gid.clone()).await.unwrap(),e1+1);
            let commit=scope.remove(&adm(&ao,1),"operation_remove_1",1).await.unwrap(); // exact retry of the same journaled remove
            // exact retry returns the stored commit without another epoch change; changed leaf or id refuses
            assert_eq!(scope.remove(&adm(&ao,1),"operation_remove_1",1).await.unwrap(),commit);
            assert!(scope.remove(&adm(&ao,1),"operation_remove_1",2).await.is_err());
            assert!(scope.remove(&adm(&ao,1),"operation_remove_2",1).await.is_err());
            assert!(scope.remove(&adm(&ao,2),"operation_remove_3",0).await.is_err()); // self-removal refused
            assert_eq!(scope.engine.group_epoch(gid.clone()).await.unwrap(),e1+1);
            assert_eq!(scope.engine.db().unwrap().mobook_pending(&ao,&gid,None,10).unwrap().len(),1);
            assert_eq!(scope.engine.group_epoch(gid.clone()).await.unwrap(),e1+1);
            c.process_message(gid.clone(),commit.clone()).await.unwrap().epoch;
            let sent=scope.prepare(&adm(&ao,2),"operation_12345678","بعد الإزالة".as_bytes().to_vec()).await.unwrap();
            let env=SenderEnvelope{owner:ao.clone(),group:gid.clone(),id:"operation_12345678".into(),epoch:2,position:1,policy:"p1".into()};
            let got=c.mobook_accept_text(&adm(&co,2),"operation_12345678",sent.payload.clone(),&env).await.unwrap();
            assert_eq!(got.payload,"بعد الإزالة".as_bytes());
            // removed Bob cannot read post-removal traffic by raw or guarded path
            assert!(b.process_message(gid.clone(),sent.payload.clone()).await.is_err());
            assert!(b.mobook_accept_text(&adm(&bo,2),"operation_12345678",sent.payload.clone(),&env).await.is_err());
            // frozen scope refuses a further remove
            scope.freeze().unwrap();assert!(scope.remove(&adm(&ao,2),"operation_remove_9",2).await.is_err());
            // removed Bob purges his own local conversation state
            let bob_scope=PrivateNativeScope::adopt(b,bo.clone(),gid.clone(),bsg).unwrap();
            let db=bob_scope.engine.db().unwrap();
            let before=db.load_for_group(&gid).await.unwrap();
            assert!(before.len()>1);
            bob_scope.purge_and_close().await.unwrap();
            let after=db.load_for_group(&gid).await;
            // all group rows gone; only the global signer key row (not group-scoped) remains
            let after=after.unwrap();assert_eq!(after.len(),1);assert!(after[0].0.starts_with(b"SignatureKeyPair"));
            assert!(bob_scope.purge_and_close().await.is_err()); // closed scope refuses a second purge
        });
    }
}
