//! Disabled versioned bridge contract. No FRB export, no shipping caller.
//! Callers pass only ids and bytes. Admission and sender evidence come from an
//! internal trusted source, never from the request.
use super::mobook_private::{AcceptedReceipt,Admission,PrivateNativeScope,SenderEnvelope};
use super::*;
use crate::encrypted_db::mobook_journal::Owner;
use std::{collections::HashMap,sync::Arc};
pub(crate) const BRIDGE_VERSION:u16=1;
/// Engineering safety bound, not a product limit.
pub(crate) const MAX_OPEN_CONVERSATIONS:usize=64;
pub(crate) trait TrustedAdmissions:Send+Sync {
    fn for_send(&self,owner:&Owner,group:&[u8],id:&str)->Result<Admission,&'static str>;
    fn for_receive(&self,owner:&Owner,group:&[u8],id:&str)->Result<(Admission,SenderEnvelope),&'static str>;
    /// Receipt evidence for an accepted transport delivery of this send.
    fn for_receipt(&self,owner:&Owner,group:&[u8],id:&str)->Result<(Admission,AcceptedReceipt),&'static str>;
}
pub(crate) enum BridgeOp {
    Send{id:String,text:Vec<u8>},
    Receive{id:String,wire:Vec<u8>},
    /// Exact-retry of the original send (same id and text) to recover the stored record, then durable receipt.
    Receipt{id:String,text:Vec<u8>},
    Close,
    Purge,
}
pub(crate) struct BridgeRequest {pub version:u16,pub conversation:Vec<u8>,pub op:BridgeOp}
pub(crate) enum BridgeReply {Wire(Vec<u8>),Text(Vec<u8>),Done}
pub(crate) struct PrivateRegistry {
    owner:Owner,
    source:Arc<dyn TrustedAdmissions>,
    scopes:futures::lock::Mutex<Option<HashMap<Vec<u8>,Arc<PrivateNativeScope>>>>,
}
impl PrivateRegistry {
    pub(crate) fn new(owner:Owner,source:Arc<dyn TrustedAdmissions>)->Self {
        Self{owner,source,scopes:futures::lock::Mutex::new(Some(HashMap::new()))}
    }
    pub(crate) async fn register(&self,scope:PrivateNativeScope,group:Vec<u8>)->Result<(),&'static str> {
        let mut g=self.scopes.lock().await;
        let m=g.as_mut().ok_or("private-registry-closed")?;
        if m.contains_key(&group) {return Err("private-conversation-duplicate");}
        if m.len()>=MAX_OPEN_CONVERSATIONS {return Err("private-registry-full");}
        m.insert(group,Arc::new(scope));Ok(())
    }
    async fn find(&self,c:&[u8])->Result<Arc<PrivateNativeScope>,&'static str> {
        self.scopes.lock().await.as_ref().ok_or("private-registry-closed")?.get(c).cloned().ok_or("private-conversation-unknown")
    }
    pub(crate) async fn handle(&self,r:BridgeRequest)->Result<BridgeReply,&'static str> {
        if r.version!=BRIDGE_VERSION {return Err("private-bridge-version");}
        let scope=self.find(&r.conversation).await?;
        match r.op {
            BridgeOp::Send{id,text}=>{
                let a=self.source.for_send(&self.owner,&r.conversation,&id)?;
                Ok(BridgeReply::Wire(scope.prepare(&a,&id,text).await?.payload.clone()))
            }
            BridgeOp::Receive{id,wire}=>{
                let (a,e)=self.source.for_receive(&self.owner,&r.conversation,&id)?;
                Ok(BridgeReply::Text(scope.receive(&a,&id,wire,&e).await?.payload.clone()))
            }
            BridgeOp::Receipt{id,text}=>{
                let (a,rc)=self.source.for_receipt(&self.owner,&r.conversation,&id)?;
                let rec=scope.prepare(&a,&id,text).await?;
                scope.receipt(&rec,&rc).await?;
                Ok(BridgeReply::Done)
            }
            BridgeOp::Close=>{
                scope.close().await?;
                if let Some(m)=self.scopes.lock().await.as_mut(){m.remove(&r.conversation);}
                Ok(BridgeReply::Done)
            }
            BridgeOp::Purge=>{
                scope.purge_and_close().await?;
                if let Some(m)=self.scopes.lock().await.as_mut(){m.remove(&r.conversation);}
                Ok(BridgeReply::Done)
            }
        }
    }
    /// Terminal. Later calls refuse; no reopen.
    pub(crate) async fn close_all(&self)->Result<(),&'static str> {
        let m=self.scopes.lock().await.take();
        if let Some(m)=m {for s in m.values(){s.close().await?;}}
        Ok(())
    }
}
#[cfg(test)]
mod tests {
    use super::*;
    use crate::api::keys::{serialize_signer,MlsSignatureKeyPair};
    use super::super::mobook_private::AdmissionLifetime;
    const SUITE:MlsCiphersuite=MlsCiphersuite::Mls128DhkemX25519Aes128gcmSha256Ed25519;
    fn caps()->MlsCapabilities {MlsCapabilities{versions:vec![1],ciphersuites:vec![1],extensions:vec![],proposals:vec![],credentials:vec![1]}}
    struct Src{owner:Owner,key:Vec<u8>,deny:bool}
    impl Src{fn adm(&self,g:&[u8])->Admission{Admission{lifetime:AdmissionLifetime::new(),owner:self.owner.clone(),group:g.to_vec(),epoch:1,position:1,policy:"p1".into(),expires_unix:u64::MAX,signature_key:self.key.clone(),credential_identity:b"alice".to_vec()}}}
    struct Pair(Src,Owner,std::sync::Mutex<Vec<u8>>);
    impl TrustedAdmissions for Pair {
        fn for_receipt(&self,_o:&Owner,g:&[u8],i:&str)->Result<(Admission,AcceptedReceipt),&'static str>{
            if self.0.deny{return Err("denied");}
            Ok((self.0.adm(g),self.rc(g,i,self.2.lock().unwrap().clone())))
        }
        fn for_send(&self,_o:&Owner,g:&[u8],_i:&str)->Result<Admission,&'static str>{if self.0.deny{Err("denied")}else{Ok(self.0.adm(g))}}
        fn for_receive(&self,_o:&Owner,g:&[u8],i:&str)->Result<(Admission,SenderEnvelope),&'static str>{
            if self.0.deny{return Err("denied");}
            let a=self.0.adm(g);
            let e=SenderEnvelope{owner:self.1.clone(),group:g.to_vec(),id:i.into(),epoch:1,position:1,policy:"p1".into()};
            Ok((a,e))
        }
    }
    impl Pair {
        fn rc(&self,g:&[u8],i:&str,digest:Vec<u8>)->AcceptedReceipt{AcceptedReceipt{owner:self.0.owner.clone(),group:g.to_vec(),id:i.into(),epoch:1,position:1,policy:"p1".into(),ciphertext_digest:digest}}
    }
    fn req(c:&[u8],op:BridgeOp)->BridgeRequest{BridgeRequest{version:1,conversation:c.to_vec(),op}}
    #[test]
    fn mobook_v1_bridge_registry_boundaries() {
        futures::executor::block_on(async {
            let a=MlsEngine::create(":memory:".into(),vec![0x5a;32]).await.unwrap();
            let b=MlsEngine::create(":memory:".into(),vec![0x6b;32]).await.unwrap();
            let ak=MlsSignatureKeyPair::generate(SUITE).unwrap();
            let bk=MlsSignatureKeyPair::generate(SUITE).unwrap();
            let a_signer=serialize_signer(SUITE,ak.private_key(),ak.public_key()).unwrap();
            let b_signer=serialize_signer(SUITE,bk.private_key(),bk.public_key()).unwrap();
            let gid=a.create_group_with_builder(MlsGroupConfig::default_config(SUITE),a_signer.clone(),b"alice".to_vec(),ak.public_key(),None,None,None,None,Some(caps()),None).await.unwrap().group_id;
            let kp=b.create_key_package_with_options(SUITE,b_signer.clone(),b"bob".to_vec(),bk.public_key(),KeyPackageOptions{lifetime_seconds:None,last_resort:false,capabilities:Some(caps()),leaf_node_extensions:None,key_package_extensions:None},None).await.unwrap().key_package_bytes;
            let w=a.add_members(gid.clone(),a_signer.clone(),vec![kp]).await.unwrap().welcome;
            b.join_group_from_welcome(MlsGroupConfig::default_config(SUITE),w,None,b_signer.clone()).await.unwrap();
            let ao=Owner{account:"alice-account".into(),device:"alice-device".into(),generation:1};
            let bo=Owner{account:"bob-account".into(),device:"bob-device".into(),generation:1};
            let mk=|o:&Owner,deny:bool,sender:&Owner|Arc::new(Pair(Src{owner:o.clone(),key:ak.public_key(),deny},sender.clone(),Default::default()));
            let pa=mk(&ao,false,&ao);
            let ra=PrivateRegistry::new(ao.clone(),pa.clone());
            let rb=PrivateRegistry::new(bo.clone(),mk(&bo,false,&ao));
            ra.register(PrivateNativeScope::adopt(a,ao.clone(),gid.clone(),a_signer.clone()).unwrap(),gid.clone()).await.unwrap();
            rb.register(PrivateNativeScope::adopt(b,bo.clone(),gid.clone(),b_signer.clone()).unwrap(),gid.clone()).await.unwrap();
            // version, unknown conversation
            let mut bad=req(&gid,BridgeOp::Send{id:"operation_12345678".into(),text:b"x".to_vec()});bad.version=2;
            assert_eq!(ra.handle(bad).await.err(),Some("private-bridge-version"));
            assert_eq!(ra.handle(req(b"nope",BridgeOp::Close)).await.err(),Some("private-conversation-unknown"));
            // duplicate registration refused
            let dup_engine=MlsEngine::create(":memory:".into(),vec![1;32]).await.unwrap();
            assert!(ra.register(PrivateNativeScope::adopt(dup_engine,ao.clone(),gid.clone(),a_signer.clone()).unwrap(),gid.clone()).await.is_err());
            // send/receive roundtrip, exact retry
            let id="operation_12345678";let text="رسالة".as_bytes().to_vec();
            let wire=match ra.handle(req(&gid,BridgeOp::Send{id:id.into(),text:text.clone()})).await.unwrap(){BridgeReply::Wire(w)=>w,_=>panic!()};
            let again=match ra.handle(req(&gid,BridgeOp::Send{id:id.into(),text:text.clone()})).await.unwrap(){BridgeReply::Wire(w)=>w,_=>panic!()};
            assert_eq!(wire,again);
            assert!(ra.handle(req(&gid,BridgeOp::Send{id:id.into(),text:b"changed".to_vec()})).await.is_err());
            // receipt: wrong digest refused, right digest accepted, idempotent, changed text refused
            let dg=crate::hybrid_crypto::HybridCrypto::new().hash(openmls_traits::types::HashType::Sha2_256,&wire).unwrap();
            let mut bad_dg=dg.clone();bad_dg[0]^=1;
            *pa.2.lock().unwrap()=bad_dg;
            assert!(ra.handle(req(&gid,BridgeOp::Receipt{id:id.into(),text:text.clone()})).await.is_err());
            *pa.2.lock().unwrap()=dg;
            assert!(ra.handle(req(&gid,BridgeOp::Receipt{id:id.into(),text:b"changed".to_vec()})).await.is_err());
            assert!(matches!(ra.handle(req(&gid,BridgeOp::Receipt{id:id.into(),text:text.clone()})).await.unwrap(),BridgeReply::Done));
            assert!(matches!(ra.handle(req(&gid,BridgeOp::Receipt{id:id.into(),text:text.clone()})).await.unwrap(),BridgeReply::Done));
            match rb.handle(req(&gid,BridgeOp::Receive{id:id.into(),wire:wire.clone()})).await.unwrap(){BridgeReply::Text(t)=>assert_eq!(t,text),_=>panic!()}
            assert!(rb.handle(req(&gid,BridgeOp::Receive{id:id.into(),wire:vec![1,2,3]})).await.is_err());
            // purge removes; later use refused as unknown
            rb.handle(req(&gid,BridgeOp::Purge)).await.unwrap();
            assert_eq!(rb.handle(req(&gid,BridgeOp::Receive{id:id.into(),wire})).await.err(),Some("private-conversation-unknown"));
            // close_all terminal
            ra.close_all().await.unwrap();
            assert_eq!(ra.handle(req(&gid,BridgeOp::Send{id:id.into(),text}) ).await.err(),Some("private-registry-closed"));
            assert!(ra.register(PrivateNativeScope::adopt(MlsEngine::create(":memory:".into(),vec![2;32]).await.unwrap(),ao.clone(),gid.clone(),a_signer.clone()).unwrap(),gid.clone()).await.is_err());
        });
    }
    #[test]
    fn mobook_v1_bridge_source_denial_and_capacity() {
        futures::executor::block_on(async {
            let ak=MlsSignatureKeyPair::generate(SUITE).unwrap();
            let signer=serialize_signer(SUITE,ak.private_key(),ak.public_key()).unwrap();
            let o=Owner{account:"alice-account".into(),device:"alice-device".into(),generation:1};
            let deny=PrivateRegistry::new(o.clone(),Arc::new(Pair(Src{owner:o.clone(),key:ak.public_key(),deny:true},o.clone(),Default::default())));
            let e=MlsEngine::create(":memory:".into(),vec![3;32]).await.unwrap();
            deny.register(PrivateNativeScope::adopt(e,o.clone(),b"g".to_vec(),signer.clone()).unwrap(),b"g".to_vec()).await.unwrap();
            assert_eq!(deny.handle(req(b"g",BridgeOp::Send{id:"operation_12345678".into(),text:b"x".to_vec()})).await.err(),Some("denied"));
            assert_eq!(deny.handle(req(b"g",BridgeOp::Receive{id:"operation_12345678".into(),wire:vec![0]})).await.err(),Some("denied"));
            for i in 0..MAX_OPEN_CONVERSATIONS-1 {
                let g=format!("group{i}").into_bytes();
                let e=MlsEngine::create(":memory:".into(),vec![4;32]).await.unwrap();
                deny.register(PrivateNativeScope::adopt(e,o.clone(),g.clone(),signer.clone()).unwrap(),g).await.unwrap();
            }
            let e=MlsEngine::create(":memory:".into(),vec![5;32]).await.unwrap();
            assert_eq!(deny.register(PrivateNativeScope::adopt(e,o,b"extra".to_vec(),signer).unwrap(),b"extra".to_vec()).await.err(),Some("private-registry-full"));
        });
    }
}
