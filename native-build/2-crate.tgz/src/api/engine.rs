//! Engine-based API — uses Rust-owned encrypted DB instead of Dart callbacks.
//!
//! `MlsEngine` wraps an `EncryptedDb` and provides all MLS operations as
//! async methods. Storage is managed entirely in Rust — Dart never sees raw
//! key-value data.
//!
//! Functions are `async` because DB I/O is async (SQLCipher on native,
//! IndexedDB on WASM).

use std::time::Duration;
// `Lifetime::validate_with_time` takes a `SystemTime`, and *which* `SystemTime`
// that is depends on the target: openmls picks `web_time`'s under
// `cfg(target_arch = "wasm32")` and `std`'s everywhere else. The two are
// unrelated types, so the epoch we add to has to be selected the same way.
#[cfg(not(target_arch = "wasm32"))]
use std::time::{SystemTime, UNIX_EPOCH};
#[cfg(target_arch = "wasm32")]
use web_time::{SystemTime, UNIX_EPOCH};

use openmls::prelude::*;
use openmls::prelude::tls_codec::{
    DeserializeBytes as TlsDeserializeBytes, Serialize as TlsSerialize,
};
use openmls::ciphersuite::hash_ref::ProposalRef;
use openmls::messages::group_info::VerifiableGroupInfo;
use openmls::schedule::PreSharedKeyId;
use openmls_traits::OpenMlsProvider;
use openmls_traits::storage::StorageProvider;

use super::config::MlsGroupConfig;
use super::keys::signer_from_bytes;
use super::types::{
    ciphersuite_to_native, native_to_ciphersuite, capabilities_to_native, extension_to_mls,
    extensions_from_mls, external_senders_to_mls,
    FlexibleCommitOptions, KeyPackageOptions, MlsCapabilities, MlsCiphersuite, MlsExtension,
    MlsGroupContextInfo, MlsLeafNodeInfo, MlsMemberInfo, MlsPendingProposalInfo, MlsProposalType,
    MlsSenderInfo, MlsSenderKind, MlsWireFormatPolicy, ProcessedMessageType, StagedCommitInfo,
    StagedProposalInfo, WelcomeGroupInfoExtensions, WelcomeInspectResult,
};
use crate::snapshot_storage::{
    stored_group_id, SnapshotOpenMlsProvider, SnapshotStorageProvider, STORED_GROUP_KEY_PREFIX,
};

// ═══════════════════════════════════════════════════════════════
// HELPERS
// ═══════════════════════════════════════════════════════════════

/// Build a `CredentialWithKey` either from a TLS-serialized `Credential` (for X.509 or custom
/// credential types) or by creating a `BasicCredential` from the identity bytes.
fn build_credential_with_key(
    credential_identity: &[u8],
    signer_public_key: &[u8],
    credential_bytes: Option<&[u8]>,
) -> Result<CredentialWithKey, String> {
    let credential = match credential_bytes {
        Some(bytes) => Credential::tls_deserialize_exact_bytes(bytes)
            .map_err(|e| format!("Failed to deserialize credential: {e}"))?,
        None => BasicCredential::new(credential_identity.to_vec()).into(),
    };
    Ok(CredentialWithKey {
        credential,
        signature_key: SignaturePublicKey::from(signer_public_key.to_vec()),
    })
}

/// Load an MlsGroup from the provider's storage.
fn load_group<P: OpenMlsProvider>(group_id: &[u8], provider: &P) -> Result<MlsGroup, String> {
    let gid = GroupId::from_slice(group_id);
    MlsGroup::load(provider.storage(), &gid)
        .map_err(|e| format!("Failed to load group: {}", e))?
        .ok_or_else(|| "No group found in storage".to_string())
}

/// Why a group cannot be created or joined under an ID this engine already
/// stores.
///
/// OpenMLS refuses it itself (`NewGroupError::GroupAlreadyExists`,
/// `WelcomeError::GroupAlreadyExists`), provided the stored group is in the
/// snapshot it looks in — which is why the create and join paths below load
/// that group's rows. The message adds what the caller can do about it.
const GROUP_ALREADY_EXISTS: &str = "A group with this ID already exists in this engine's \
    storage. To replace it (for example one this client has left or been removed from), \
    delete it with deleteGroup first";

/// Why an external join into a group this engine already stores is refused:
/// OpenMLS does not check, so the engine does (`load_for_external_join`).
const EXTERNAL_JOIN_STORED_GROUP: &str = "A group with this ID already exists in this engine's \
    storage. To rejoin it from this GroupInfo, replacing what is stored, pass \
    replaceStoredGroup: true, and only for a GroupInfo whose source speaks for that group";

/// A group ID as an error message shows it.
fn hex(bytes: &[u8]) -> String {
    bytes.iter().map(|byte| format!("{byte:02x}")).collect()
}

type StorageError = crate::snapshot_storage::SnapshotStorageError;

fn new_group_error(error: NewGroupError<StorageError>) -> String {
    match error {
        NewGroupError::GroupAlreadyExists => {
            format!("Failed to create group: {GROUP_ALREADY_EXISTS}")
        }
        other => format!("Failed to create group: {other}"),
    }
}

fn welcome_error(context: &str, error: WelcomeError<StorageError>) -> String {
    match error {
        WelcomeError::GroupAlreadyExists => {
            format!("Failed to join group from welcome: {GROUP_ALREADY_EXISTS}")
        }
        other => format!("{context}: {other}"),
    }
}

/// The extension type of last_resort (draft-ietf-mls-extensions).
const LAST_RESORT_EXTENSION_TYPE: u16 = 0x000a;

/// The highest proposal type MLS keeps for itself: RFC 9420 reserves
/// `0x0000` and registers `0x0001` to `0x0007`, and the MLS extensions draft
/// (draft-ietf-mls-extensions) takes `0x0008` to `0x000a` for its own
/// proposals. None of them is an application's own.
const LAST_RESERVED_PROPOSAL_TYPE: u16 = 0x000a;

/// The leaf capabilities a key package built from `options` advertises, or
/// `None` for OpenMLS's defaults.
///
/// A last-resort key package carries a last_resort extension, and a key
/// package's extensions have to be among its leaf's capabilities (RFC 9420
/// §10). OpenMLS's default capabilities list no extension, so the type is
/// added here, to the defaults or to the caller's list: without it, whoever
/// adds the key package refuses it ("A key package extension is not supported
/// in the leaf's capabilities").
fn key_package_capabilities(options: &KeyPackageOptions) -> Result<Option<Capabilities>, String> {
    if !options.last_resort {
        return options.capabilities.as_ref().map(capabilities_to_native).transpose();
    }
    let mut caps = match &options.capabilities {
        Some(given) => MlsCapabilities {
            versions: given.versions.clone(),
            ciphersuites: given.ciphersuites.clone(),
            extensions: given.extensions.clone(),
            proposals: given.proposals.clone(),
            credentials: given.credentials.clone(),
        },
        None => MlsCapabilities {
            versions: Vec::new(),
            ciphersuites: Vec::new(),
            extensions: Vec::new(),
            proposals: Vec::new(),
            credentials: Vec::new(),
        },
    };
    if !caps.extensions.contains(&LAST_RESORT_EXTENSION_TYPE) {
        caps.extensions.push(LAST_RESORT_EXTENSION_TYPE);
    }
    capabilities_to_native(&caps).map(Some)
}

/// A proposal's reference as `removePendingProposal` reads it.
fn serialize_proposal_ref(proposal_ref: &ProposalRef) -> Result<Vec<u8>, String> {
    proposal_ref
        .tls_serialize_detached()
        .map_err(|e| format!("Failed to serialize proposal ref: {e}"))
}

/// The binding's name for a proposal's type.
fn proposal_type_of(proposal: &Proposal) -> MlsProposalType {
    match proposal {
        Proposal::Add(_) => MlsProposalType::Add,
        Proposal::Remove(_) => MlsProposalType::Remove,
        Proposal::Update(_) => MlsProposalType::Update,
        Proposal::PreSharedKey(_) => MlsProposalType::PreSharedKey,
        Proposal::ReInit(_) => MlsProposalType::Reinit,
        Proposal::ExternalInit(_) => MlsProposalType::ExternalInit,
        Proposal::GroupContextExtensions(_) => MlsProposalType::GroupContextExtensions,
        _ => MlsProposalType::Custom,
    }
}

/// The error for a PrivateMessage this client authored itself, which the
/// encryption-only sender ratchet cannot read back.
///
/// `looks_like_own_commit` only picks the wording. It comes from the content
/// type in the message header, which is not authenticated until decryption —
/// and this message is never decrypted — so it must not decide anything. Nor
/// is the sender: every member holds the sender-data key, so any of them can
/// send a message that names this member's leaf. The hint says so, so that no
/// application merges on the strength of this error.
fn own_private_message_error(looks_like_own_commit: bool) -> String {
    if looks_like_own_commit {
        "Cannot decrypt own message: its header names this member as the sender of a \
         commit, but any member can write such a header, so the message proves nothing. \
         If the delivery service confirmed this member's pending commit, apply it with \
         mergePendingCommit"
            .to_string()
    } else {
        "Cannot decrypt own message: the sender ratchet is encryption-only, \
         so a PrivateMessage this client authored cannot be read back"
            .to_string()
    }
}

/// The binding's form of a sender, as MLS authenticated it.
fn sender_info(sender: &Sender) -> Result<MlsSenderInfo, String> {
    Ok(match sender {
        Sender::Member(index) => MlsSenderInfo { kind: MlsSenderKind::Member, index: Some(index.u32()) },
        Sender::External(index) => {
            // OpenMLS keeps the number to itself; on the wire it is a u32.
            let wire = index
                .tls_serialize_detached()
                .map_err(|e| format!("Failed to serialize external sender index: {}", e))?;
            let index = <[u8; 4]>::try_from(wire.as_slice())
                .map_err(|_| "External sender index is not four bytes".to_string())?;
            MlsSenderInfo { kind: MlsSenderKind::External, index: Some(u32::from_be_bytes(index)) }
        }
        Sender::NewMemberProposal => MlsSenderInfo { kind: MlsSenderKind::NewMemberProposal, index: None },
        Sender::NewMemberCommit => MlsSenderInfo { kind: MlsSenderKind::NewMemberCommit, index: None },
    })
}

/// `leaf`'s credential, keys, capabilities and extensions. With
/// `only_unknown_extensions`, only the extensions OpenMLS does not interpret
/// itself — the application's own.
fn leaf_node_info(leaf: &LeafNode, only_unknown_extensions: bool) -> Result<MlsLeafNodeInfo, String> {
    let cred_bytes = leaf.credential()
        .tls_serialize_detached()
        .map_err(|e| format!("Failed to serialize credential: {}", e))?;

    let caps = leaf.capabilities();
    let capabilities = MlsCapabilities {
        versions: caps.versions().iter().map(|v| match v {
            ProtocolVersion::Mls10 => 1u16,
            ProtocolVersion::Other(n) => *n,
        }).collect(),
        ciphersuites: caps.ciphersuites().iter().map(|c| c.value()).collect(),
        extensions: caps.extensions().iter().map(|e| u16::from(*e)).collect(),
        proposals: caps.proposals().iter().map(|p| u16::from(*p)).collect(),
        credentials: caps.credentials().iter().map(|c| u16::from(*c)).collect(),
    };

    let mut extensions = Vec::new();
    for ext in leaf.extensions().iter() {
        if let Extension::Unknown(ext_type, data) = ext {
            extensions.push(MlsExtension {
                extension_type: *ext_type,
                data: data.0.clone(),
            });
        } else if !only_unknown_extensions {
            extensions.push(extension_to_mls(ext)?);
        }
    }

    let encryption_key_bytes = leaf
        .encryption_key()
        .tls_serialize_detached()
        .map_err(|e| format!("Failed to serialize encryption key: {}", e))?;

    Ok(MlsLeafNodeInfo {
        credential: cred_bytes,
        signature_key: leaf.signature_key().as_slice().to_vec(),
        encryption_key: encryption_key_bytes,
        capabilities,
        extensions,
    })
}

/// The member at `index` in `group`'s current tree, if there is one.
fn member_info(group: &MlsGroup, index: LeafNodeIndex) -> Result<Option<MlsMemberInfo>, String> {
    group.member_at(index)
        .map(|member| {
            let credential = member.credential
                .tls_serialize_detached()
                .map_err(|e| format!("Failed to serialize member credential: {}", e))?;
            Ok(MlsMemberInfo {
                index: member.index.u32(),
                credential,
                signature_key: member.signature_key.clone(),
            })
        })
        .transpose()
}

/// What `queued` proposes, and who it affects in `group` as it stands — which
/// must still be the epoch the proposal belongs to.
fn proposal_info(group: &MlsGroup, queued: &QueuedProposal) -> Result<StagedProposalInfo, String> {
    let (leaf, affected_member, extensions) = match queued.proposal() {
        Proposal::Add(add) => (Some(leaf_node_info(add.key_package().leaf_node(), false)?), None, Vec::new()),
        Proposal::Update(update) => {
            let affected = match queued.sender() {
                Sender::Member(index) => member_info(group, *index)?,
                _ => None,
            };
            (Some(leaf_node_info(update.leaf_node(), false)?), affected, Vec::new())
        }
        Proposal::Remove(remove) => (None, member_info(group, remove.removed())?, Vec::new()),
        Proposal::GroupContextExtensions(gce) => {
            let extensions = gce.extensions().iter()
                .map(extension_to_mls)
                .collect::<Result<_, _>>()?;
            (None, None, extensions)
        }
        _ => (None, None, Vec::new()),
    };
    Ok(StagedProposalInfo {
        proposal_type: proposal_type_of(queued.proposal()),
        sender_index: match queued.sender() {
            Sender::Member(index) => Some(index.u32()),
            _ => None,
        },
        sender: sender_info(queued.sender())?,
        by_reference: matches!(queued.proposal_or_ref_type(), ProposalOrRefType::Reference),
        leaf,
        affected_member,
        extensions,
    })
}

/// Everything an application may want to judge about `staged` before it is
/// merged into `group` — which must still be in the epoch the commit ends, so
/// the leaves it removes can still be looked up.
fn staged_commit_info(group: &MlsGroup, staged: &StagedCommit) -> Result<StagedCommitInfo, String> {
    let mut add_credentials = Vec::new();
    for add in staged.add_proposals() {
        let cred_bytes = add.add_proposal().key_package().leaf_node().credential()
            .tls_serialize_detached()
            .map_err(|e| format!("Failed to serialize add credential: {}", e))?;
        add_credentials.push(cred_bytes);
    }

    let mut remove_indices = Vec::new();
    let mut remove_credentials = Vec::new();
    for remove in staged.remove_proposals() {
        let removed = remove.remove_proposal().removed();
        let member = group.member_at(removed)
            .ok_or_else(|| format!("Commit removes leaf {} which holds no member", removed.u32()))?;
        let cred_bytes = member.credential
            .tls_serialize_detached()
            .map_err(|e| format!("Failed to serialize removed member's credential: {}", e))?;
        remove_indices.push(removed.u32());
        remove_credentials.push(cred_bytes);
    }

    let proposals = staged.queued_proposals()
        .map(|queued| proposal_info(group, queued))
        .collect::<Result<_, _>>()?;

    let committer_credential = staged.update_path_leaf_node()
        .map(|leaf| leaf.credential().tls_serialize_detached())
        .transpose()
        .map_err(|e| format!("Failed to serialize committer credential: {}", e))?;

    // Every extension, OpenMLS's own types included: `ExternalSenders` in
    // particular decides who may propose without being a member, so hiding
    // the typed ones would hide exactly the change a policy has to see.
    let context_extensions = staged.group_context().extensions();
    let group_context_extensions = context_extensions.iter()
        .map(extension_to_mls)
        .collect::<Result<_, _>>()?;
    let external_senders = match context_extensions.external_senders() {
        Some(senders) => external_senders_to_mls(senders)?,
        None => Vec::new(),
    };

    Ok(StagedCommitInfo {
        add_credentials,
        remove_indices,
        has_update: staged.update_proposals().next().is_some(),
        self_removed: staged.self_removed(),
        psk_count: staged.psk_proposals().count() as u32,
        remove_credentials,
        proposals,
        committer_credential,
        group_context_extensions,
        external_senders,
    })
}

// ═══════════════════════════════════════════════════════════════
// RESULT TYPES
// ═══════════════════════════════════════════════════════════════

pub struct CreateGroupResult {
    pub group_id: Vec<u8>,
}

pub struct JoinGroupResult {
    pub group_id: Vec<u8>,
}

pub struct ExternalJoinResult {
    pub group_id: Vec<u8>,
    pub commit: Vec<u8>,
    pub group_info: Option<Vec<u8>>,
}

pub struct AddMembersResult {
    pub commit: Vec<u8>,
    pub welcome: Vec<u8>,
    pub group_info: Option<Vec<u8>>,
}

pub struct CommitResult {
    pub commit: Vec<u8>,
    /// The Welcome for the members the commit adds, if any.
    ///
    /// Send it only once the delivery service has accepted `commit`. A
    /// Welcome sent earlier admits its recipients into an epoch that never
    /// happens if another commit wins the race — they join a group nobody
    /// else is in. With `FlexibleCommitOptions.keepPending` the order is:
    /// send the commit, wait for the delivery service to accept it,
    /// `mergePendingCommit`, then send the Welcome.
    pub welcome: Option<Vec<u8>>,
    /// The GroupInfo of the epoch the commit creates, when it was asked for.
    ///
    /// Publish it, like the Welcome, only once the delivery service has
    /// accepted `commit`: a party joining by external commit from it would
    /// otherwise enter an epoch that may never happen.
    ///
    /// It is not encrypted. With `FlexibleCommitOptions.groupInfoExtensions`
    /// it carries those extensions, and it is created only when
    /// `createGroupInfo` asks for it.
    pub group_info: Option<Vec<u8>>,
}

pub struct ProposalResult {
    pub proposal_message: Vec<u8>,
    /// The proposal's reference (RFC 9420 §5.2), serialized: what
    /// `removePendingProposal` takes to withdraw it from this member's store
    /// before a commit carries it.
    ///
    /// Withdrawing is local. The other members keep the proposal they
    /// received, a commit of theirs can still carry it by reference, and this
    /// member then cannot process that commit. So withdraw only a proposal
    /// whose message has not been sent.
    pub proposal_ref: Vec<u8>,
}

pub struct CreateMessageResult {
    pub ciphertext: Vec<u8>,
}

pub struct ProcessedMessageResult {
    pub message_type: ProcessedMessageType,
    pub sender_index: Option<u32>,
    pub epoch: u64,
    pub application_message: Option<Vec<u8>>,
    pub has_staged_commit: bool,
    pub has_proposal: bool,
    pub proposal_type: Option<MlsProposalType>,
}

pub struct ProcessedMessageInspectResult {
    pub message_type: ProcessedMessageType,
    /// The sender's leaf index when a member sent it; `None` for an external
    /// sender or a new member — `sender` tells those apart.
    pub sender_index: Option<u32>,
    pub epoch: u64,
    pub application_message: Option<Vec<u8>>,
    pub staged_commit_info: Option<StagedCommitInfo>,
    pub proposal_type: Option<MlsProposalType>,
    /// Who sent the message, as MLS authenticated it — external senders and
    /// new members included. Always set by the engine; optional only so code
    /// that builds a result itself keeps compiling.
    pub sender: Option<MlsSenderInfo>,
    /// For a proposal message: what it proposes — the new leaf of an Update,
    /// the extensions of a GroupContextExtensions proposal, the member a
    /// Remove takes out — as `stagedCommitInfo.proposals` reports them for a
    /// commit.
    pub proposal_info: Option<StagedProposalInfo>,
}

pub struct KeyPackageResult {
    pub key_package_bytes: Vec<u8>,
}

pub struct LeaveGroupResult {
    pub message: Vec<u8>,
}

pub struct GroupConfigurationResult {
    pub ciphersuite: MlsCiphersuite,
    pub wire_format_policy: MlsWireFormatPolicy,
    pub padding_size: u32,
    pub sender_ratchet_max_out_of_order: u32,
    pub sender_ratchet_max_forward_distance: u32,
}

// ═══════════════════════════════════════════════════════════════
// PAST EPOCH SECRETS
// ═══════════════════════════════════════════════════════════════

/// How many past epochs' message secrets a group keeps, as
/// `pastEpochDeletionPolicy` reports it.
///
/// An application message is encrypted under the epoch its sender was in. Once
/// a commit advances the group, a message that was already in flight can only
/// be read from the secrets of the epoch it was sent in — so a group that
/// keeps none of them discards such a message. Keeping a few is what lets a
/// delivery service reorder or delay messages across a commit.
///
/// ⚠ **Keeping any is a forward-secrecy trade-off, not a tuning knob.** The
/// secrets of a past epoch decrypt every message of that epoch, including ones
/// an attacker recorded earlier, for as long as they remain stored. OpenMLS
/// asks for the number to be as low as the delivery service allows; the
/// default keeps none.
pub struct PastEpochDeletionPolicyResult {
    /// True when the group keeps every past epoch's secrets — the state
    /// `setPastEpochDeletionPolicyKeepAll` puts it in. `maxEpochs` says
    /// nothing then.
    pub keep_all: bool,
    /// How many past epochs' secrets are kept, when `keepAll` is false. Zero
    /// — the default for a new group — keeps none.
    pub max_epochs: u32,
}

/// Reads OpenMLS's policy into the pair Dart sees.
///
/// Everything this cannot report as a number is reported as keep-all, which
/// keeps the surface total in both directions: the number that comes out is
/// always one `max_epochs_to_native` would take back in.
///
/// Two quite different inputs land in that arm.
///
/// ⚠ The first is not an edge case on every target. OpenMLS serializes
/// `KeepAll` as `usize::MAX` and deserializes only `u64::MAX` back into it, so
/// where `usize` is 32 bits — the Web, 32-bit Android — a stored `KeepAll`
/// comes back as `MaxEpochs(usize::MAX)` instead. Mapping it here is what makes
/// the Dart surface answer the same way on every platform.
///
/// The second is a number too large to be one of ours: everything this crate
/// writes came through `max_epochs_to_native` and so fits a `u32` with room to
/// spare, and a store written by another OpenMLS application could hold more.
/// Keep-all is the honest summary of such a value — it is more epochs than
/// anything will ever hold — and it beats reporting a number the setter would
/// refuse.
fn native_to_past_epoch_policy(policy: &PastEpochDeletionPolicy) -> PastEpochDeletionPolicyResult {
    let keep_all = PastEpochDeletionPolicyResult { keep_all: true, max_epochs: 0 };
    match policy {
        PastEpochDeletionPolicy::KeepAll => keep_all,
        PastEpochDeletionPolicy::MaxEpochs(n) => match u32::try_from(*n) {
            Ok(max_epochs) if max_epochs < u32::MAX => PastEpochDeletionPolicyResult {
                keep_all: false,
                max_epochs,
            },
            _ => keep_all,
        },
    }
}

fn max_epochs_to_native(max_epochs: u32) -> Result<PastEpochDeletionPolicy, String> {
    if max_epochs == u32::MAX {
        return Err(format!(
            "maxEpochs must be below {}: that value is what OpenMLS stores to mean \
             keep-all on a 32-bit target, so the two settings would be one stored \
             value there and two everywhere else. Use \
             setPastEpochDeletionPolicyKeepAll instead.",
            u32::MAX
        ));
    }
    Ok(PastEpochDeletionPolicy::MaxEpochs(max_epochs as usize))
}

/// Applies the optional "and keep at most this many" modifier.
///
/// Only the three selective deletions take it. `PastEpochDeletion::delete_all`
/// carries no time config, and OpenMLS applies the modifier only to requests
/// that have one — so `delete_all().max_past_epochs(n)` deletes everything and
/// ignores `n`. `deleteAllPastEpochSecrets` therefore does not offer it.
fn with_cap(deletion: PastEpochDeletion, max_past_epochs: Option<u32>) -> PastEpochDeletion {
    match max_past_epochs {
        Some(n) => deletion.max_past_epochs(n as usize),
        None => deletion,
    }
}

// ═══════════════════════════════════════════════════════════════
// MLS ENGINE
// ═══════════════════════════════════════════════════════════════

pub struct MlsEngine {
    db: parking_lot::RwLock<Option<std::sync::Arc<crate::encrypted_db::EncryptedDb>>>,
    /// Serializes the load → operate → save sequence of every operation.
    ///
    /// Each method loads a snapshot of the stored group state, lets OpenMLS
    /// mutate it in memory, then writes back the diff. Two calls that overlap
    /// would load the same base snapshot and the later write-back would drop
    /// the other one's changes — a merged commit, an advanced ratchet or a
    /// stored proposal would silently disappear and desynchronize the group.
    ///
    /// This is an async mutex on purpose: the guarded span contains `.await`
    /// points, and a blocking mutex would deadlock the single-threaded WASM
    /// event loop (where the same interleaving happens without threads).
    op_lock: futures::lock::Mutex<()>,
}

/// Exclusive session over one engine's storage.
///
/// Owns the snapshot provider *and* the engine-wide operation lock, so a
/// provider cannot exist without the lock being held. The guard lives until
/// the session is consumed by [`MlsEngine::commit`] (or dropped by a method
/// that only reads), which keeps the whole load → operate → save span
/// serialized.
struct OpSession<'a> {
    locks: OpLocks<'a>,
    provider: SnapshotOpenMlsProvider,
}

/// Everything an [`OpSession`] holds besides its snapshot.
///
/// Kept as one value so a method that has to move the provider out of the
/// session can bind the locks in the same `let` and keep them alive across the
/// write-back. Destructuring with `..` instead would drop them right there,
/// releasing the lock while the save is still running — which is the exact
/// interleaving this guards against.
struct OpLocks<'a> {
    /// Serializes operations on THIS engine — see [`MlsEngine::op_lock`].
    _guard: futures::lock::MutexGuard<'a, ()>,
    /// Serializes operations across browsing contexts of one origin, which the
    /// mutex above cannot see: another tab is another WASM instance with
    /// another engine, addressing the same IndexedDB database. Native needs no
    /// counterpart — its sidecar lock file refuses the second opener outright.
    #[cfg(target_arch = "wasm32")]
    _web_lock: crate::web_lock::WebLockGuard,
}

/// Delegates to the wrapped snapshot provider so `OpSession` can be handed to
/// OpenMLS directly — call sites never see the guard.
impl OpenMlsProvider for OpSession<'_> {
    type CryptoProvider = <SnapshotOpenMlsProvider as OpenMlsProvider>::CryptoProvider;
    type RandProvider = <SnapshotOpenMlsProvider as OpenMlsProvider>::RandProvider;
    type StorageProvider = <SnapshotOpenMlsProvider as OpenMlsProvider>::StorageProvider;

    fn storage(&self) -> &Self::StorageProvider {
        self.provider.storage()
    }

    fn crypto(&self) -> &Self::CryptoProvider {
        self.provider.crypto()
    }

    fn rand(&self) -> &Self::RandProvider {
        self.provider.rand()
    }
}

impl MlsEngine {
    // ═══════════════════════════════════════════════════════════
    // CONSTRUCTOR
    // ═══════════════════════════════════════════════════════════

    /// Create a new MlsEngine backed by an encrypted database.
    ///
    /// # Arguments
    ///
    /// * `dbPath` — Database location.
    ///   - **Native**: file path for SQLCipher (e.g. `"path/to/mls.db"`).
    ///     Use `":memory:"` for an ephemeral in-memory database (destroyed on drop,
    ///     useful for tests). A `"file:…"` URI is rejected: the path it resolves
    ///     to cannot be recovered without parsing the URI, so such a database
    ///     would get neither owner-only permissions nor the lock file below.
    ///   - **WASM**: IndexedDB database name (e.g. `"mls_account_123"`).
    ///     `":memory:"` generates a unique random name per instance to match the
    ///     native ephemeral behavior.
    ///   - Tip: include an account identifier in the path to isolate data per user
    ///     (e.g. `"mls_{account_id}.db"` on native, `"mls_{account_id}"` on web).
    ///
    /// * `encryptionKey` — 32-byte AES-256 key that protects data at rest.
    ///   The caller is responsible for generating, storing, and providing this key.
    ///   Recommended pattern: generate a random key on first launch and persist it
    ///   in platform secure storage (e.g. Keychain on iOS/macOS, Android Keystore,
    ///   or `flutter_secure_storage`).
    ///
    /// # One engine per database file
    ///
    /// On native the database is locked exclusively. A second engine on the same
    /// file — another instance, isolate or process — fails with "Database is
    /// already open by another connection or process" rather than silently
    /// overwriting this one's group state. `MlsEngine.close` releases the
    /// lock; an overlapping opener waits out a five-second timeout first, so
    /// handing the file over during teardown still works.
    ///
    /// On Unix this is held partly by a lock file next to the database, named
    /// `<db_path>.lock`, which the engine creates and never deletes. An empty
    /// file beside the database is expected; deleting it while an engine is
    /// running removes the protection.
    ///
    /// On the Web the shape is different, because the unit is a browser tab and
    /// not a process: tabs are opened and closed by the person using the
    /// application, so a second one is not refused. Every operation takes an
    /// exclusive Web Lock named after the IndexedDB database instead, which
    /// serializes the load → operate → save cycles of every tab and worker on
    /// the origin. One that cannot get in within five seconds fails with
    /// "Database is busy" rather than waiting behind a wedged tab forever.
    ///
    /// That guarantee needs a secure context, which is where `navigator.locks`
    /// exists at all: `https`, or `http` on `localhost`. Served over plain
    /// `http` from any other host the API is absent, and operations run exactly
    /// as they did before it was used — without the cross-tab guarantee, never
    /// with an error.
    ///
    /// Calls on one engine are safe to make concurrently: each runs its
    /// load → operate → save cycle under an engine-wide lock.
    pub async fn create(db_path: String, encryption_key: Vec<u8>) -> Result<MlsEngine, String> {
        let db = crate::encrypted_db::EncryptedDb::open(db_path, encryption_key).await?;
        Ok(MlsEngine {
            db: parking_lot::RwLock::new(Some(std::sync::Arc::new(db))),
            op_lock: futures::lock::Mutex::new(()),
        })
    }

    // ═══════════════════════════════════════════════════════════
    // INTERNAL HELPERS
    // ═══════════════════════════════════════════════════════════

    fn db(&self) -> Result<std::sync::Arc<crate::encrypted_db::EncryptedDb>, String> {
        self.db.read().as_ref().cloned().ok_or_else(|| "MlsEngine is closed".to_string())
    }

    /// Take every lock an operation needs, in one order everywhere.
    ///
    /// Engine-wide mutex first, cross-context lock second. The order is what
    /// keeps it deadlock-free: taking them the other way round in one of the
    /// two callers would be enough for two operations to hold one each.
    #[cfg(not(target_arch = "wasm32"))]
    async fn acquire_locks(&self) -> Result<OpLocks<'_>, String> {
        Ok(OpLocks { _guard: self.op_lock.lock().await })
    }

    /// See the native twin above. The Web build adds the cross-tab lock, whose
    /// wait can time out — which is why this returns a `Result` on both
    /// targets rather than only here.
    #[cfg(target_arch = "wasm32")]
    async fn acquire_locks(&self) -> Result<OpLocks<'_>, String> {
        let guard = self.op_lock.lock().await;
        let name = self.db()?.lock_name();
        let web_lock =
            crate::web_lock::acquire(&name, crate::web_lock::WEB_LOCK_TIMEOUT_MS).await?;
        Ok(OpLocks { _guard: guard, _web_lock: web_lock })
    }

    /// Take the operation locks and load a group's snapshot under them.
    async fn load_for_group(&self, group_id: &[u8]) -> Result<OpSession<'_>, String> {
        let locks = self.acquire_locks().await?;
        let entries = self.db()?.load_for_group(group_id).await?;
        Ok(OpSession {
            locks,
            provider: SnapshotOpenMlsProvider::new(SnapshotStorageProvider::from_entries(entries)),
        })
    }

    /// Take the operation locks and load the global (group-independent)
    /// snapshot under them.
    async fn load_global(&self) -> Result<OpSession<'_>, String> {
        let locks = self.acquire_locks().await?;
        let entries = self.db()?.load_global().await?;
        Ok(OpSession {
            locks,
            provider: SnapshotOpenMlsProvider::new(SnapshotStorageProvider::from_entries(entries)),
        })
    }

    /// Take the operation locks and load the snapshot a Welcome is joined
    /// in: the global scope *and* the group the Welcome invites into.
    ///
    /// A Welcome names its group only inside the GroupInfo it encrypts, so
    /// it is opened once in the global scope — where the key package it is
    /// addressed to lives — to read the ID, and that snapshot is thrown away
    /// unwritten. The join then runs on one that also holds the stored group
    /// of that ID, if any, so OpenMLS's check that the ID is not already in
    /// use (RFC 9420 §12.4.3.1) can see it. With the global scope alone it
    /// sees nothing, and the join writes over the stored group.
    ///
    /// The locks are held from the first load to the end of the operation,
    /// so nothing can change the group between the two.
    async fn load_for_welcome(
        &self,
        join_config: &MlsGroupJoinConfig,
        welcome: &Welcome,
    ) -> Result<OpSession<'_>, String> {
        let OpSession { locks, provider } = self.load_global().await?;
        let group_id = ProcessedWelcome::new_from_welcome(&provider, join_config, welcome.clone())
            .map_err(|e| format!("Failed to process welcome: {}", e))?
            .unverified_group_info()
            .group_id()
            .clone();
        drop(provider);
        let entries = self.db()?.load_for_group(group_id.as_slice()).await?;
        Ok(OpSession {
            locks,
            provider: SnapshotOpenMlsProvider::new(SnapshotStorageProvider::from_entries(entries)),
        })
    }

    /// Take the operation locks and load the snapshot an external commit
    /// joins in: the global scope and the group the GroupInfo names.
    ///
    /// OpenMLS does not check an external join's group ID against storage,
    /// and an external join is how a client rejoins a group it lost track
    /// of. So a group stored under that ID is refused here unless `replace`.
    /// Then every entry under the ID is taken out of the snapshot before the
    /// join writes the new group — the stored group's when told to replace
    /// it, and otherwise entries no group loads from — and the write that
    /// stores the new group deletes them with it: a join that fails keeps
    /// them. On the global scope alone, as before, the join wrote over the
    /// stored group and left its queued proposals and an earlier epoch's key
    /// pairs behind under the new group's ID.
    async fn load_for_external_join(
        &self,
        group_info: &VerifiableGroupInfo,
        replace: bool,
    ) -> Result<OpSession<'_>, String> {
        let group_id = group_info.group_id().clone();
        let session = self.load_for_group(group_id.as_slice()).await?;
        // Replacing needs no load, so a stored group that no longer loads
        // can be replaced too.
        if !replace
            && MlsGroup::load(session.storage(), &group_id)
                .map_err(|e| {
                    format!(
                        "Failed to join group via external commit: the group stored under \
                         this ID does not load ({e}). To replace it, pass \
                         replaceStoredGroup: true (group ID {})",
                        hex(group_id.as_slice())
                    )
                })?
                .is_some()
        {
            return Err(format!(
                "Failed to join group via external commit: {EXTERNAL_JOIN_STORED_GROUP} \
                 (group ID {})",
                hex(group_id.as_slice())
            ));
        }
        session.storage().forget_group(group_id.as_slice());
        Ok(session)
    }

    /// Diff a session's snapshot, write it back, and release the operation
    /// lock.
    async fn commit(&self, session: OpSession<'_>, group_id: Option<&[u8]>) -> Result<(), String> {
        // Binding the locks keeps them alive until this function returns, so
        // the write-back still happens under them.
        let OpSession { locks: _locks, provider } = session;
        let updates = provider.into_storage().into_updates();
        if updates.upserts.is_empty() && updates.deletes.is_empty() {
            return Ok(());
        }
        self.db()?.save_updates(updates, group_id).await
    }

    // ═══════════════════════════════════════════════════════════
    // KEY PACKAGES
    // ═══════════════════════════════════════════════════════════

    /// Builds a key package with OpenMLS's defaults for everything except the
    /// ciphersuite and the credential.
    ///
    /// Those defaults include the advertised capabilities, and the ciphersuite
    /// list inside them is every suite `supportedCiphersuites` returns — ten of
    /// them experimental post-quantum suites on provisional code points. A peer
    /// reading this key package may therefore pick one of those for a group.
    ///
    /// To advertise a narrower set, or to change the lifetime, mark the package
    /// last-resort, or attach extensions, use `createKeyPackageWithOptions`
    /// instead: `KeyPackageOptions.capabilities` is where the ciphersuite list
    /// goes.
    pub async fn create_key_package(
        &self,
        ciphersuite: MlsCiphersuite,
        signer_bytes: Vec<u8>,
        credential_identity: Vec<u8>,
        signer_public_key: Vec<u8>,
        credential_bytes: Option<Vec<u8>>,
    ) -> Result<KeyPackageResult, String> {
        let cs = ciphersuite_to_native(&ciphersuite);
        let signer = signer_from_bytes(signer_bytes)?;
        let credential_with_key = build_credential_with_key(
            &credential_identity, &signer_public_key, credential_bytes.as_deref(),
        )?;

        let provider = self.load_global().await?;

        let key_package_bundle = KeyPackage::builder()
            .build(cs, &provider, &signer, credential_with_key)
            .map_err(|e| format!("Failed to create key package: {}", e))?;

        let kp_bytes = key_package_bundle
            .key_package()
            .tls_serialize_detached()
            .map_err(|e| format!("Failed to serialize key package: {}", e))?;

        self.commit(provider, None).await?;

        Ok(KeyPackageResult {
            key_package_bytes: kp_bytes,
        })
    }

    /// Builds a key package, overriding the defaults `createKeyPackage` leaves
    /// alone.
    ///
    /// Every field of `KeyPackageOptions` is optional and an unset one keeps
    /// OpenMLS's default. `capabilities` is the one with a wire consequence:
    /// setting `MlsCapabilities.ciphersuites` to an explicit list of raw code
    /// points is the only way to stop a key package advertising every suite
    /// this provider supports, experimental ones included.
    pub async fn create_key_package_with_options(
        &self,
        ciphersuite: MlsCiphersuite,
        signer_bytes: Vec<u8>,
        credential_identity: Vec<u8>,
        signer_public_key: Vec<u8>,
        options: KeyPackageOptions,
        credential_bytes: Option<Vec<u8>>,
    ) -> Result<KeyPackageResult, String> {
        let cs = ciphersuite_to_native(&ciphersuite);
        let signer = signer_from_bytes(signer_bytes)?;
        let credential_with_key = build_credential_with_key(
            &credential_identity, &signer_public_key, credential_bytes.as_deref(),
        )?;

        let provider = self.load_global().await?;
        let mut builder = KeyPackage::builder();

        if let Some(lifetime_secs) = options.lifetime_seconds {
            builder = builder.key_package_lifetime(Lifetime::new(lifetime_secs));
        }
        if options.last_resort {
            builder = builder.mark_as_last_resort();
        }
        if let Some(caps) = key_package_capabilities(&options)? {
            builder = builder.leaf_node_capabilities(caps);
        }
        if let Some(ref leaf_exts) = options.leaf_node_extensions {
            let extensions = Extensions::from_vec(extensions_from_mls(leaf_exts)?)
                .map_err(|e| format!("Failed to create leaf node extensions: {}", e))?;
            builder = builder.leaf_node_extensions(extensions);
        }
        if let Some(ref kp_exts) = options.key_package_extensions {
            let extensions = Extensions::from_vec(extensions_from_mls(kp_exts)?)
                .map_err(|e| format!("Failed to create key package extensions: {}", e))?;
            builder = builder.key_package_extensions(extensions);
        }

        let key_package_bundle = builder
            .build(cs, &provider, &signer, credential_with_key)
            .map_err(|e| format!("Failed to create key package: {}", e))?;

        let kp_bytes = key_package_bundle
            .key_package()
            .tls_serialize_detached()
            .map_err(|e| format!("Failed to serialize key package: {}", e))?;

        self.commit(provider, None).await?;

        Ok(KeyPackageResult {
            key_package_bytes: kp_bytes,
        })
    }

    // ═══════════════════════════════════════════════════════════
    // GROUP CREATION
    // ═══════════════════════════════════════════════════════════

    /// Creates a group with this client as its only member, under `groupId`
    /// when one is given and a random ID otherwise.
    ///
    /// Fails when this engine already stores a group under `groupId`. To
    /// reuse the ID, delete that group with `deleteGroup` first.
    pub async fn create_group(
        &self,
        config: MlsGroupConfig,
        signer_bytes: Vec<u8>,
        credential_identity: Vec<u8>,
        signer_public_key: Vec<u8>,
        group_id: Option<Vec<u8>>,
        credential_bytes: Option<Vec<u8>>,
    ) -> Result<CreateGroupResult, String> {
        let signer = signer_from_bytes(signer_bytes)?;
        let credential_with_key = build_credential_with_key(
            &credential_identity, &signer_public_key, credential_bytes.as_deref(),
        )?;

        // A group stored under the requested ID has to be in the snapshot:
        // that is where OpenMLS looks before it creates one under the same
        // ID, and with the global scope alone the commit below would write
        // over it.
        let provider = match &group_id {
            Some(gid) => self.load_for_group(gid).await?,
            None => self.load_global().await?,
        };
        let create_config = config.to_create_config();

        signer
            .store(provider.storage())
            .map_err(|e| format!("Failed to store signer: {}", e))?;

        let mls_group = if let Some(gid) = group_id {
            MlsGroup::new_with_group_id(
                &provider,
                &signer,
                &create_config,
                GroupId::from_slice(&gid),
                credential_with_key,
            )
        } else {
            MlsGroup::new(&provider, &signer, &create_config, credential_with_key)
        };

        let mls_group = mls_group.map_err(new_group_error)?;
        let gid = mls_group.group_id().as_slice().to_vec();

        self.commit(provider, Some(&gid)).await?;

        Ok(CreateGroupResult { group_id: gid })
    }

    /// `createGroup` with the rest of OpenMLS's group builder: lifetime,
    /// extensions and capabilities.
    ///
    /// Fails when this engine already stores a group under `groupId`, as
    /// `createGroup` does.
    #[allow(clippy::too_many_arguments)]
    pub async fn create_group_with_builder(
        &self,
        config: MlsGroupConfig,
        signer_bytes: Vec<u8>,
        credential_identity: Vec<u8>,
        signer_public_key: Vec<u8>,
        group_id: Option<Vec<u8>>,
        lifetime_seconds: Option<u64>,
        group_context_extensions: Option<Vec<MlsExtension>>,
        leaf_node_extensions: Option<Vec<MlsExtension>>,
        capabilities: Option<MlsCapabilities>,
        credential_bytes: Option<Vec<u8>>,
    ) -> Result<CreateGroupResult, String> {
        let signer = signer_from_bytes(signer_bytes)?;
        let credential_with_key = build_credential_with_key(
            &credential_identity, &signer_public_key, credential_bytes.as_deref(),
        )?;

        // See `create_group`: OpenMLS checks the requested ID against what
        // the snapshot holds.
        let provider = match &group_id {
            Some(gid) => self.load_for_group(gid).await?,
            None => self.load_global().await?,
        };

        signer
            .store(provider.storage())
            .map_err(|e| format!("Failed to store signer: {}", e))?;

        let cs = super::types::ciphersuite_to_native(&config.ciphersuite);
        let wf = super::types::wire_format_to_native(&config.wire_format_policy);

        let mut builder = MlsGroup::builder()
            .ciphersuite(cs)
            .with_wire_format_policy(wf)
            .use_ratchet_tree_extension(config.use_ratchet_tree_extension)
            .max_past_epochs(config.max_past_epochs as usize)
            .padding_size(config.padding_size as usize)
            .sender_ratchet_configuration(SenderRatchetConfiguration::new(
                config.sender_ratchet_max_out_of_order,
                config.sender_ratchet_max_forward_distance,
            ));

        if let Some(gid) = group_id {
            builder = builder.with_group_id(GroupId::from_slice(&gid));
        }
        if let Some(lifetime_secs) = lifetime_seconds {
            builder = builder.lifetime(Lifetime::new(lifetime_secs));
        }
        if let Some(ref gc_exts) = group_context_extensions {
            let extensions = Extensions::from_vec(extensions_from_mls(gc_exts)?)
                .map_err(|e| format!("Failed to create group context extensions: {}", e))?;
            builder = builder.with_group_context_extensions(extensions);
        }
        if let Some(ref leaf_exts) = leaf_node_extensions {
            let extensions = Extensions::from_vec(extensions_from_mls(leaf_exts)?)
                .map_err(|e| format!("Failed to create leaf node extensions: {}", e))?;
            builder = builder
                .with_leaf_node_extensions(extensions)
                .map_err(|e| format!("Failed to set leaf node extensions: {}", e))?;
        }
        if let Some(ref caps) = capabilities {
            builder = builder.with_capabilities(capabilities_to_native(caps)?);
        }

        let mls_group = builder
            .build(&provider, &signer, credential_with_key)
            .map_err(new_group_error)?;

        let gid = mls_group.group_id().as_slice().to_vec();

        self.commit(provider, Some(&gid)).await?;

        Ok(CreateGroupResult { group_id: gid })
    }

    // ═══════════════════════════════════════════════════════════
    // JOINING A GROUP
    // ═══════════════════════════════════════════════════════════

    /// Joins the group a Welcome invites this client into.
    ///
    /// Fails when this engine already stores a group with the Welcome's
    /// group ID. RFC 9420 has a joiner check that the ID is not one it is
    /// already using, and accepting would replace the stored group with the
    /// one the Welcome describes — whoever sent it. That includes a group
    /// this client has left or been removed from: to accept a new invitation
    /// into it, delete the old state with `deleteGroup` first.
    /// `inspectWelcome` reads the group ID without joining.
    pub async fn join_group_from_welcome(
        &self,
        config: MlsGroupConfig,
        welcome_bytes: Vec<u8>,
        ratchet_tree_bytes: Option<Vec<u8>>,
        signer_bytes: Vec<u8>,
    ) -> Result<JoinGroupResult, String> {
        let signer = signer_from_bytes(signer_bytes)?;

        let welcome_msg = MlsMessageIn::tls_deserialize_exact_bytes(&welcome_bytes)
            .map_err(|e| format!("Failed to deserialize welcome: {}", e))?;
        let welcome = match welcome_msg.extract() {
            MlsMessageBodyIn::Welcome(w) => w,
            _ => return Err("Message is not a Welcome".to_string()),
        };

        let join_config = config.to_join_config();
        let ratchet_tree: Option<RatchetTreeIn> = ratchet_tree_bytes
            .map(|rt_bytes| {
                RatchetTreeIn::tls_deserialize_exact_bytes(&rt_bytes)
                    .map_err(|e| format!("Failed to deserialize ratchet tree: {}", e))
            })
            .transpose()?;

        let provider = self.load_for_welcome(&join_config, &welcome).await?;

        signer
            .store(provider.storage())
            .map_err(|e| format!("Failed to store signer: {}", e))?;

        let staged = StagedWelcome::new_from_welcome(&provider, &join_config, welcome, ratchet_tree)
            .map_err(|e| welcome_error("Failed to process welcome", e))?;
        let mls_group = staged
            .into_group(&provider)
            .map_err(|e| format!("Failed to join group from welcome: {}", e))?;

        let gid = mls_group.group_id().as_slice().to_vec();

        self.commit(provider, Some(&gid)).await?;

        Ok(JoinGroupResult { group_id: gid })
    }

    /// `joinGroupFromWelcome` with OpenMLS's join options.
    ///
    /// Fails when this engine already stores a group with the Welcome's
    /// group ID, as `joinGroupFromWelcome` does.
    pub async fn join_group_from_welcome_with_options(
        &self,
        config: MlsGroupConfig,
        welcome_bytes: Vec<u8>,
        ratchet_tree_bytes: Option<Vec<u8>>,
        signer_bytes: Vec<u8>,
        skip_lifetime_validation: bool,
    ) -> Result<JoinGroupResult, String> {
        let signer = signer_from_bytes(signer_bytes)?;

        let welcome_msg = MlsMessageIn::tls_deserialize_exact_bytes(&welcome_bytes)
            .map_err(|e| format!("Failed to deserialize welcome: {}", e))?;
        let welcome = match welcome_msg.extract() {
            MlsMessageBodyIn::Welcome(w) => w,
            _ => return Err("Message is not a Welcome".to_string()),
        };

        let join_config = config.to_join_config();
        let provider = self.load_for_welcome(&join_config, &welcome).await?;

        signer
            .store(provider.storage())
            .map_err(|e| format!("Failed to store signer: {}", e))?;

        let mut join_builder = StagedWelcome::build_from_welcome(&provider, &join_config, welcome)
            .map_err(|e| format!("Failed to process welcome: {}", e))?;

        if let Some(rt_bytes) = ratchet_tree_bytes {
            let ratchet_tree = RatchetTreeIn::tls_deserialize_exact_bytes(&rt_bytes)
                .map_err(|e| format!("Failed to deserialize ratchet tree: {}", e))?;
            join_builder = join_builder.with_ratchet_tree(ratchet_tree);
        }
        if skip_lifetime_validation {
            join_builder = join_builder.skip_lifetime_validation();
        }

        let staged = join_builder
            .build()
            .map_err(|e| welcome_error("Failed to build staged welcome", e))?;
        let mls_group = staged
            .into_group(&provider)
            .map_err(|e| format!("Failed to join group from welcome: {}", e))?;

        let gid = mls_group.group_id().as_slice().to_vec();

        self.commit(provider, Some(&gid)).await?;

        Ok(JoinGroupResult { group_id: gid })
    }

    pub async fn inspect_welcome(
        &self,
        config: MlsGroupConfig,
        welcome_bytes: Vec<u8>,
    ) -> Result<WelcomeInspectResult, String> {
        let provider = self.load_global().await?;

        let welcome_msg = MlsMessageIn::tls_deserialize_exact_bytes(&welcome_bytes)
            .map_err(|e| format!("Failed to deserialize welcome: {}", e))?;
        let welcome = match welcome_msg.extract() {
            MlsMessageBodyIn::Welcome(w) => w,
            _ => return Err("Message is not a Welcome".to_string()),
        };

        let join_config = config.to_join_config();
        let processed = ProcessedWelcome::new_from_welcome(&provider, &join_config, welcome)
            .map_err(|e| format!("Failed to process welcome: {}", e))?;

        let vgi = processed.unverified_group_info();
        Ok(WelcomeInspectResult {
            group_id: vgi.group_id().as_slice().to_vec(),
            ciphersuite: native_to_ciphersuite(vgi.ciphersuite())?,
            psk_count: processed.psks().len() as u32,
            epoch: vgi.epoch().as_u64(),
        })
    }

    /// Derives a secret from the epoch a Welcome invites this client into,
    /// **without joining the group**.
    ///
    /// This is `exportSecret` one step earlier: same derivation, same
    /// `label`/`context`/`keyLength` meaning, but reachable while the
    /// invitation is still only an invitation. It is what lets a client agree
    /// a key with the inviter — or prove to a third party that it can read the
    /// epoch — before it decides whether to accept.
    ///
    /// Like `inspectWelcome`, this writes nothing, and that is load-bearing
    /// rather than incidental. Processing a Welcome consumes the key package
    /// it was addressed to: OpenMLS deletes it from storage unless it is
    /// marked last-resort. Here that delete lands in this call's snapshot and
    /// is discarded with it, because neither this function nor `inspectWelcome`
    /// commits — so a later `joinGroupFromWelcome` on the same Welcome still
    /// finds its key package. Committing from either would silently burn the
    /// invitation.
    ///
    /// The secret comes from the unverified group info in the Welcome. The
    /// confirmation tag is only checked when the Welcome is staged into a
    /// group, which happens in `joinGroupFromWelcome` and not here.
    ///
    /// It sees the storage the real join opens the Welcome in: the global
    /// scope, where pre-shared keys live (they are stored ungrouped, like key
    /// packages and signature keys). So a Welcome that carries PSKs resolves
    /// them here or fails here for the same reason it would there — this
    /// function is never the narrower of the two. The join loads one thing
    /// more, the stored group of the Welcome's ID, and refuses a Welcome whose
    /// ID is already stored; this function does not check that.
    pub async fn export_welcome_secret(
        &self,
        config: MlsGroupConfig,
        welcome_bytes: Vec<u8>,
        label: String,
        context: Vec<u8>,
        key_length: u32,
    ) -> Result<Vec<u8>, String> {
        let provider = self.load_global().await?;

        let welcome_msg = MlsMessageIn::tls_deserialize_exact_bytes(&welcome_bytes)
            .map_err(|e| format!("Failed to deserialize welcome: {}", e))?;
        let welcome = match welcome_msg.extract() {
            MlsMessageBodyIn::Welcome(w) => w,
            _ => return Err("Message is not a Welcome".to_string()),
        };

        let join_config = config.to_join_config();
        let processed = ProcessedWelcome::new_from_welcome(&provider, &join_config, welcome)
            .map_err(|e| format!("Failed to process welcome: {}", e))?;

        processed
            .export_secret(provider.crypto(), &label, &context, key_length as usize)
            .map_err(|e| format!("Failed to export secret from welcome: {}", e))
    }

    /// The extensions in the GroupInfo of a Welcome
    /// (`FlexibleCommitOptions.groupInfoExtensions`), and the member that
    /// signed that GroupInfo, read **without joining the group**.
    ///
    /// They are returned only once the Welcome has been staged as
    /// `joinGroupFromWelcome` stages it. Staging checks:
    /// - the GroupInfo's signature, against the leaf the GroupInfo names as
    ///   its signer, in the ratchet tree that came with the Welcome;
    /// - that tree, against the GroupInfo;
    /// - the confirmation tag, against the epoch's secrets.
    ///
    /// A Welcome that fails a check fails here.
    ///
    /// That proves the extensions are what `signer` wrote. It proves nothing
    /// about who `signer` is. Usually it is the committer, but two other
    /// parties can produce a Welcome that passes the same checks:
    /// - any member of the new epoch, under its own signature;
    /// - anyone who holds one of this client's key packages, from a group of
    ///   their own.
    ///
    /// Before acting on the extensions, authenticate `signer` as before any
    /// join: by its signature key, which is what the signature binds. A basic
    /// credential's identity is whatever its owner claims.
    ///
    /// Nor are they a secret the newcomer alone holds: the welcome secret
    /// that encrypts them is derived by every member that processes the
    /// commit (RFC 9420 §12.4.2).
    ///
    /// Writes nothing, like `inspectWelcome` and `exportWelcomeSecret`: the
    /// key package the Welcome is addressed to is still there for the join.
    /// Unlike `joinGroupFromWelcomeWithOptions`, leaf lifetimes are always
    /// checked. A Welcome without a ratchet tree extension needs
    /// `ratchetTreeBytes`: the tree of the epoch the Welcome is for.
    ///
    /// Nor, since it joins nothing, does it check the Welcome's group ID
    /// against the groups this engine stores: extensions are returned for a
    /// Welcome under an ID that is already in use, and `joinGroupFromWelcome`
    /// then refuses that Welcome.
    ///
    /// The ratchet tree extension is left out, since it is the group's tree
    /// rather than something a committer adds. So is the external public key,
    /// which a Welcome's GroupInfo does not carry.
    pub async fn welcome_group_info_extensions(
        &self,
        config: MlsGroupConfig,
        welcome_bytes: Vec<u8>,
        ratchet_tree_bytes: Option<Vec<u8>>,
    ) -> Result<WelcomeGroupInfoExtensions, String> {
        let provider = self.load_global().await?;

        let welcome_msg = MlsMessageIn::tls_deserialize_exact_bytes(&welcome_bytes)
            .map_err(|e| format!("Failed to deserialize welcome: {}", e))?;
        let welcome = match welcome_msg.extract() {
            MlsMessageBodyIn::Welcome(w) => w,
            _ => return Err("Message is not a Welcome".to_string()),
        };

        let join_config = config.to_join_config();
        let processed = ProcessedWelcome::new_from_welcome(&provider, &join_config, welcome)
            .map_err(|e| format!("Failed to process welcome: {}", e))?;
        // Read before staging consumes it; staging below verifies this very
        // GroupInfo, so they count only once it succeeds.
        let extensions = processed.unverified_group_info().extensions().clone();

        let ratchet_tree = ratchet_tree_bytes
            .map(|bytes| {
                RatchetTreeIn::tls_deserialize_exact_bytes(&bytes)
                    .map_err(|e| format!("Failed to deserialize ratchet tree: {}", e))
            })
            .transpose()?;
        let staged = processed
            .into_staged_welcome(&provider, ratchet_tree)
            .map_err(|e| format!("Failed to verify welcome: {}", e))?;

        let signer_leaf = staged
            .welcome_sender()
            .map_err(|e| format!("Failed to read the welcome's signer: {}", e))?;
        let signer = MlsMemberInfo {
            index: staged.welcome_sender_index().u32(),
            credential: signer_leaf
                .credential()
                .tls_serialize_detached()
                .map_err(|e| format!("Failed to serialize the signer's credential: {}", e))?,
            signature_key: signer_leaf.signature_key().as_slice().to_vec(),
        };

        let extensions = extensions
            .iter()
            .filter(|ext| {
                !matches!(ext, Extension::RatchetTree(_) | Extension::ExternalPub(_))
            })
            .map(extension_to_mls)
            .collect::<Result<Vec<_>, _>>()?;

        Ok(WelcomeGroupInfoExtensions { extensions, signer })
    }

    /// Joins the group a GroupInfo describes by an external commit
    /// (RFC 9420 §12.4.3.2), as the member `credentialIdentity` and
    /// `signerPublicKey` name. `joinGroupExternalCommitV2` does the same with
    /// more options.
    ///
    /// Refused, with nothing written, when this engine already stores a group
    /// under the GroupInfo's group ID — unless `replaceStoredGroup` is true,
    /// which is how a client rejoins a group whose state it lost track of.
    /// Every entry stored under that group ID is then deleted, in the write
    /// that stores the new group, so a join that fails keeps them all. The
    /// engine cannot tell a later epoch of the stored group from another
    /// group under the same ID, which anyone can create: replace only from a
    /// GroupInfo whose source the application trusts to speak for that group.
    #[allow(deprecated)]
    #[allow(clippy::too_many_arguments)]
    pub async fn join_group_external_commit(
        &self,
        config: MlsGroupConfig,
        group_info_bytes: Vec<u8>,
        ratchet_tree_bytes: Option<Vec<u8>>,
        signer_bytes: Vec<u8>,
        credential_identity: Vec<u8>,
        signer_public_key: Vec<u8>,
        credential_bytes: Option<Vec<u8>>,
        replace_stored_group: Option<bool>,
    ) -> Result<ExternalJoinResult, String> {
        let signer = signer_from_bytes(signer_bytes)?;
        let credential_with_key = build_credential_with_key(
            &credential_identity, &signer_public_key, credential_bytes.as_deref(),
        )?;

        let gi_msg = MlsMessageIn::tls_deserialize_exact_bytes(&group_info_bytes)
            .map_err(|e| format!("Failed to deserialize group info: {}", e))?;
        let verifiable_group_info = match gi_msg.extract() {
            MlsMessageBodyIn::GroupInfo(gi) => gi,
            _ => return Err("Not a GroupInfo message".to_string()),
        };

        let provider = self
            .load_for_external_join(&verifiable_group_info, replace_stored_group.unwrap_or(false))
            .await?;
        signer
            .store(provider.storage())
            .map_err(|e| format!("Failed to store signer: {}", e))?;
        let join_config = config.to_join_config();

        let ratchet_tree: Option<RatchetTreeIn> = ratchet_tree_bytes
            .map(|rt_bytes| {
                RatchetTreeIn::tls_deserialize_exact_bytes(&rt_bytes)
                    .map_err(|e| format!("Failed to deserialize ratchet tree: {}", e))
            })
            .transpose()?;

        let (mls_group, commit_out, group_info_opt) = MlsGroup::join_by_external_commit(
            &provider, &signer, ratchet_tree, verifiable_group_info, &join_config, None, None, &[], credential_with_key,
        )
        .map_err(|e| format!("Failed to join group via external commit: {}", e))?;

        let gid = mls_group.group_id().as_slice().to_vec();
        let commit_bytes = commit_out
            .tls_serialize_detached()
            .map_err(|e| format!("Failed to serialize commit: {}", e))?;
        let gi_bytes = group_info_opt
            .map(|gi| gi.tls_serialize_detached())
            .transpose()
            .map_err(|e| format!("Failed to serialize group info: {}", e))?;

        self.commit(provider, Some(&gid)).await?;

        Ok(ExternalJoinResult {
            group_id: gid,
            commit: commit_bytes,
            group_info: gi_bytes,
        })
    }

    /// Joins the group a GroupInfo describes by an external commit, as
    /// `joinGroupExternalCommit` does, with additional authenticated data for
    /// the commit and the option to skip the GroupInfo's lifetime checks.
    ///
    /// A group this engine already stores under the GroupInfo's group ID is
    /// refused and replaced exactly as there: refused, with nothing written,
    /// unless `replaceStoredGroup` is true, and then every entry stored under
    /// that group ID is deleted in the write that stores the new group. The
    /// engine cannot tell a later epoch of the stored group from another group
    /// under the same ID: replace only from a GroupInfo whose source the
    /// application trusts to speak for that group.
    #[allow(clippy::too_many_arguments)]
    pub async fn join_group_external_commit_v2(
        &self,
        config: MlsGroupConfig,
        group_info_bytes: Vec<u8>,
        ratchet_tree_bytes: Option<Vec<u8>>,
        signer_bytes: Vec<u8>,
        credential_identity: Vec<u8>,
        signer_public_key: Vec<u8>,
        aad: Option<Vec<u8>>,
        skip_lifetime_validation: bool,
        credential_bytes: Option<Vec<u8>>,
        replace_stored_group: Option<bool>,
    ) -> Result<ExternalJoinResult, String> {
        let signer = signer_from_bytes(signer_bytes)?;
        let credential_with_key = build_credential_with_key(
            &credential_identity, &signer_public_key, credential_bytes.as_deref(),
        )?;

        let gi_msg = MlsMessageIn::tls_deserialize_exact_bytes(&group_info_bytes)
            .map_err(|e| format!("Failed to deserialize group info: {}", e))?;
        let verifiable_group_info = match gi_msg.extract() {
            MlsMessageBodyIn::GroupInfo(gi) => gi,
            _ => return Err("Not a GroupInfo message".to_string()),
        };

        let provider = self
            .load_for_external_join(&verifiable_group_info, replace_stored_group.unwrap_or(false))
            .await?;
        signer
            .store(provider.storage())
            .map_err(|e| format!("Failed to store signer: {}", e))?;
        let join_config = config.to_join_config();

        let mut ext_builder = MlsGroup::external_commit_builder().with_config(join_config);
        if let Some(rt_bytes) = ratchet_tree_bytes {
            let ratchet_tree = RatchetTreeIn::tls_deserialize_exact_bytes(&rt_bytes)
                .map_err(|e| format!("Failed to deserialize ratchet tree: {}", e))?;
            ext_builder = ext_builder.with_ratchet_tree(ratchet_tree);
        }
        if let Some(aad_bytes) = aad {
            ext_builder = ext_builder.with_aad(aad_bytes);
        }
        if skip_lifetime_validation {
            ext_builder = ext_builder.skip_lifetime_validation();
        }

        let commit_builder = ext_builder
            .build_group(&provider, verifiable_group_info, credential_with_key)
            .map_err(|e| format!("Failed to build external commit group: {}", e))?;
        let commit_builder = commit_builder
            .load_psks(provider.storage())
            .map_err(|e| format!("Failed to load PSKs: {}", e))?;
        let commit_builder = commit_builder
            .build(provider.rand(), provider.crypto(), &signer, |_| true)
            .map_err(|e| format!("Failed to build external commit: {}", e))?;
        let (mls_group, bundle) = commit_builder
            .finalize(&provider)
            .map_err(|e| format!("Failed to finalize external commit: {}", e))?;

        let gid = mls_group.group_id().as_slice().to_vec();
        let (commit_out, _welcome_opt, gi_opt) = bundle.into_messages();
        let commit_bytes = commit_out
            .tls_serialize_detached()
            .map_err(|e| format!("Failed to serialize commit: {}", e))?;
        let gi_bytes = gi_opt
            .map(|gi| gi.tls_serialize_detached())
            .transpose()
            .map_err(|e| format!("Failed to serialize group info: {}", e))?;

        self.commit(provider, Some(&gid)).await?;

        Ok(ExternalJoinResult {
            group_id: gid,
            commit: commit_bytes,
            group_info: gi_bytes,
        })
    }

    // ═══════════════════════════════════════════════════════════
    // STATE QUERIES (read-only)
    // ═══════════════════════════════════════════════════════════

    /// The ID of every group this engine stores, in no particular order.
    ///
    /// These are the groups the other methods can load, and the IDs that
    /// `createGroup` and `joinGroupFromWelcome` refuse as already in use, as
    /// do the external joins unless told to replace the group. A group this
    /// client has left or been removed from stays listed until `deleteGroup`
    /// removes it; `groupIsActive` tells the two apart.
    ///
    /// Only storage keys are read, never the group state behind them, so the
    /// cost grows with the number of groups and not with their size. What an
    /// application shows for a group — a title, the last message — is not
    /// MLS state and is not stored here.
    pub async fn group_ids(&self) -> Result<Vec<Vec<u8>>, String> {
        // Under the operation locks like every other call, so the list
        // reflects exactly the calls that took them before this one.
        let _locks = self.acquire_locks().await?;
        let keys = self.db()?.keys_with_prefix(STORED_GROUP_KEY_PREFIX).await?;
        let mut group_ids: Vec<Vec<u8>> = keys.iter().filter_map(|key| stored_group_id(key)).collect();
        group_ids.sort();
        Ok(group_ids)
    }

    pub async fn group_id(
        &self,
        group_id_bytes: Vec<u8>,
    ) -> Result<Vec<u8>, String> {
        let provider = self.load_for_group(&group_id_bytes).await?;
        let group = load_group(&group_id_bytes, &provider)?;
        Ok(group.group_id().as_slice().to_vec())
    }

    pub async fn group_epoch(
        &self,
        group_id_bytes: Vec<u8>,
    ) -> Result<u64, String> {
        let provider = self.load_for_group(&group_id_bytes).await?;
        let group = load_group(&group_id_bytes, &provider)?;
        Ok(group.epoch().as_u64())
    }

    pub async fn group_is_active(
        &self,
        group_id_bytes: Vec<u8>,
    ) -> Result<bool, String> {
        let provider = self.load_for_group(&group_id_bytes).await?;
        let group = load_group(&group_id_bytes, &provider)?;
        Ok(group.is_active())
    }

    pub async fn group_members(
        &self,
        group_id_bytes: Vec<u8>,
    ) -> Result<Vec<MlsMemberInfo>, String> {
        let provider = self.load_for_group(&group_id_bytes).await?;
        let group = load_group(&group_id_bytes, &provider)?;
        let mut members = Vec::new();
        for member in group.members() {
            let cred_bytes = member.credential
                .tls_serialize_detached()
                .map_err(|e| format!("Failed to serialize member credential: {}", e))?;
            members.push(MlsMemberInfo {
                index: member.index.u32(),
                credential: cred_bytes,
                signature_key: member.signature_key.clone(),
            });
        }
        Ok(members)
    }

    pub async fn group_ciphersuite(
        &self,
        group_id_bytes: Vec<u8>,
    ) -> Result<MlsCiphersuite, String> {
        let provider = self.load_for_group(&group_id_bytes).await?;
        let group = load_group(&group_id_bytes, &provider)?;
        native_to_ciphersuite(group.ciphersuite())
    }

    pub async fn group_own_index(
        &self,
        group_id_bytes: Vec<u8>,
    ) -> Result<u32, String> {
        let provider = self.load_for_group(&group_id_bytes).await?;
        let group = load_group(&group_id_bytes, &provider)?;
        Ok(group.own_leaf_index().u32())
    }

    pub async fn group_credential(
        &self,
        group_id_bytes: Vec<u8>,
    ) -> Result<Vec<u8>, String> {
        let provider = self.load_for_group(&group_id_bytes).await?;
        let group = load_group(&group_id_bytes, &provider)?;
        let credential = group.credential().map_err(|e| format!("Failed to get credential: {}", e))?;
        credential
            .tls_serialize_detached()
            .map_err(|e| format!("Failed to serialize credential: {}", e))
    }

    pub async fn group_extensions(
        &self,
        group_id_bytes: Vec<u8>,
    ) -> Result<Vec<u8>, String> {
        let provider = self.load_for_group(&group_id_bytes).await?;
        let group = load_group(&group_id_bytes, &provider)?;
        group
            .extensions()
            .tls_serialize_detached()
            .map_err(|e| format!("Failed to serialize extensions: {}", e))
    }

    pub async fn group_pending_proposals(
        &self,
        group_id_bytes: Vec<u8>,
    ) -> Result<Vec<MlsPendingProposalInfo>, String> {
        let provider = self.load_for_group(&group_id_bytes).await?;
        let group = load_group(&group_id_bytes, &provider)?;
        let mut proposals = Vec::new();
        for qp in group.pending_proposals() {
            let proposal_type = match qp.proposal() {
                Proposal::Add(_) => MlsProposalType::Add,
                Proposal::Remove(_) => MlsProposalType::Remove,
                Proposal::Update(_) => MlsProposalType::Update,
                Proposal::PreSharedKey(_) => MlsProposalType::PreSharedKey,
                Proposal::ReInit(_) => MlsProposalType::Reinit,
                Proposal::ExternalInit(_) => MlsProposalType::ExternalInit,
                Proposal::GroupContextExtensions(_) => MlsProposalType::GroupContextExtensions,
                _ => MlsProposalType::Custom,
            };
            let sender_index = match qp.sender() {
                Sender::Member(idx) => Some(idx.u32()),
                _ => None,
            };
            proposals.push(MlsPendingProposalInfo { proposal_type, sender_index });
        }
        Ok(proposals)
    }

    pub async fn group_has_pending_proposals(
        &self,
        group_id_bytes: Vec<u8>,
    ) -> Result<bool, String> {
        let provider = self.load_for_group(&group_id_bytes).await?;
        let group = load_group(&group_id_bytes, &provider)?;
        Ok(group.has_pending_proposals())
    }

    pub async fn group_member_at(
        &self,
        group_id_bytes: Vec<u8>,
        leaf_index: u32,
    ) -> Result<Option<MlsMemberInfo>, String> {
        let provider = self.load_for_group(&group_id_bytes).await?;
        let group = load_group(&group_id_bytes, &provider)?;
        match group.member_at(LeafNodeIndex::new(leaf_index)) {
            Some(member) => {
                let cred_bytes = member.credential
                    .tls_serialize_detached()
                    .map_err(|e| format!("Failed to serialize member credential: {}", e))?;
                Ok(Some(MlsMemberInfo {
                    index: member.index.u32(),
                    credential: cred_bytes,
                    signature_key: member.signature_key.clone(),
                }))
            }
            None => Ok(None),
        }
    }

    pub async fn group_member_leaf_index(
        &self,
        group_id_bytes: Vec<u8>,
        credential_bytes: Vec<u8>,
    ) -> Result<Option<u32>, String> {
        let provider = self.load_for_group(&group_id_bytes).await?;
        let group = load_group(&group_id_bytes, &provider)?;
        let credential = Credential::tls_deserialize_exact_bytes(&credential_bytes)
            .map_err(|e| format!("Failed to deserialize credential: {}", e))?;
        Ok(group.member_leaf_index(&credential).map(|idx| idx.u32()))
    }

    // ═══════════════════════════════════════════════════════════
    // EXPORT OPERATIONS (read-only)
    // ═══════════════════════════════════════════════════════════

    pub async fn export_ratchet_tree(
        &self,
        group_id_bytes: Vec<u8>,
    ) -> Result<Vec<u8>, String> {
        let provider = self.load_for_group(&group_id_bytes).await?;
        let group = load_group(&group_id_bytes, &provider)?;
        group
            .export_ratchet_tree()
            .tls_serialize_detached()
            .map_err(|e| format!("Failed to serialize ratchet tree: {}", e))
    }

    pub async fn export_group_info(
        &self,
        group_id_bytes: Vec<u8>,
        signer_bytes: Vec<u8>,
    ) -> Result<Vec<u8>, String> {
        let signer = signer_from_bytes(signer_bytes)?;
        let provider = self.load_for_group(&group_id_bytes).await?;
        let group = load_group(&group_id_bytes, &provider)?;
        let group_info = group
            .export_group_info(provider.crypto(), &signer, true)
            .map_err(|e| format!("Failed to export group info: {}", e))?;
        group_info
            .tls_serialize_detached()
            .map_err(|e| format!("Failed to serialize group info: {}", e))
    }

    pub async fn export_secret(
        &self,
        group_id_bytes: Vec<u8>,
        label: String,
        context: Vec<u8>,
        key_length: u32,
    ) -> Result<Vec<u8>, String> {
        let provider = self.load_for_group(&group_id_bytes).await?;
        let group = load_group(&group_id_bytes, &provider)?;
        group
            .export_secret(provider.crypto(), &label, &context, key_length as usize)
            .map_err(|e| format!("Failed to export secret: {}", e))
    }

    pub async fn export_group_context(
        &self,
        group_id_bytes: Vec<u8>,
    ) -> Result<MlsGroupContextInfo, String> {
        let provider = self.load_for_group(&group_id_bytes).await?;
        let group = load_group(&group_id_bytes, &provider)?;
        let cs = native_to_ciphersuite(group.ciphersuite())?;
        let ctx = group.public_group().group_context();
        let ext_bytes = ctx
            .extensions()
            .tls_serialize_detached()
            .map_err(|e| format!("Failed to serialize extensions: {}", e))?;
        Ok(MlsGroupContextInfo {
            group_id: group.group_id().as_slice().to_vec(),
            epoch: group.epoch().as_u64(),
            ciphersuite: cs,
            tree_hash: ctx.tree_hash().to_vec(),
            confirmed_transcript_hash: ctx.confirmed_transcript_hash().to_vec(),
            extensions: ext_bytes,
        })
    }

    pub async fn group_confirmation_tag(
        &self,
        group_id_bytes: Vec<u8>,
    ) -> Result<Vec<u8>, String> {
        let provider = self.load_for_group(&group_id_bytes).await?;
        let group = load_group(&group_id_bytes, &provider)?;
        group
            .confirmation_tag()
            .tls_serialize_detached()
            .map_err(|e| format!("Failed to serialize confirmation tag: {}", e))
    }

    pub async fn group_own_leaf_node(
        &self,
        group_id_bytes: Vec<u8>,
    ) -> Result<MlsLeafNodeInfo, String> {
        let provider = self.load_for_group(&group_id_bytes).await?;
        let group = load_group(&group_id_bytes, &provider)?;
        let leaf = group
            .own_leaf_node()
            .ok_or_else(|| "No own leaf node (group not active?)".to_string())?;
        leaf_node_info(leaf, true)
    }

    pub async fn get_past_resumption_psk(
        &self,
        group_id_bytes: Vec<u8>,
        epoch: u64,
    ) -> Result<Option<Vec<u8>>, String> {
        let provider = self.load_for_group(&group_id_bytes).await?;
        let group = load_group(&group_id_bytes, &provider)?;
        Ok(group
            .get_past_resumption_psk(GroupEpoch::from(epoch))
            .map(|psk| psk.as_slice().to_vec()))
    }

    // ═══════════════════════════════════════════════════════════
    // MEMBER MANAGEMENT (mutating)
    // ═══════════════════════════════════════════════════════════

    pub async fn add_members(
        &self,
        group_id_bytes: Vec<u8>,
        signer_bytes: Vec<u8>,
        key_packages_bytes: Vec<Vec<u8>>,
    ) -> Result<AddMembersResult, String> {
        let signer = signer_from_bytes(signer_bytes)?;
        let provider = self.load_for_group(&group_id_bytes).await?;
        let mut group = load_group(&group_id_bytes, &provider)?;

        let mut key_packages = Vec::with_capacity(key_packages_bytes.len());
        for kp_bytes in key_packages_bytes {
            let kp_in = KeyPackageIn::tls_deserialize_exact_bytes(&kp_bytes)
                .map_err(|e| format!("Failed to deserialize key package: {}", e))?;
            let kp = kp_in
                .validate(provider.crypto(), ProtocolVersion::Mls10)
                .map_err(|e| format!("Failed to validate key package: {}", e))?;
            key_packages.push(kp);
        }

        let (commit_out, welcome_out, group_info_opt) = group
            .add_members(&provider, &signer, &key_packages)
            .map_err(|e| format!("Failed to add members: {}", e))?;

        group
            .merge_pending_commit(&provider)
            .map_err(|e| format!("Failed to merge pending commit: {}", e))?;

        let commit_bytes = commit_out.tls_serialize_detached().map_err(|e| format!("Failed to serialize commit: {}", e))?;
        let welcome_bytes = welcome_out.tls_serialize_detached().map_err(|e| format!("Failed to serialize welcome: {}", e))?;
        let gi_bytes = group_info_opt.map(|gi| gi.tls_serialize_detached()).transpose().map_err(|e| format!("Failed to serialize group info: {}", e))?;

        self.commit(provider, Some(&group_id_bytes)).await?;

        Ok(AddMembersResult { commit: commit_bytes, welcome: welcome_bytes, group_info: gi_bytes })
    }

    pub async fn add_members_without_update(
        &self,
        group_id_bytes: Vec<u8>,
        signer_bytes: Vec<u8>,
        key_packages_bytes: Vec<Vec<u8>>,
    ) -> Result<AddMembersResult, String> {
        let signer = signer_from_bytes(signer_bytes)?;
        let provider = self.load_for_group(&group_id_bytes).await?;
        let mut group = load_group(&group_id_bytes, &provider)?;

        let mut key_packages = Vec::with_capacity(key_packages_bytes.len());
        for kp_bytes in key_packages_bytes {
            let kp_in = KeyPackageIn::tls_deserialize_exact_bytes(&kp_bytes)
                .map_err(|e| format!("Failed to deserialize key package: {}", e))?;
            let kp = kp_in.validate(provider.crypto(), ProtocolVersion::Mls10)
                .map_err(|e| format!("Failed to validate key package: {}", e))?;
            key_packages.push(kp);
        }

        let (commit_out, welcome_out, group_info_opt) = group
            .add_members_without_update(&provider, &signer, &key_packages)
            .map_err(|e| format!("Failed to add members without update: {}", e))?;
        group.merge_pending_commit(&provider).map_err(|e| format!("Failed to merge pending commit: {}", e))?;

        let commit_bytes = commit_out.tls_serialize_detached().map_err(|e| format!("Failed to serialize commit: {}", e))?;
        let welcome_bytes = welcome_out.tls_serialize_detached().map_err(|e| format!("Failed to serialize welcome: {}", e))?;
        let gi_bytes = group_info_opt.map(|gi| gi.tls_serialize_detached()).transpose().map_err(|e| format!("Failed to serialize group info: {}", e))?;

        self.commit(provider, Some(&group_id_bytes)).await?;

        Ok(AddMembersResult { commit: commit_bytes, welcome: welcome_bytes, group_info: gi_bytes })
    }

    pub async fn remove_members(
        &self,
        group_id_bytes: Vec<u8>,
        signer_bytes: Vec<u8>,
        member_indices: Vec<u32>,
    ) -> Result<CommitResult, String> {
        let signer = signer_from_bytes(signer_bytes)?;
        let provider = self.load_for_group(&group_id_bytes).await?;
        let mut group = load_group(&group_id_bytes, &provider)?;

        let indices: Vec<LeafNodeIndex> = member_indices.iter().map(|&i| LeafNodeIndex::new(i)).collect();
        let (commit_out, welcome_opt, group_info_opt) = group
            .remove_members(&provider, &signer, &indices)
            .map_err(|e| format!("Failed to remove members: {}", e))?;
        group.merge_pending_commit(&provider).map_err(|e| format!("Failed to merge pending commit: {}", e))?;

        let commit_bytes = commit_out.tls_serialize_detached().map_err(|e| format!("Failed to serialize commit: {}", e))?;
        let welcome_bytes: Option<Vec<u8>> = welcome_opt.map(|w: MlsMessageOut| w.tls_serialize_detached()).transpose().map_err(|e| format!("Failed to serialize welcome: {}", e))?;
        let gi_bytes = group_info_opt.map(|gi| gi.tls_serialize_detached()).transpose().map_err(|e| format!("Failed to serialize group info: {}", e))?;

        self.commit(provider, Some(&group_id_bytes)).await?;

        Ok(CommitResult { commit: commit_bytes, welcome: welcome_bytes, group_info: gi_bytes })
    }

    pub async fn self_update(
        &self,
        group_id_bytes: Vec<u8>,
        signer_bytes: Vec<u8>,
    ) -> Result<CommitResult, String> {
        let signer = signer_from_bytes(signer_bytes)?;
        let provider = self.load_for_group(&group_id_bytes).await?;
        let mut group = load_group(&group_id_bytes, &provider)?;

        let bundle = group
            .self_update(&provider, &signer, LeafNodeParameters::default())
            .map_err(|e| format!("Failed to self-update: {}", e))?;
        let (commit_out, welcome_opt, group_info_opt) = bundle.into_contents();
        group.merge_pending_commit(&provider).map_err(|e| format!("Failed to merge pending commit: {}", e))?;

        let commit_bytes = commit_out.tls_serialize_detached().map_err(|e| format!("Failed to serialize commit: {}", e))?;
        let welcome_bytes: Option<Vec<u8>> = welcome_opt.map(|w: Welcome| w.tls_serialize_detached()).transpose().map_err(|e| format!("Failed to serialize welcome: {}", e))?;
        let gi_bytes = group_info_opt.map(|gi| gi.tls_serialize_detached()).transpose().map_err(|e| format!("Failed to serialize group info: {}", e))?;

        self.commit(provider, Some(&group_id_bytes)).await?;

        Ok(CommitResult { commit: commit_bytes, welcome: welcome_bytes, group_info: gi_bytes })
    }

    pub async fn self_update_with_new_signer(
        &self,
        group_id_bytes: Vec<u8>,
        old_signer_bytes: Vec<u8>,
        new_signer_bytes: Vec<u8>,
        new_credential_identity: Vec<u8>,
        new_signer_public_key: Vec<u8>,
        new_credential_bytes: Option<Vec<u8>>,
    ) -> Result<CommitResult, String> {
        let old_signer = signer_from_bytes(old_signer_bytes)?;
        let new_signer = signer_from_bytes(new_signer_bytes)?;
        let provider = self.load_for_group(&group_id_bytes).await?;
        let mut group = load_group(&group_id_bytes, &provider)?;

        new_signer.store(provider.storage()).map_err(|e| format!("Failed to store new signer: {}", e))?;

        let credential_with_key = build_credential_with_key(
            &new_credential_identity, &new_signer_public_key, new_credential_bytes.as_deref(),
        )?;
        let new_signer_bundle = NewSignerBundle { signer: &new_signer, credential_with_key };

        let bundle = group
            .self_update_with_new_signer(&provider, &old_signer, new_signer_bundle, LeafNodeParameters::default())
            .map_err(|e| format!("Failed to self-update with new signer: {}", e))?;
        let (commit_out, welcome_opt, group_info_opt) = bundle.into_contents();
        group.merge_pending_commit(&provider).map_err(|e| format!("Failed to merge pending commit: {}", e))?;

        let commit_bytes = commit_out.tls_serialize_detached().map_err(|e| format!("Failed to serialize commit: {}", e))?;
        let welcome_bytes: Option<Vec<u8>> = welcome_opt.map(|w: Welcome| w.tls_serialize_detached()).transpose().map_err(|e| format!("Failed to serialize welcome: {}", e))?;
        let gi_bytes = group_info_opt.map(|gi| gi.tls_serialize_detached()).transpose().map_err(|e| format!("Failed to serialize group info: {}", e))?;

        self.commit(provider, Some(&group_id_bytes)).await?;

        Ok(CommitResult { commit: commit_bytes, welcome: welcome_bytes, group_info: gi_bytes })
    }

    pub async fn swap_members(
        &self,
        group_id_bytes: Vec<u8>,
        signer_bytes: Vec<u8>,
        remove_indices: Vec<u32>,
        add_key_packages_bytes: Vec<Vec<u8>>,
    ) -> Result<AddMembersResult, String> {
        let signer = signer_from_bytes(signer_bytes)?;
        let provider = self.load_for_group(&group_id_bytes).await?;
        let mut group = load_group(&group_id_bytes, &provider)?;

        let indices: Vec<LeafNodeIndex> = remove_indices.iter().map(|&i| LeafNodeIndex::new(i)).collect();
        let mut key_packages = Vec::with_capacity(add_key_packages_bytes.len());
        for kp_bytes in add_key_packages_bytes {
            let kp_in = KeyPackageIn::tls_deserialize_exact_bytes(&kp_bytes)
                .map_err(|e| format!("Failed to deserialize key package: {}", e))?;
            let kp = kp_in.validate(provider.crypto(), ProtocolVersion::Mls10)
                .map_err(|e| format!("Failed to validate key package: {}", e))?;
            key_packages.push(kp);
        }

        let result = group.swap_members(&provider, &signer, &indices, &key_packages)
            .map_err(|e| format!("Failed to swap members: {}", e))?;
        group.merge_pending_commit(&provider).map_err(|e| format!("Failed to merge pending commit: {}", e))?;

        let commit_bytes = result.commit.tls_serialize_detached().map_err(|e| format!("Failed to serialize commit: {}", e))?;
        let welcome_bytes = result.welcome.tls_serialize_detached().map_err(|e| format!("Failed to serialize welcome: {}", e))?;
        let gi_bytes = result.group_info.map(|gi| gi.tls_serialize_detached()).transpose().map_err(|e| format!("Failed to serialize group info: {}", e))?;

        self.commit(provider, Some(&group_id_bytes)).await?;

        Ok(AddMembersResult { commit: commit_bytes, welcome: welcome_bytes, group_info: gi_bytes })
    }

    pub async fn leave_group(
        &self,
        group_id_bytes: Vec<u8>,
        signer_bytes: Vec<u8>,
    ) -> Result<LeaveGroupResult, String> {
        let signer = signer_from_bytes(signer_bytes)?;
        let provider = self.load_for_group(&group_id_bytes).await?;
        let mut group = load_group(&group_id_bytes, &provider)?;

        let msg = group.leave_group(&provider, &signer).map_err(|e| format!("Failed to leave group: {}", e))?;
        let msg_bytes = msg.tls_serialize_detached().map_err(|e| format!("Failed to serialize leave message: {}", e))?;

        self.commit(provider, Some(&group_id_bytes)).await?;

        Ok(LeaveGroupResult { message: msg_bytes })
    }

    /// Leaves the group with a SelfRemove proposal (draft-ietf-mls-extensions),
    /// which any member may commit without proposing the removal itself.
    ///
    /// Two things have to hold, or a step fails:
    /// - The group sends its handshake messages in the clear
    ///   (`MlsWireFormatPolicy.plaintext`): OpenMLS refuses to send a
    ///   SelfRemove encrypted.
    /// - Every member's leaf lists the proposal type `0x000a` in
    ///   `MlsCapabilities.proposals`, through `createGroupWithBuilder` and
    ///   `KeyPackageOptions.capabilities`; OpenMLS's default capabilities do
    ///   not. Otherwise the proposal is sent, and the commit that would carry
    ///   it is refused: "The proposal type is not supported by all group
    ///   members".
    ///
    /// `leaveGroup` needs neither: it proposes an ordinary Remove of this
    /// member.
    pub async fn leave_group_via_self_remove(
        &self,
        group_id_bytes: Vec<u8>,
        signer_bytes: Vec<u8>,
    ) -> Result<LeaveGroupResult, String> {
        let signer = signer_from_bytes(signer_bytes)?;
        let provider = self.load_for_group(&group_id_bytes).await?;
        let mut group = load_group(&group_id_bytes, &provider)?;

        let msg = group.leave_group_via_self_remove(&provider, &signer).map_err(|e| format!("Failed to leave group via self-remove: {}", e))?;
        let msg_bytes = msg.tls_serialize_detached().map_err(|e| format!("Failed to serialize leave message: {}", e))?;

        self.commit(provider, Some(&group_id_bytes)).await?;

        Ok(LeaveGroupResult { message: msg_bytes })
    }

    // ═══════════════════════════════════════════════════════════
    // PROPOSALS (mutating)
    // ═══════════════════════════════════════════════════════════

    pub async fn propose_add(
        &self,
        group_id_bytes: Vec<u8>,
        signer_bytes: Vec<u8>,
        key_package_bytes: Vec<u8>,
    ) -> Result<ProposalResult, String> {
        let signer = signer_from_bytes(signer_bytes)?;
        let provider = self.load_for_group(&group_id_bytes).await?;
        let mut group = load_group(&group_id_bytes, &provider)?;

        let kp_in = KeyPackageIn::tls_deserialize_exact_bytes(&key_package_bytes)
            .map_err(|e| format!("Failed to deserialize key package: {}", e))?;
        let kp = kp_in.validate(provider.crypto(), ProtocolVersion::Mls10)
            .map_err(|e| format!("Failed to validate key package: {}", e))?;

        let (proposal_out, proposal_ref) = group.propose_add_member(&provider, &signer, &kp)
            .map_err(|e| format!("Failed to propose add: {}", e))?;
        let msg_bytes = proposal_out.tls_serialize_detached().map_err(|e| format!("Failed to serialize proposal: {}", e))?;
        let proposal_ref = serialize_proposal_ref(&proposal_ref)?;

        self.commit(provider, Some(&group_id_bytes)).await?;

        Ok(ProposalResult {
            proposal_message: msg_bytes,
            proposal_ref,
        })
    }

    pub async fn propose_remove(
        &self,
        group_id_bytes: Vec<u8>,
        signer_bytes: Vec<u8>,
        member_index: u32,
    ) -> Result<ProposalResult, String> {
        let signer = signer_from_bytes(signer_bytes)?;
        let provider = self.load_for_group(&group_id_bytes).await?;
        let mut group = load_group(&group_id_bytes, &provider)?;

        let (proposal_out, proposal_ref) = group.propose_remove_member(&provider, &signer, LeafNodeIndex::new(member_index))
            .map_err(|e| format!("Failed to propose remove: {}", e))?;
        let msg_bytes = proposal_out.tls_serialize_detached().map_err(|e| format!("Failed to serialize proposal: {}", e))?;
        let proposal_ref = serialize_proposal_ref(&proposal_ref)?;

        self.commit(provider, Some(&group_id_bytes)).await?;

        Ok(ProposalResult {
            proposal_message: msg_bytes,
            proposal_ref,
        })
    }

    pub async fn propose_self_update(
        &self,
        group_id_bytes: Vec<u8>,
        signer_bytes: Vec<u8>,
        leaf_node_capabilities: Option<MlsCapabilities>,
        leaf_node_extensions: Option<Vec<MlsExtension>>,
    ) -> Result<ProposalResult, String> {
        let signer = signer_from_bytes(signer_bytes)?;
        let provider = self.load_for_group(&group_id_bytes).await?;
        let mut group = load_group(&group_id_bytes, &provider)?;

        let mut ln_builder = LeafNodeParameters::builder();
        if let Some(ref caps) = leaf_node_capabilities {
            ln_builder = ln_builder.with_capabilities(capabilities_to_native(caps)?);
        }
        if let Some(ref exts) = leaf_node_extensions {
            let extensions = Extensions::from_vec(extensions_from_mls(exts)?)
                .map_err(|e| format!("Failed to create leaf node extensions: {}", e))?;
            ln_builder = ln_builder.with_extensions(extensions);
        }
        let leaf_node_params = ln_builder.build();

        let (proposal_out, proposal_ref) = group.propose_self_update(&provider, &signer, leaf_node_params)
            .map_err(|e| format!("Failed to propose self-update: {}", e))?;
        let msg_bytes = proposal_out.tls_serialize_detached().map_err(|e| format!("Failed to serialize proposal: {}", e))?;
        let proposal_ref = serialize_proposal_ref(&proposal_ref)?;

        self.commit(provider, Some(&group_id_bytes)).await?;

        Ok(ProposalResult {
            proposal_message: msg_bytes,
            proposal_ref,
        })
    }

    /// Proposes a self-update that also rotates this member's signature key.
    ///
    /// The proposal form of `selfUpdateWithNewSigner`: the same key rotation,
    /// queued as a proposal instead of committed, so it can be carried by
    /// somebody else's commit.
    ///
    /// Two signers are needed because the message and its payload are
    /// authenticated against different keys. The envelope is signed with
    /// `oldSignerBytes`, since this member's leaf in the group tree still
    /// carries the old signature key at the time the proposal is sent; the new
    /// leaf inside the proposal is self-signed by `newSignerBytes` so that it
    /// verifies against the `signatureKey` it announces. Both must therefore be
    /// real key pairs with private keys.
    ///
    /// Upstream requires that a credential set in the leaf-node parameters
    /// equal the new signer's credential. This wrapper cannot violate that: it
    /// builds leaf-node parameters from `leafNodeCapabilities` and
    /// `leafNodeExtensions` only and never sets a credential there, so the
    /// credential built from `newCredentialIdentity` /
    /// `newSignerPublicKey` / `newCredentialBytes` is always the one that gets
    /// folded in.
    ///
    /// The new signer is stored before the proposal is created, matching
    /// `selfUpdateWithNewSigner`, so the key is available to sign with once the
    /// proposal is committed. Fails if a commit is already pending.
    ///
    /// Availability rests on this crate not enabling openmls's
    /// `virtual-clients-draft` feature. Upstream gates this function on
    /// `not(virtual-clients-draft)`, its own `test-utils`, or `test` — and that
    /// `test-utils` was deliberately dropped from the shipped binary in 3.0.0,
    /// so `not(virtual-clients-draft)` is the only arm holding it open here.
    #[allow(clippy::too_many_arguments)]
    pub async fn propose_self_update_with_new_signer(
        &self,
        group_id_bytes: Vec<u8>,
        old_signer_bytes: Vec<u8>,
        new_signer_bytes: Vec<u8>,
        new_credential_identity: Vec<u8>,
        new_signer_public_key: Vec<u8>,
        new_credential_bytes: Option<Vec<u8>>,
        leaf_node_capabilities: Option<MlsCapabilities>,
        leaf_node_extensions: Option<Vec<MlsExtension>>,
    ) -> Result<ProposalResult, String> {
        let old_signer = signer_from_bytes(old_signer_bytes)?;
        let new_signer = signer_from_bytes(new_signer_bytes)?;
        let provider = self.load_for_group(&group_id_bytes).await?;
        let mut group = load_group(&group_id_bytes, &provider)?;

        new_signer.store(provider.storage()).map_err(|e| format!("Failed to store new signer: {}", e))?;

        let credential_with_key = build_credential_with_key(
            &new_credential_identity, &new_signer_public_key, new_credential_bytes.as_deref(),
        )?;
        let new_signer_bundle = NewSignerBundle { signer: &new_signer, credential_with_key };

        let mut ln_builder = LeafNodeParameters::builder();
        if let Some(ref caps) = leaf_node_capabilities {
            ln_builder = ln_builder.with_capabilities(capabilities_to_native(caps)?);
        }
        if let Some(ref exts) = leaf_node_extensions {
            let extensions = Extensions::from_vec(extensions_from_mls(exts)?)
                .map_err(|e| format!("Failed to create leaf node extensions: {}", e))?;
            ln_builder = ln_builder.with_extensions(extensions);
        }
        let leaf_node_params = ln_builder.build();

        let (proposal_out, proposal_ref) = group
            .propose_self_update_with_new_signer(&provider, &old_signer, new_signer_bundle, leaf_node_params)
            .map_err(|e| format!("Failed to propose self-update with new signer: {}", e))?;
        let msg_bytes = proposal_out.tls_serialize_detached().map_err(|e| format!("Failed to serialize proposal: {}", e))?;
        let proposal_ref = serialize_proposal_ref(&proposal_ref)?;

        self.commit(provider, Some(&group_id_bytes)).await?;

        Ok(ProposalResult {
            proposal_message: msg_bytes,
            proposal_ref,
        })
    }

    pub async fn propose_external_psk(
        &self,
        group_id_bytes: Vec<u8>,
        signer_bytes: Vec<u8>,
        psk_id: Vec<u8>,
        psk_nonce: Vec<u8>,
    ) -> Result<ProposalResult, String> {
        let signer = signer_from_bytes(signer_bytes)?;
        let provider = self.load_for_group(&group_id_bytes).await?;
        let mut group = load_group(&group_id_bytes, &provider)?;

        let psk = PreSharedKeyId::external(psk_id, psk_nonce);
        let (proposal_out, proposal_ref) = group.propose_pre_shared_key(&provider, &signer, psk)
            .map_err(|e| format!("Failed to propose external PSK: {}", e))?;
        let msg_bytes = proposal_out.tls_serialize_detached().map_err(|e| format!("Failed to serialize proposal: {}", e))?;
        let proposal_ref = serialize_proposal_ref(&proposal_ref)?;

        self.commit(provider, Some(&group_id_bytes)).await?;

        Ok(ProposalResult {
            proposal_message: msg_bytes,
            proposal_ref,
        })
    }

    pub async fn propose_group_context_extensions(
        &self,
        group_id_bytes: Vec<u8>,
        signer_bytes: Vec<u8>,
        extensions: Vec<MlsExtension>,
    ) -> Result<ProposalResult, String> {
        let signer = signer_from_bytes(signer_bytes)?;
        let provider = self.load_for_group(&group_id_bytes).await?;
        let mut group = load_group(&group_id_bytes, &provider)?;

        let ext_vec = extensions_from_mls(&extensions)?;
        let gc_extensions = Extensions::from_vec(ext_vec).map_err(|e| format!("Failed to create extensions: {}", e))?;

        let (proposal_out, proposal_ref) = group.propose_group_context_extensions(&provider, gc_extensions, &signer)
            .map_err(|e| format!("Failed to propose group context extensions: {}", e))?;
        let msg_bytes = proposal_out.tls_serialize_detached().map_err(|e| format!("Failed to serialize proposal: {}", e))?;
        let proposal_ref = serialize_proposal_ref(&proposal_ref)?;

        self.commit(provider, Some(&group_id_bytes)).await?;

        Ok(ProposalResult {
            proposal_message: msg_bytes,
            proposal_ref,
        })
    }

    /// Proposes an application's own proposal: `payload` under `proposalType`.
    ///
    /// `proposalType` has to be the application's own, or the call is
    /// refused: not `0x0000` to `0x0007`, which RFC 9420 reserves and
    /// registers, not `0x0008` to `0x000a`, which the MLS extensions draft
    /// takes, and not a GREASE value. OpenMLS reads most of those as proposals
    /// of its own, so such a number would go out as that proposal with this
    /// payload: the other members could not decode it ("The content is
    /// malformed"), while this member kept it pending, and a commit of its
    /// pending proposals would refer to a proposal no other member has.
    /// `0x0008` and `0x0009` OpenMLS reads as custom unless it is built with
    /// its draft extensions, but a member whose implementation has them would
    /// not. The private-use range, `0xf000` to `0xffff`, is free for an
    /// application's own types. A commit can carry a custom proposal only when
    /// every member's leaf lists its type in `MlsCapabilities.proposals`.
    pub async fn propose_custom_proposal(
        &self,
        group_id_bytes: Vec<u8>,
        signer_bytes: Vec<u8>,
        proposal_type: u16,
        payload: Vec<u8>,
    ) -> Result<ProposalResult, String> {
        // Only what OpenMLS reads as custom passes, so a type it comes to read
        // as its own, in a later release or with a feature, is refused too.
        match ProposalType::from(proposal_type) {
            ProposalType::Custom(_) if proposal_type > LAST_RESERVED_PROPOSAL_TYPE => {}
            ProposalType::Custom(_) => {
                return Err(format!(
                    "proposalType {proposal_type:#06x} is not a type of the application's \
                     own: it is reserved for MLS (RFC 9420 and the MLS extensions draft). \
                     Use a type from the private-use range 0xf000-0xffff."
                ));
            }
            other => {
                return Err(format!(
                    "proposalType {proposal_type:#06x} is not a type of the application's \
                     own: OpenMLS reads it as {other:?}. Use the method for that proposal, \
                     or a type from the private-use range 0xf000-0xffff."
                ));
            }
        }
        let signer = signer_from_bytes(signer_bytes)?;
        let provider = self.load_for_group(&group_id_bytes).await?;
        let mut group = load_group(&group_id_bytes, &provider)?;

        let custom = CustomProposal::new(proposal_type, payload);
        let (proposal_out, proposal_ref) = group.propose_custom_proposal_by_reference(&provider, &signer, custom)
            .map_err(|e| format!("Failed to propose custom proposal: {}", e))?;
        let msg_bytes = proposal_out.tls_serialize_detached().map_err(|e| format!("Failed to serialize proposal: {}", e))?;
        let proposal_ref = serialize_proposal_ref(&proposal_ref)?;

        self.commit(provider, Some(&group_id_bytes)).await?;

        Ok(ProposalResult {
            proposal_message: msg_bytes,
            proposal_ref,
        })
    }

    pub async fn propose_remove_member_by_credential(
        &self,
        group_id_bytes: Vec<u8>,
        signer_bytes: Vec<u8>,
        credential_bytes: Vec<u8>,
    ) -> Result<ProposalResult, String> {
        let signer = signer_from_bytes(signer_bytes)?;
        let provider = self.load_for_group(&group_id_bytes).await?;
        let mut group = load_group(&group_id_bytes, &provider)?;

        let credential = Credential::tls_deserialize_exact_bytes(&credential_bytes)
            .map_err(|e| format!("Failed to deserialize credential: {}", e))?;
        let (proposal_out, proposal_ref) = group.propose_remove_member_by_credential(&provider, &signer, &credential)
            .map_err(|e| format!("Failed to propose remove by credential: {}", e))?;
        let msg_bytes = proposal_out.tls_serialize_detached().map_err(|e| format!("Failed to serialize proposal: {}", e))?;
        let proposal_ref = serialize_proposal_ref(&proposal_ref)?;

        self.commit(provider, Some(&group_id_bytes)).await?;

        Ok(ProposalResult {
            proposal_message: msg_bytes,
            proposal_ref,
        })
    }

    // ═══════════════════════════════════════════════════════════
    // COMMIT / MERGE OPERATIONS (mutating)
    // ═══════════════════════════════════════════════════════════

    pub async fn commit_to_pending_proposals(
        &self,
        group_id_bytes: Vec<u8>,
        signer_bytes: Vec<u8>,
    ) -> Result<CommitResult, String> {
        let signer = signer_from_bytes(signer_bytes)?;
        let provider = self.load_for_group(&group_id_bytes).await?;
        let mut group = load_group(&group_id_bytes, &provider)?;

        let (commit_out, welcome_opt, group_info_opt) = group
            .commit_to_pending_proposals(&provider, &signer)
            .map_err(|e| format!("Failed to commit to pending proposals: {}", e))?;
        group.merge_pending_commit(&provider).map_err(|e| format!("Failed to merge pending commit: {}", e))?;

        let commit_bytes = commit_out.tls_serialize_detached().map_err(|e| format!("Failed to serialize commit: {}", e))?;
        let welcome_bytes: Option<Vec<u8>> = welcome_opt.map(|w: MlsMessageOut| w.tls_serialize_detached()).transpose().map_err(|e| format!("Failed to serialize welcome: {}", e))?;
        let gi_bytes = group_info_opt.map(|gi| gi.tls_serialize_detached()).transpose().map_err(|e| format!("Failed to serialize group info: {}", e))?;

        self.commit(provider, Some(&group_id_bytes)).await?;

        Ok(CommitResult { commit: commit_bytes, welcome: welcome_bytes, group_info: gi_bytes })
    }

    pub async fn merge_pending_commit(
        &self,
        group_id_bytes: Vec<u8>,
    ) -> Result<(), String> {
        let provider = self.load_for_group(&group_id_bytes).await?;
        let mut group = load_group(&group_id_bytes, &provider)?;
        group.merge_pending_commit(&provider).map_err(|e| format!("Failed to merge pending commit: {}", e))?;

        self.commit(provider, Some(&group_id_bytes)).await
    }

    pub async fn clear_pending_commit(
        &self,
        group_id_bytes: Vec<u8>,
    ) -> Result<(), String> {
        let provider = self.load_for_group(&group_id_bytes).await?;
        let mut group = load_group(&group_id_bytes, &provider)?;
        group.clear_pending_commit(provider.storage()).map_err(|e| format!("Failed to clear pending commit: {}", e))?;

        self.commit(provider, Some(&group_id_bytes)).await
    }

    pub async fn clear_pending_proposals(
        &self,
        group_id_bytes: Vec<u8>,
    ) -> Result<(), String> {
        let provider = self.load_for_group(&group_id_bytes).await?;
        let mut group = load_group(&group_id_bytes, &provider)?;
        group.clear_pending_proposals(provider.storage()).map_err(|e| format!("Failed to clear pending proposals: {}", e))?;

        self.commit(provider, Some(&group_id_bytes)).await
    }

    /// Replace the group's runtime configuration.
    ///
    /// Every field of `MlsGroupConfig` is written, including the ones this
    /// call was not made for — the struct carries no "leave as is".
    ///
    /// ⚠ **This resets the past epoch deletion policy.** `maxPastEpochs` is
    /// the same setting as `setPastEpochDeletionPolicyMaxEpochs`, so passing a
    /// config here writes that number as the policy — silently undoing a
    /// `setPastEpochDeletionPolicyKeepAll` made earlier, along with the past
    /// epoch secrets the lower number no longer admits. When both are used,
    /// set the policy after the configuration, not before.
    pub async fn set_configuration(
        &self,
        group_id_bytes: Vec<u8>,
        config: MlsGroupConfig,
    ) -> Result<(), String> {
        let provider = self.load_for_group(&group_id_bytes).await?;
        let mut group = load_group(&group_id_bytes, &provider)?;
        let join_config = config.to_join_config();
        group.set_configuration(provider.storage(), &join_config).map_err(|e| format!("Failed to set configuration: {}", e))?;

        self.commit(provider, Some(&group_id_bytes)).await
    }

    pub async fn update_group_context_extensions(
        &self,
        group_id_bytes: Vec<u8>,
        signer_bytes: Vec<u8>,
        extensions: Vec<MlsExtension>,
    ) -> Result<CommitResult, String> {
        let signer = signer_from_bytes(signer_bytes)?;
        let provider = self.load_for_group(&group_id_bytes).await?;
        let mut group = load_group(&group_id_bytes, &provider)?;

        let ext_vec = extensions_from_mls(&extensions)?;
        let gc_extensions = Extensions::from_vec(ext_vec).map_err(|e| format!("Failed to create extensions: {}", e))?;

        let (commit_out, welcome_opt, group_info_opt) = group
            .update_group_context_extensions(&provider, gc_extensions, &signer)
            .map_err(|e| format!("Failed to update group context extensions: {}", e))?;
        group.merge_pending_commit(&provider).map_err(|e| format!("Failed to merge pending commit: {}", e))?;

        let commit_bytes = commit_out.tls_serialize_detached().map_err(|e| format!("Failed to serialize commit: {}", e))?;
        let welcome_bytes: Option<Vec<u8>> = welcome_opt.map(|w: MlsMessageOut| w.tls_serialize_detached()).transpose().map_err(|e| format!("Failed to serialize welcome: {}", e))?;
        let gi_bytes = group_info_opt.map(|gi| gi.tls_serialize_detached()).transpose().map_err(|e| format!("Failed to serialize group info: {}", e))?;

        self.commit(provider, Some(&group_id_bytes)).await?;

        Ok(CommitResult { commit: commit_bytes, welcome: welcome_bytes, group_info: gi_bytes })
    }

    pub async fn flexible_commit(
        &self,
        group_id_bytes: Vec<u8>,
        signer_bytes: Vec<u8>,
        options: FlexibleCommitOptions,
    ) -> Result<CommitResult, String> {
        let signer = signer_from_bytes(signer_bytes)?;
        let provider = self.load_for_group(&group_id_bytes).await?;
        let mut group = load_group(&group_id_bytes, &provider)?;

        // `commit_builder()` is the one OpenMLS entry point that does not
        // refuse a group with a pending commit: staging replaces it. If the
        // replaced commit already reached other members, this member would
        // then merge a different commit to the same epoch — a fork. The
        // other commit methods are refused by OpenMLS itself.
        if group.pending_commit().is_some() {
            return Err(
                "A commit is already pending for this group: merge it with \
                 mergePendingCommit (the delivery service accepted it) or drop it \
                 with clearPendingCommit (it lost) before creating another"
                    .to_string(),
            );
        }

        if let Some(aad_bytes) = options.aad {
            group.set_aad(aad_bytes);
        }

        let mut commit_builder = group.commit_builder()
            .consume_proposal_store(options.consume_pending_proposals)
            .force_self_update(options.force_self_update);

        if !options.add_key_packages.is_empty() {
            let mut key_packages = Vec::with_capacity(options.add_key_packages.len());
            for kp_bytes in &options.add_key_packages {
                let kp_in = KeyPackageIn::tls_deserialize_exact_bytes(kp_bytes)
                    .map_err(|e| format!("Failed to deserialize key package: {}", e))?;
                let kp = kp_in.validate(provider.crypto(), ProtocolVersion::Mls10)
                    .map_err(|e| format!("Failed to validate key package: {}", e))?;
                key_packages.push(kp);
            }
            commit_builder = commit_builder.propose_adds(key_packages);
        }

        if !options.remove_indices.is_empty() {
            commit_builder = commit_builder.propose_removals(options.remove_indices.iter().map(|&i| LeafNodeIndex::new(i)));
        }

        if let Some(ref gc_exts) = options.group_context_extensions {
            let ext_vec = extensions_from_mls(gc_exts)?;
            let extensions = Extensions::from_vec(ext_vec).map_err(|e| format!("Failed to create group context extensions: {}", e))?;
            commit_builder = commit_builder.propose_group_context_extensions(extensions).map_err(|e| format!("Failed to propose group context extensions: {}", e))?;
        }

        let commit_builder = commit_builder.load_psks(provider.storage()).map_err(|e| format!("Failed to load PSKs: {}", e))?;
        let mut commit_builder = commit_builder.create_group_info(options.create_group_info).use_ratchet_tree_extension(options.use_ratchet_tree_extension);
        // An empty list is the same as none, so the exported GroupInfo is then
        // created exactly as it is without the option.
        let group_info_extensions = options
            .group_info_extensions
            .as_ref()
            .filter(|extensions| !extensions.is_empty());
        if let Some(gi_exts) = group_info_extensions {
            let ext_vec = extensions_from_mls(gi_exts)?;
            // Adding them turns the exported GroupInfo on, and so does the
            // ratchet tree extension. It is not encrypted, so it is created
            // only when asked for: the Welcome's own GroupInfo carries them
            // either way.
            commit_builder = commit_builder
                .create_group_info_with_extensions(ext_vec)
                .map_err(|e| format!("Failed to add group info extensions: {}", e))?
                .create_group_info(options.create_group_info);
        }
        let commit_builder = commit_builder.build(provider.rand(), provider.crypto(), &signer, |_| true).map_err(|e| format!("Failed to build commit: {}", e))?;
        let bundle = commit_builder.stage_commit(&provider).map_err(|e| format!("Failed to stage commit: {}", e))?;
        // A commit that adds no member has no Welcome, and without
        // createGroupInfo no exported GroupInfo either: nothing would carry the
        // extensions. Refused here, before anything is merged or written,
        // rather than dropping them in silence.
        if group_info_extensions.is_some() && bundle.welcome().is_none() && bundle.group_info().is_none() {
            return Err(
                "groupInfoExtensions have nothing to carry them: the commit adds \
                 no member, so it has no Welcome, and createGroupInfo is off"
                    .to_string(),
            );
        }
        if !options.keep_pending {
            group.merge_pending_commit(&provider).map_err(|e| format!("Failed to merge pending commit: {}", e))?;
        }

        let (commit_out, welcome_opt, gi_opt) = bundle.into_messages();
        let commit_bytes = commit_out.tls_serialize_detached().map_err(|e| format!("Failed to serialize commit: {}", e))?;
        let welcome_bytes: Option<Vec<u8>> = welcome_opt.map(|w| w.tls_serialize_detached()).transpose().map_err(|e| format!("Failed to serialize welcome: {}", e))?;
        let gi_bytes = gi_opt.map(|gi| gi.tls_serialize_detached()).transpose().map_err(|e| format!("Failed to serialize group info: {}", e))?;

        self.commit(provider, Some(&group_id_bytes)).await?;

        Ok(CommitResult { commit: commit_bytes, welcome: welcome_bytes, group_info: gi_bytes })
    }

    // ═══════════════════════════════════════════════════════════
    // MESSAGES (mutating)
    // ═══════════════════════════════════════════════════════════

    pub async fn create_message(
        &self,
        group_id_bytes: Vec<u8>,
        signer_bytes: Vec<u8>,
        message: Vec<u8>,
        aad: Option<Vec<u8>>,
    ) -> Result<CreateMessageResult, String> {
        let signer = signer_from_bytes(signer_bytes)?;
        let provider = self.load_for_group(&group_id_bytes).await?;
        let mut group = load_group(&group_id_bytes, &provider)?;

        if let Some(aad_bytes) = aad {
            group.set_aad(aad_bytes);
        }

        let msg_out = group.create_message(&provider, &signer, &message)
            .map_err(|e| format!("Failed to create message: {}", e))?;
        let ciphertext = msg_out.tls_serialize_detached().map_err(|e| format!("Failed to serialize message: {}", e))?;

        self.commit(provider, Some(&group_id_bytes)).await?;

        Ok(CreateMessageResult { ciphertext })
    }

    pub async fn process_message(
        &self,
        group_id_bytes: Vec<u8>,
        message_bytes: Vec<u8>,
    ) -> Result<ProcessedMessageResult, String> {
        let provider = self.load_for_group(&group_id_bytes).await?;
        let mut group = load_group(&group_id_bytes, &provider)?;

        let msg_in = MlsMessageIn::tls_deserialize_exact_bytes(&message_bytes)
            .map_err(|e| format!("Failed to deserialize message: {}", e))?;
        let protocol_msg = msg_in.try_into_protocol_message()
            .map_err(|e| format!("Not a protocol message: {}", e))?;
        let looks_like_own_commit =
            protocol_msg.content_type() == ContentType::Commit && group.pending_commit().is_some();

        let processed = group.process_message(&provider, protocol_msg)
            .map_err(|e| format!("Failed to process message: {}", e))?;

        let sender_index = match processed.sender() {
            Sender::Member(idx) => Some(idx.u32()),
            _ => None,
        };
        let epoch = group.epoch().as_u64();

        let (message_type, application_message, has_staged_commit, has_proposal, proposal_type) =
            match processed.into_content() {
                ProcessedMessageContent::ApplicationMessage(app_msg) => {
                    (ProcessedMessageType::Application, Some(app_msg.into_bytes()), false, false, None)
                }
                ProcessedMessageContent::StagedCommitMessage(staged_commit) => {
                    group.merge_staged_commit(&provider, *staged_commit)
                        .map_err(|e| format!("Failed to merge staged commit: {}", e))?;
                    (ProcessedMessageType::StagedCommit, None, true, false, None)
                }
                ProcessedMessageContent::ProposalMessage(queued_proposal) => {
                    let prop_type = match queued_proposal.proposal() {
                        Proposal::Add(_) => MlsProposalType::Add,
                        Proposal::Remove(_) => MlsProposalType::Remove,
                        Proposal::Update(_) => MlsProposalType::Update,
                        Proposal::PreSharedKey(_) => MlsProposalType::PreSharedKey,
                        Proposal::ReInit(_) => MlsProposalType::Reinit,
                        Proposal::ExternalInit(_) => MlsProposalType::ExternalInit,
                        Proposal::GroupContextExtensions(_) => MlsProposalType::GroupContextExtensions,
                        _ => MlsProposalType::Custom,
                    };
                    group.store_pending_proposal(provider.storage(), *queued_proposal)
                        .map_err(|e| format!("Failed to store pending proposal: {}", e))?;
                    (ProcessedMessageType::Proposal, None, false, true, Some(prop_type))
                }
                // `OwnPendingCommit`: an incoming commit is this member's own
                // pending one, made with `FlexibleCommitOptions.keepPending`.
                // `mergePendingCommit` applies it; there is nothing to process.
                ProcessedMessageContent::OwnPendingCommit => {
                    return Err(
                        "Own commit fanned back by the delivery service matched this member's \
                         pending commit; merge it with mergePendingCommit instead of \
                         processing it"
                            .to_string(),
                    );
                }
                // `OwnPrivateMessage` replaces 0.8.1's
                // `ValidationError::CannotDecryptOwnMessage`, which that version
                // raised from `process_message` itself. Same input, same
                // outcome, different path: the own sender ratchet is
                // encryption-only, so the content cannot be read back.
                ProcessedMessageContent::OwnPrivateMessage => {
                    return Err(own_private_message_error(looks_like_own_commit));
                }
                _ => return Err("Unknown processed message content type".to_string()),
            };

        self.commit(provider, Some(&group_id_bytes)).await?;

        Ok(ProcessedMessageResult {
            message_type, sender_index, epoch, application_message, has_staged_commit, has_proposal, proposal_type,
        })
    }

    pub async fn process_message_with_inspect(
        &self,
        group_id_bytes: Vec<u8>,
        message_bytes: Vec<u8>,
    ) -> Result<ProcessedMessageInspectResult, String> {
        self.process_inspected(group_id_bytes, message_bytes, true).await
    }

    /// Process a message the way `processMessageWithInspect` does — decrypt it,
    /// verify it, stage a commit — and report the same, **without changing
    /// anything**: no commit is merged, no proposal stored, no ratchet
    /// advanced, nothing written to storage.
    ///
    /// For an application that decides whether a commit is acceptable before
    /// it takes effect: an access-control policy over who may add and remove
    /// whom, say, which MLS leaves to the application. Inspect the commit,
    /// judge `stagedCommitInfo` — its `proposals` with their senders, the
    /// credentials of the members it removes, the group context it leads to —
    /// and only then call `processMessage` (or `processMessageWithInspect`) on
    /// the same bytes to apply it. A commit that is refused is simply never
    /// processed by this member.
    ///
    /// The message is processed twice when accepted, which costs one more
    /// decryption and signature check. That is what makes this safe: nothing
    /// staged here can be merged by mistake, because nothing staged here
    /// outlives the call. If the group moves on between the two calls, the
    /// second one fails on the epoch instead of applying something else.
    ///
    /// **A refusal is local.** It keeps *this member* in the current epoch;
    /// it binds nobody else. If any other member accepts the commit, the group
    /// moves on and the member that refused is the one left behind, unable to
    /// read what follows. Which commit becomes the next epoch is decided by
    /// the delivery service, not by a refusal: a policy is only enforced if
    /// every member applies it, or the delivery service does. A malicious
    /// delivery service can also hand different members different commits
    /// for the same epoch; MLS does not prevent that fork, it lets members
    /// detect it — compare `groupEpochAuthenticator` among members.
    ///
    /// **What the result reports is what the sender claims.** MLS proves who
    /// signed the message; it does not prove that a credential in it — a new
    /// member's, an Update's replacement leaf, an external sender's — belongs
    /// to who it names. Verify each against the application's own source of
    /// trust before acting on it.
    ///
    /// An application message inspected here is decrypted without being
    /// consumed: its key stays in storage and the same bytes can be processed
    /// (or inspected) again. A successful inspection advances no ratchet —
    /// forward secrecy for that message only begins once it is processed —
    /// and is not a delivery or replay record.
    ///
    /// A PrivateMessage this member sent itself cannot be inspected, its own
    /// pending commit under the default ciphertext wire format included: the
    /// sender ratchet is encryption-only. Apply an own commit the delivery
    /// service accepted with `mergePendingCommit`.
    pub async fn inspect_message(
        &self,
        group_id_bytes: Vec<u8>,
        message_bytes: Vec<u8>,
    ) -> Result<ProcessedMessageInspectResult, String> {
        self.process_inspected(group_id_bytes, message_bytes, false).await
    }

    /// The common body of `process_message_with_inspect` (`apply`) and
    /// `inspect_message` (not `apply`: the session is dropped unsaved).
    async fn process_inspected(
        &self,
        group_id_bytes: Vec<u8>,
        message_bytes: Vec<u8>,
        apply: bool,
    ) -> Result<ProcessedMessageInspectResult, String> {
        let provider = self.load_for_group(&group_id_bytes).await?;
        let mut group = load_group(&group_id_bytes, &provider)?;

        let msg_in = MlsMessageIn::tls_deserialize_exact_bytes(&message_bytes)
            .map_err(|e| format!("Failed to deserialize message: {}", e))?;
        let protocol_msg = msg_in.try_into_protocol_message()
            .map_err(|e| format!("Not a protocol message: {}", e))?;
        let looks_like_own_commit =
            protocol_msg.content_type() == ContentType::Commit && group.pending_commit().is_some();

        let processed = group.process_message(&provider, protocol_msg)
            .map_err(|e| format!("Failed to process message: {}", e))?;

        let sender_index = match processed.sender() {
            Sender::Member(idx) => Some(idx.u32()),
            _ => None,
        };
        let sender = Some(sender_info(processed.sender())?);
        let epoch = group.epoch().as_u64();

        let (message_type, application_message, staged_commit_info, proposal_type, proposal_info) =
            match processed.into_content() {
                ProcessedMessageContent::ApplicationMessage(app_msg) => {
                    (ProcessedMessageType::Application, Some(app_msg.into_bytes()), None, None, None)
                }
                ProcessedMessageContent::StagedCommitMessage(staged_commit) => {
                    // Read before the merge: the leaves it removes are gone after.
                    let info = staged_commit_info(&group, &staged_commit)?;
                    if apply {
                        group.merge_staged_commit(&provider, *staged_commit)
                            .map_err(|e| format!("Failed to merge staged commit: {}", e))?;
                    }
                    (ProcessedMessageType::StagedCommit, None, Some(info), None, None)
                }
                ProcessedMessageContent::ProposalMessage(queued_proposal) => {
                    let prop_type = proposal_type_of(queued_proposal.proposal());
                    let info = proposal_info(&group, &queued_proposal)?;
                    if apply {
                        group.store_pending_proposal(provider.storage(), *queued_proposal)
                            .map_err(|e| format!("Failed to store pending proposal: {}", e))?;
                    }
                    (ProcessedMessageType::Proposal, None, None, Some(prop_type), Some(info))
                }
                // `OwnPendingCommit` is returned when an incoming commit is this
                // member's own pending one — fanned back by the delivery service
                // after a commit made with `FlexibleCommitOptions.keepPending`.
                // There is nothing to process: `mergePendingCommit` applies it.
                // (A commit merged when it was made arrives as
                // `OwnCommitMismatch` instead, as in 0.8.1.)
                ProcessedMessageContent::OwnPendingCommit => {
                    return Err(
                        "Own commit fanned back by the delivery service matched this member's \
                         pending commit; merge it with mergePendingCommit instead of \
                         processing it"
                            .to_string(),
                    );
                }
                // `OwnPrivateMessage` replaces 0.8.1's
                // `ValidationError::CannotDecryptOwnMessage`, which that version
                // raised from `process_message` itself. Same input, same
                // outcome, different path: the own sender ratchet is
                // encryption-only, so the content cannot be read back.
                ProcessedMessageContent::OwnPrivateMessage => {
                    return Err(own_private_message_error(looks_like_own_commit));
                }
                _ => return Err("Unknown processed message content type".to_string()),
            };

        // Not applying: dropping the session discards everything processing
        // touched in its snapshot, and releases the operation lock.
        if apply {
            self.commit(provider, Some(&group_id_bytes)).await?;
        }

        Ok(ProcessedMessageInspectResult {
            message_type, sender_index, epoch, application_message, staged_commit_info, proposal_type,
            sender, proposal_info,
        })
    }

    // ═══════════════════════════════════════════════════════════
    // STORAGE CLEANUP (mutating)
    // ═══════════════════════════════════════════════════════════

    pub async fn delete_group(
        &self,
        group_id_bytes: Vec<u8>,
    ) -> Result<(), String> {
        let session = self.load_for_group(&group_id_bytes).await?;
        let mut group = load_group(&group_id_bytes, &session)?;
        group.delete(session.storage()).map_err(|e| format!("Failed to delete group: {}", e))?;

        // One transaction for the final state and the purge of whatever rows
        // OpenMLS left behind, so a crash cannot half-delete the group.
        let OpSession { locks: _locks, provider } = session;
        let updates = provider.into_storage().into_updates();
        self.db()?
            .save_updates_and_purge_group(updates, &group_id_bytes)
            .await
    }

    pub async fn delete_key_package(
        &self,
        key_package_ref_bytes: Vec<u8>,
    ) -> Result<(), String> {
        let provider = self.load_global().await?;
        let hash_ref = openmls::ciphersuite::hash_ref::KeyPackageRef::tls_deserialize_exact_bytes(&key_package_ref_bytes)
            .map_err(|e| format!("Failed to deserialize key package ref: {}", e))?;
        provider.storage().delete_key_package(&hash_ref)
            .map_err(|e| format!("Failed to delete key package: {}", e))?;

        self.commit(provider, None).await
    }

    // ═══════════════════════════════════════════════════════════
    // ADDITIONAL STATE QUERIES / MUTATING
    // ═══════════════════════════════════════════════════════════

    /// Withdraws one pending proposal from this member's store: the one whose
    /// reference is `proposalRefBytes`, as `ProposalResult.proposalRef`
    /// returns it for a proposal of this member's.
    ///
    /// Only this member's copy goes. The other members keep a proposal they
    /// received, a commit of theirs can still carry it by reference, and this
    /// member then fails to process that commit, having nothing it refers to.
    /// So withdraw only a proposal whose message has not been sent. The engine
    /// reports no reference for a received proposal: to keep one out of this
    /// member's next commit, inspect the message before processing it
    /// (`inspectMessage`), or drop every pending proposal with
    /// `clearPendingProposals`.
    pub async fn remove_pending_proposal(
        &self,
        group_id_bytes: Vec<u8>,
        proposal_ref_bytes: Vec<u8>,
    ) -> Result<(), String> {
        let provider = self.load_for_group(&group_id_bytes).await?;
        let mut group = load_group(&group_id_bytes, &provider)?;
        let proposal_ref = ProposalRef::tls_deserialize_exact_bytes(&proposal_ref_bytes)
            .map_err(|e| format!("Failed to deserialize proposal ref: {}", e))?;
        group.remove_pending_proposal(provider.storage(), &proposal_ref)
            .map_err(|e| format!("Failed to remove pending proposal: {}", e))?;

        self.commit(provider, Some(&group_id_bytes)).await
    }

    pub async fn group_epoch_authenticator(
        &self,
        group_id_bytes: Vec<u8>,
    ) -> Result<Vec<u8>, String> {
        let provider = self.load_for_group(&group_id_bytes).await?;
        let group = load_group(&group_id_bytes, &provider)?;
        Ok(group.epoch_authenticator().as_slice().to_vec())
    }

    pub async fn group_configuration(
        &self,
        group_id_bytes: Vec<u8>,
    ) -> Result<GroupConfigurationResult, String> {
        let provider = self.load_for_group(&group_id_bytes).await?;
        let group = load_group(&group_id_bytes, &provider)?;
        let join_config = group.configuration();
        let cs = native_to_ciphersuite(group.ciphersuite())?;
        let wf = if join_config.wire_format_policy() == PURE_PLAINTEXT_WIRE_FORMAT_POLICY {
            super::types::MlsWireFormatPolicy::Plaintext
        } else {
            super::types::MlsWireFormatPolicy::Ciphertext
        };
        let sr_config = join_config.sender_ratchet_configuration();
        Ok(GroupConfigurationResult {
            ciphersuite: cs,
            wire_format_policy: wf,
            padding_size: join_config.padding_size() as u32,
            sender_ratchet_max_out_of_order: sr_config.out_of_order_tolerance(),
            sender_ratchet_max_forward_distance: sr_config.maximum_forward_distance(),
        })
    }

    // ═══════════════════════════════════════════════════════════
    // PAST EPOCH SECRETS
    // ═══════════════════════════════════════════════════════════

    /// Read how many past epochs' message secrets this group keeps.
    ///
    /// A group that was never told otherwise reports the `maxPastEpochs` its
    /// `MlsGroupConfig` carried when it was created or joined — the two are
    /// the same setting.
    pub async fn past_epoch_deletion_policy(
        &self,
        group_id_bytes: Vec<u8>,
    ) -> Result<PastEpochDeletionPolicyResult, String> {
        let provider = self.load_for_group(&group_id_bytes).await?;
        let group = load_group(&group_id_bytes, &provider)?;
        Ok(native_to_past_epoch_policy(group.past_epoch_deletion_policy()))
    }

    /// Keep the message secrets of at most `maxEpochs` past epochs, deleting
    /// the oldest as newer ones arrive.
    ///
    /// Takes effect at once: a number below what the group already holds
    /// deletes the surplus inside this call rather than at the next commit.
    ///
    /// ⚠ Above 0 this keeps material that decrypts past traffic — see
    /// `PastEpochDeletionPolicyResult` for the trade-off. Zero, the default
    /// for a new group, keeps none.
    ///
    /// ⚠ **`setConfiguration` resets this**, because `MlsGroupConfig` carries
    /// the same setting as `maxPastEpochs`. When both are used, set the policy
    /// after the configuration, not before.
    ///
    /// Errors when `maxEpochs` is 4294967295. That one value is refused rather
    /// than stored because it is what OpenMLS writes to mean keep-all where
    /// `usize` is 32 bits — the Web and 32-bit Android — so accepting it would
    /// make two settings one stored value there and two everywhere else. Use
    /// `setPastEpochDeletionPolicyKeepAll` if that is what you mean.
    pub async fn set_past_epoch_deletion_policy_max_epochs(
        &self,
        group_id_bytes: Vec<u8>,
        max_epochs: u32,
    ) -> Result<(), String> {
        // Validated before the snapshot is loaded, so a rejected value costs no
        // database work and holds no lock.
        let policy = max_epochs_to_native(max_epochs)?;
        self.apply_past_epoch_policy(group_id_bytes, policy).await
    }

    /// Keep every past epoch's message secrets, deleting none automatically.
    ///
    /// ⚠ **Deletion becomes the application's job.** Nothing in this package
    /// removes past epoch secrets while this is set, so the group's stored
    /// state grows with every commit for as long as the group lives, and every
    /// epoch it ever had stays decryptable by anyone who obtains that store.
    /// Pair it with one of the `deletePastEpochSecrets…` methods on a schedule
    /// of your own — a retention window with
    /// `deletePastEpochSecretsOlderThan`, say — or this is a leak rather than
    /// a feature.
    ///
    /// It does not bring back what an earlier policy already discarded, and
    /// like the one above it is reset by `setConfiguration`.
    pub async fn set_past_epoch_deletion_policy_keep_all(
        &self,
        group_id_bytes: Vec<u8>,
    ) -> Result<(), String> {
        self.apply_past_epoch_policy(group_id_bytes, PastEpochDeletionPolicy::KeepAll)
            .await
    }

    /// Delete the message secrets of every past epoch, keeping the policy as
    /// it is.
    ///
    /// The group's current epoch is untouched: messages of the current epoch
    /// keep decrypting. Everything older stops, irreversibly.
    ///
    /// ⚠ It clears what has accumulated; it does not stop accumulation. Under
    /// `setPastEpochDeletionPolicyKeepAll` the next commit starts recording
    /// past epochs again, so this is a sweep to be repeated rather than a
    /// switch. To stop it, set a `maxEpochs` policy.
    pub async fn delete_all_past_epoch_secrets(
        &self,
        group_id_bytes: Vec<u8>,
    ) -> Result<(), String> {
        self.apply_past_epoch_deletion(group_id_bytes, PastEpochDeletion::delete_all())
            .await
    }

    /// Delete the message secrets of past epochs recorded more than `seconds`
    /// ago, keeping the policy as it is.
    ///
    /// Age is measured from when the secrets were stored, by this device's
    /// clock, not from anything in the protocol. `maxPastEpochs` additionally
    /// caps what survives at that many of the newest past epochs; omit it to
    /// apply no cap.
    ///
    /// ⚠ **Entries that carry no timestamp are skipped in silence** — the
    /// store cannot tell how old an undated one is. Such entries exist only
    /// where an application ran a version of this package built on OpenMLS
    /// 0.8.1 or earlier *and* had `maxPastEpochs` above zero, since the
    /// default records no past epochs at all; in a group that outlived that
    /// upgrade they sit alongside dated ones and a retention window built only
    /// out of this method keeps them forever.
    /// `deletePastEpochSecretsWithoutTimestamps` is the step that clears them.
    pub async fn delete_past_epoch_secrets_older_than(
        &self,
        group_id_bytes: Vec<u8>,
        seconds: u64,
        max_past_epochs: Option<u32>,
    ) -> Result<(), String> {
        self.apply_past_epoch_deletion(
            group_id_bytes,
            with_cap(
                PastEpochDeletion::older_than_duration(Duration::from_secs(seconds)),
                max_past_epochs,
            ),
        )
        .await
    }

    /// Delete the message secrets of past epochs recorded before
    /// `unixSeconds`, counted from the Unix epoch, keeping the policy as it is.
    ///
    /// `maxPastEpochs` additionally caps what survives at that many of the
    /// newest past epochs; omit it to apply no cap. Undated entries are
    /// skipped here too — see `deletePastEpochSecretsOlderThan`.
    ///
    /// ⚠ Seconds, not milliseconds. Dart offers `millisecondsSinceEpoch`
    /// first, and a present-day millisecond count is about a thousand times
    /// too large: that lands past the year 9999 and is refused here, rather
    /// than quietly deleting every past epoch the group has.
    pub async fn delete_past_epoch_secrets_before(
        &self,
        group_id_bytes: Vec<u8>,
        unix_seconds: u64,
        max_past_epochs: Option<u32>,
    ) -> Result<(), String> {
        // Validated before the snapshot is loaded — see above.
        let cutoff = unix_seconds_to_system_time(unix_seconds)?;
        self.apply_past_epoch_deletion(
            group_id_bytes,
            with_cap(PastEpochDeletion::before_timestamp(cutoff), max_past_epochs),
        )
        .await
    }

    /// Delete the message secrets of past epochs that carry no timestamp,
    /// keeping the policy as it is.
    ///
    /// This is a migration step, not an exotic option. Secrets recorded by a
    /// version of this package built on OpenMLS 0.8.1 or earlier have no
    /// timestamp, so neither `deletePastEpochSecretsOlderThan` nor
    /// `deletePastEpochSecretsBefore` will ever remove them; a deployment that
    /// keeps past epochs and has upgraded across that boundary should run this
    /// once. Where `maxPastEpochs` was left at its default of zero, no past
    /// epochs were recorded at all and there is nothing here to clear.
    ///
    /// `maxPastEpochs` additionally caps what survives at that many of the
    /// newest past epochs; omit it to apply no cap.
    pub async fn delete_past_epoch_secrets_without_timestamps(
        &self,
        group_id_bytes: Vec<u8>,
        max_past_epochs: Option<u32>,
    ) -> Result<(), String> {
        self.apply_past_epoch_deletion(
            group_id_bytes,
            with_cap(
                PastEpochDeletion::delete_all_without_timestamps(),
                max_past_epochs,
            ),
        )
        .await
    }

    /// Shared tail of the two policy setters: one load → operate → save cycle.
    async fn apply_past_epoch_policy(
        &self,
        group_id_bytes: Vec<u8>,
        policy: PastEpochDeletionPolicy,
    ) -> Result<(), String> {
        let provider = self.load_for_group(&group_id_bytes).await?;
        let mut group = load_group(&group_id_bytes, &provider)?;
        group
            .set_past_epoch_deletion_policy(&provider, policy)
            .map_err(|e| format!("Failed to set past epoch deletion policy: {}", e))?;

        self.commit(provider, Some(&group_id_bytes)).await
    }

    /// Shared tail of the four deletions: one load → operate → save cycle.
    async fn apply_past_epoch_deletion(
        &self,
        group_id_bytes: Vec<u8>,
        deletion: PastEpochDeletion,
    ) -> Result<(), String> {
        let provider = self.load_for_group(&group_id_bytes).await?;
        let mut group = load_group(&group_id_bytes, &provider)?;
        group
            .delete_past_epoch_secrets(&provider, deletion)
            .map_err(|e| format!("Failed to delete past epoch secrets: {}", e))?;

        self.commit(provider, Some(&group_id_bytes)).await
    }

    // ═══════════════════════════════════════════════════════════
    // LIFECYCLE
    // ═══════════════════════════════════════════════════════════

    /// Return the database schema version.
    ///
    /// After a successful `create()`, this is always `LATEST_SCHEMA_VERSION`.
    /// Useful for diagnostics and debugging migration issues.
    #[flutter_rust_bridge::frb(sync)]
    pub fn schema_version(&self) -> u32 {
        crate::encrypted_db::LATEST_SCHEMA_VERSION
    }

    /// Close the engine, wiping the encryption key from memory and closing the
    /// database connection. After calling this, all operations will fail with
    /// "MlsEngine is closed". Idempotent — calling close on an already-closed
    /// engine is a no-op.
    pub async fn close(&self) -> Result<(), String> {
        // Wait for any in-flight operation to finish its load → operate → save
        // sequence before tearing the connection down.
        let _op = self.op_lock.lock().await;
        let arc = { self.db.write().take() };
        match arc {
            Some(arc) => match std::sync::Arc::try_unwrap(arc) {
                Ok(db) => db.close().await,
                Err(_) => Ok(()), // In-flight operations hold the last ref; cleanup on drop
            },
            None => Ok(()), // Already closed — idempotent
        }
    }

    /// Check whether this engine has been closed.
    #[flutter_rust_bridge::frb(sync)]
    pub fn is_closed(&self) -> bool {
        self.db.read().is_none()
    }
}

// ═══════════════════════════════════════════════════════════════
// MESSAGE UTILITIES (standalone, no storage needed)
// ═══════════════════════════════════════════════════════════════

/// Extract the group ID from an MLS protocol message.
///
/// Useful for routing incoming messages to the right group before calling
/// `processMessage`. Returns an error if the message is not a protocol
/// message (i.e. it's a Welcome, GroupInfo, or KeyPackage).
#[flutter_rust_bridge::frb(sync)]
pub fn mls_message_extract_group_id(message_bytes: Vec<u8>) -> Result<Vec<u8>, String> {
    let msg_in = MlsMessageIn::tls_deserialize_exact_bytes(&message_bytes)
        .map_err(|e| format!("Failed to deserialize message: {}", e))?;
    let protocol_msg = msg_in
        .try_into_protocol_message()
        .map_err(|e| format!("Not a protocol message: {}", e))?;
    Ok(protocol_msg.group_id().as_slice().to_vec())
}

/// Extract the epoch from an MLS protocol message.
///
/// Returns an error if the message is not a protocol message.
#[flutter_rust_bridge::frb(sync)]
pub fn mls_message_extract_epoch(message_bytes: Vec<u8>) -> Result<u64, String> {
    let msg_in = MlsMessageIn::tls_deserialize_exact_bytes(&message_bytes)
        .map_err(|e| format!("Failed to deserialize message: {}", e))?;
    let protocol_msg = msg_in
        .try_into_protocol_message()
        .map_err(|e| format!("Not a protocol message: {}", e))?;
    Ok(protocol_msg.epoch().as_u64())
}

/// Get the content type of an MLS protocol message as a string.
///
/// Returns one of: "application", "proposal", "commit".
/// Returns an error if the message is not a protocol message.
#[flutter_rust_bridge::frb(sync)]
pub fn mls_message_content_type(message_bytes: Vec<u8>) -> Result<String, String> {
    let msg_in = MlsMessageIn::tls_deserialize_exact_bytes(&message_bytes)
        .map_err(|e| format!("Failed to deserialize message: {}", e))?;
    let protocol_msg = msg_in
        .try_into_protocol_message()
        .map_err(|e| format!("Not a protocol message: {}", e))?;
    let ct = match protocol_msg.content_type() {
        ContentType::Application => "application",
        ContentType::Proposal => "proposal",
        ContentType::Commit => "commit",
    };
    Ok(ct.to_string())
}


// ═══════════════════════════════════════════════════════════════
// KEY PACKAGE UTILITIES (standalone, no storage needed)
// ═══════════════════════════════════════════════════════════════

/// The window during which a key package may be used, as seconds since the
/// Unix epoch.
pub struct KeyPackageLifetime {
    /// Start of the window. A client must not use the key package before this
    /// instant; an instant equal to it is already inside the window.
    pub not_before: u64,
    /// End of the window. A client must not use the key package at or after
    /// this instant.
    pub not_after: u64,
}

/// Whether a validity window admits some instant, and OpenMLS's reason when it
/// does not.
pub struct LifetimeVerdict {
    /// True when the instant falls inside the window.
    pub valid: bool,
    /// Why not, when `valid` is false. Null when it is true.
    pub reason: Option<String>,
}

/// Reads the validity window out of a key package.
///
/// Pair this with `checkLifetimeAt` to judge a key package by a clock other
/// than the device's — a timestamp from a server, say — before offering it to
/// `addMembers`.
///
/// ⚠ **The device's own clock still gates this call.** Getting at the window
/// means validating the key package, and OpenMLS's validation checks
/// signatures, protocol version, extensions *and* the lifetime, that last one
/// against `SystemTime::now()` on this device. There is no way to ask it to
/// skip that from outside the crate. So a key package this device believes is
/// expired, or not yet valid, fails here and never yields its bounds: the pair
/// of functions can apply an authority stricter than the local clock, not
/// rescue a package the local clock has already rejected.
#[flutter_rust_bridge::frb(sync)]
pub fn key_package_lifetime(key_package_bytes: Vec<u8>) -> Result<KeyPackageLifetime, String> {
    let kp_in = KeyPackageIn::tls_deserialize_exact_bytes(&key_package_bytes)
        .map_err(|e| format!("Failed to deserialize key package: {}", e))?;
    let crypto = crate::hybrid_crypto::HybridCrypto::new();
    let kp = kp_in
        .validate(&crypto, ProtocolVersion::Mls10)
        .map_err(|e| format!("Failed to validate key package: {}", e))?;
    let lifetime = kp.life_time();
    Ok(KeyPackageLifetime {
        not_before: lifetime.not_before(),
        not_after: lifetime.not_after(),
    })
}

/// The largest instant `checkLifetimeAt` accepts: 9999-12-31T23:59:59Z.
///
/// A cap is needed because the platforms disagree about what a `SystemTime`
/// can hold, and without one the same call would answer differently depending
/// on where it ran. `web_time::SystemTime` on wasm32 is a bare `Duration`
/// since the epoch — its `checked_add` is `Duration::checked_add` — so it
/// accepts every `u64` of seconds; native `std::time::SystemTime` does not,
/// and `u64::MAX` is an error there. Measured on both: the same argument was
/// a verdict on one target and an error on the other.
///
/// The cap sits where no calendar can mean a larger value rather than at any
/// platform's limit, which is what keeps it correct without a survey of the
/// platforms: rejecting past the end of year 9999 costs no caller anything,
/// and below it every target this crate builds for answers a given argument
/// the same way.
const MAX_UNIX_SECONDS: u64 = 253_402_300_799;

/// Turns a count of seconds since the Unix epoch into an instant, refusing
/// anything no calendar can mean.
///
/// Shared by every function here that takes a wall-clock instant from Dart, so
/// that they agree on the bound and on what happens past it — `checkLifetimeAt`
/// and `deletePastEpochSecrets` would otherwise each pick their own.
fn unix_seconds_to_system_time(unix_seconds: u64) -> Result<SystemTime, String> {
    if unix_seconds > MAX_UNIX_SECONDS {
        return Err(format!(
            "Not a representable instant: {} seconds after the Unix epoch is past \
             9999-12-31T23:59:59Z",
            unix_seconds
        ));
    }
    // Nothing under the cap overflows on any target this crate is built for,
    // so this arm is unreachable today. It stays because `checked_add` returns
    // an `Option` either way, and because a narrower platform added later
    // should produce an error here rather than depend on the survey above
    // still being complete.
    UNIX_EPOCH
        .checked_add(Duration::from_secs(unix_seconds))
        .ok_or_else(|| {
            format!(
                "Not a representable instant: {} seconds after the Unix epoch",
                unix_seconds
            )
        })
}

/// Checks a validity window against a supplied instant instead of this
/// device's clock.
///
/// Takes the two bounds rather than key package bytes, so that this half of
/// the check has no dependency on the local clock at all: `keyPackageLifetime`
/// is the only way to read bounds *out of* a key package and it does consult
/// the local clock, but a caller that already holds bounds — from its own
/// directory, from an earlier reading, from a server that publishes them — can
/// apply this on its own.
///
/// The comparison is OpenMLS's (`Lifetime::validate_with_time`), not a
/// re-implementation, so the boundaries match what a peer will decide about
/// the same package: `notAfter` is exclusive — an instant equal to it counts
/// as expired — while `notBefore` is inclusive.
///
/// Returns an error only when `nowUnixSeconds` names no instant a calendar
/// could mean — anything past 9999-12-31T23:59:59Z. An instant outside the
/// window is a verdict, not an error, and below that cap every platform this
/// package ships for answers a given argument the same way.
///
/// That cap also catches the likeliest way to call this wrongly. Dart has no
/// `secondsSinceEpoch`, so a caller reaching for `DateTime` meets
/// `millisecondsSinceEpoch` first, and a present-day millisecond count is
/// roughly a thousand times too large — comfortably past the cap, so it fails
/// loudly here instead of returning a confident verdict about a date tens of
/// thousands of years out.
#[flutter_rust_bridge::frb(sync)]
pub fn check_lifetime_at(
    not_before: u64,
    not_after: u64,
    now_unix_seconds: u64,
) -> Result<LifetimeVerdict, String> {
    let now = unix_seconds_to_system_time(now_unix_seconds)?;
    Ok(
        match Lifetime::init(not_before, not_after).validate_with_time(now) {
            Ok(()) => LifetimeVerdict { valid: true, reason: None },
            Err(e) => LifetimeVerdict { valid: false, reason: Some(e.to_string()) },
        },
    )
}

// ═══════════════════════════════════════════════════════════════
// TESTS
// ═══════════════════════════════════════════════════════════════

/// Past epoch policy conversions, run on the host *and* in the browser.
///
/// The two are not the same measurement: `usize` is 64 bits on the host and 32
/// on wasm32, and OpenMLS's encoding of the keep-all policy is written in
/// terms of `usize::MAX`. Everything here that mentions a pointer width is
/// therefore a different assertion on each target, and the browser run is the
/// only one that sees the branch the Web actually takes.
#[cfg(test)]
mod past_epoch_policy_tests {
    use super::*;

    #[cfg(target_arch = "wasm32")]
    use wasm_bindgen_test::{wasm_bindgen_test, wasm_bindgen_test_configure};

    #[cfg(target_arch = "wasm32")]
    wasm_bindgen_test_configure!(run_in_browser);

    #[cfg_attr(not(target_arch = "wasm32"), test)]
    #[cfg_attr(target_arch = "wasm32", wasm_bindgen_test)]
    fn keep_all_is_reported_however_openmls_stored_it() {
        assert!(native_to_past_epoch_policy(&PastEpochDeletionPolicy::KeepAll).keep_all);

        // The shape a 32-bit target reads back — see the test below. On the
        // host this arm is unreachable through storage, which is exactly why
        // it is asserted directly rather than left to the round trip.
        assert!(
            native_to_past_epoch_policy(&PastEpochDeletionPolicy::MaxEpochs(usize::MAX)).keep_all,
            "MaxEpochs(usize::MAX) is OpenMLS's own encoding of keep-all"
        );
    }

    #[cfg_attr(not(target_arch = "wasm32"), test)]
    #[cfg_attr(target_arch = "wasm32", wasm_bindgen_test)]
    fn the_storage_codec_preserves_keep_all_only_where_usize_is_64_bits() {
        // serde_json is the codec `SnapshotStorageProvider` writes values with,
        // so this is the round trip a stored join config really takes.
        let json = serde_json::to_string(&PastEpochDeletionPolicy::KeepAll).unwrap();
        let back: PastEpochDeletionPolicy = serde_json::from_str(&json).unwrap();

        // OpenMLS serializes KeepAll as `usize::MAX` and deserializes only
        // `u64::MAX` back into it, so the value survives on a 64-bit target and
        // lands on MaxEpochs everywhere else.
        #[cfg(target_pointer_width = "64")]
        assert_eq!(back, PastEpochDeletionPolicy::KeepAll);
        #[cfg(target_pointer_width = "32")]
        assert_eq!(back, PastEpochDeletionPolicy::MaxEpochs(usize::MAX));

        // Either way this is what Dart is told, which is the point of the
        // normalization: the surface does not change shape with the target.
        assert!(native_to_past_epoch_policy(&back).keep_all);
    }

    #[cfg_attr(not(target_arch = "wasm32"), test)]
    #[cfg_attr(target_arch = "wasm32", wasm_bindgen_test)]
    fn every_number_reported_is_one_the_setter_would_take_back() {
        // A store written by another OpenMLS application can hold a number
        // larger than anything this crate writes. Reporting it verbatim would
        // hand Dart a value its own setter refuses, so it reads as keep-all.
        assert!(native_to_past_epoch_policy(&PastEpochDeletionPolicy::MaxEpochs(
            u32::MAX as usize
        ))
        .keep_all);

        let ordinary =
            native_to_past_epoch_policy(&PastEpochDeletionPolicy::MaxEpochs(u32::MAX as usize - 1));
        assert!(!ordinary.keep_all);
        assert_eq!(ordinary.max_epochs, u32::MAX - 1);
        assert!(max_epochs_to_native(ordinary.max_epochs).is_ok());
    }

    #[cfg_attr(not(target_arch = "wasm32"), test)]
    #[cfg_attr(target_arch = "wasm32", wasm_bindgen_test)]
    fn the_one_ambiguous_number_is_refused() {
        // u32::MAX is `usize::MAX` where usize is 32 bits, so storing it would
        // be storing keep-all under another name on those targets only.
        assert!(max_epochs_to_native(u32::MAX).is_err());
        assert!(max_epochs_to_native(u32::MAX - 1).is_ok());
        assert!(max_epochs_to_native(0).is_ok());
    }
}

/// `inspect_message` on a proposal from an external sender — a party the
/// group's `ExternalSenders` extension admits without making it a member.
/// The Dart API cannot sign one, so the proposal is built with OpenMLS here.
#[cfg(all(test, not(target_arch = "wasm32")))]
mod external_sender_tests {
    use super::*;
    use crate::api::keys::{serialize_signer, MlsSignatureKeyPair};
    use futures::executor::block_on;

    const SUITE: MlsCiphersuite = MlsCiphersuite::Mls128DhkemX25519Aes128gcmSha256Ed25519;

    /// An engine on its own database in the temp directory, removed on drop.
    struct TempEngine {
        engine: MlsEngine,
        path: std::path::PathBuf,
    }

    impl TempEngine {
        fn new(name: &str) -> Self {
            let path = std::env::temp_dir().join(format!(
                "openmls_frb_external_sender_{name}_{}.db",
                std::process::id()
            ));
            let _ = std::fs::remove_file(&path);
            let engine = block_on(MlsEngine::create(
                path.to_str().expect("temp path is valid UTF-8").to_string(),
                vec![0x5a; 32],
            ))
            .expect("engine opens");
            Self { engine, path }
        }
    }

    impl Drop for TempEngine {
        fn drop(&mut self) {
            for suffix in ["", "-journal", ".lock"] {
                let _ = std::fs::remove_file(format!("{}{suffix}", self.path.display()));
            }
        }
    }

    /// A fresh key pair, as the serialized signer the engine takes and the
    /// public key.
    fn identity() -> (Vec<u8>, Vec<u8>) {
        let keys = MlsSignatureKeyPair::generate(SUITE).expect("signature key pair");
        let signer = serialize_signer(SUITE, keys.private_key(), keys.public_key())
            .expect("serialized signer");
        (signer, keys.public_key())
    }

    #[test]
    fn a_proposal_from_an_external_sender_names_it_and_whom_it_removes() {
        let alice = TempEngine::new("alice");
        let bob = TempEngine::new("bob");
        let (alice_signer, alice_key) = identity();
        let (bob_signer, bob_key) = identity();
        let (ds_signer, ds_key) = identity();

        let group_id = block_on(alice.engine.create_group(
            MlsGroupConfig::default_config(SUITE),
            alice_signer.clone(),
            b"alice".to_vec(),
            alice_key,
            None,
            None,
        ))
        .expect("group is created")
        .group_id;
        let key_package = block_on(bob.engine.create_key_package(
            SUITE,
            bob_signer,
            b"bob".to_vec(),
            bob_key,
            None,
        ))
        .expect("key package")
        .key_package_bytes;
        block_on(alice.engine.add_members(group_id.clone(), alice_signer.clone(), vec![key_package]))
            .expect("bob is added");

        // The group admits the delivery service as external sender 0.
        let external_senders = Extension::ExternalSenders(vec![ExternalSender::new(
            SignaturePublicKey::from(ds_key.clone()),
            BasicCredential::new(b"delivery-service".to_vec()).into(),
        )]);
        block_on(alice.engine.update_group_context_extensions(
            group_id.clone(),
            alice_signer,
            vec![extension_to_mls(&external_senders).expect("extension encodes")],
        ))
        .expect("external sender is admitted");

        let epoch = block_on(alice.engine.group_epoch(group_id.clone())).expect("epoch");
        let proposal = ExternalProposal::new_remove::<SnapshotOpenMlsProvider>(
            LeafNodeIndex::new(1),
            GroupId::from_slice(&group_id),
            GroupEpoch::from(epoch),
            &signer_from_bytes(ds_signer).expect("delivery service signer"),
            SenderExtensionIndex::new(0),
        )
        .expect("external proposal")
        .tls_serialize_detached()
        .expect("proposal encodes");

        let inspected = block_on(alice.engine.inspect_message(group_id, proposal))
            .expect("external proposal inspects");
        let sender = inspected.sender.expect("sender is reported");
        assert!(matches!(sender.kind, MlsSenderKind::External));
        assert_eq!(sender.index, Some(0));
        assert_eq!(inspected.sender_index, None, "not a member");

        let info = inspected.proposal_info.expect("proposal is described");
        assert!(matches!(info.proposal_type, MlsProposalType::Remove));
        assert!(matches!(info.sender.kind, MlsSenderKind::External));
        let removed = info.affected_member.expect("removed member is named");
        assert_eq!(removed.index, 1);
        let credential = Credential::tls_deserialize_exact_bytes(&removed.credential)
            .expect("credential decodes");
        assert_eq!(
            BasicCredential::try_from(credential).expect("basic credential").identity(),
            b"bob"
        );
    }

    #[test]
    fn external_senders_read_back_as_they_were_written() {
        let (_, ds_key) = identity();
        let credential: Credential = BasicCredential::new(b"delivery-service".to_vec()).into();
        let extension = Extension::ExternalSenders(vec![ExternalSender::new(
            SignaturePublicKey::from(ds_key.clone()),
            credential.clone(),
        )]);

        let wire = extension_to_mls(&extension).expect("extension encodes");
        assert_eq!(wire.extension_type, 0x0005);
        let senders = crate::api::types::decode_external_senders(wire.data).expect("decodes");
        assert_eq!(senders.len(), 1);
        assert_eq!(senders[0].signature_key, ds_key);
        assert_eq!(senders[0].credential, credential.tls_serialize_detached().unwrap());
    }
}

/// The policy against the real Web storage path.
///
/// The Dart suite covers this on native SQLCipher, where `usize` is 64 bits
/// and the keep-all encoding round-trips by itself. Only here does the
/// normalization above carry the result, and only execution can show it: a
/// wasm32 body is a different implementation of the same function.
#[cfg(all(test, target_arch = "wasm32"))]
mod past_epoch_web_tests {
    use super::*;
    use wasm_bindgen_test::{wasm_bindgen_test, wasm_bindgen_test_configure};

    wasm_bindgen_test_configure!(run_in_browser);

    #[wasm_bindgen_test]
    async fn keep_all_round_trips_through_indexeddb() {
        let name = format!("openmls_frb_policy_test_{}", js_sys::Date::now() as u64);
        let engine = MlsEngine::create(name, vec![7u8; 32])
            .await
            .expect("engine opens");

        let keys = crate::api::keys::MlsSignatureKeyPair::generate(
            MlsCiphersuite::Mls128DhkemX25519Aes128gcmSha256Ed25519,
        )
        .expect("signature key pair");
        let signer = crate::api::keys::serialize_signer(
            MlsCiphersuite::Mls128DhkemX25519Aes128gcmSha256Ed25519,
            keys.private_key(),
            keys.public_key(),
        )
        .expect("serialized signer");

        let group = engine
            .create_group(
                MlsGroupConfig::default_config(
                    MlsCiphersuite::Mls128DhkemX25519Aes128gcmSha256Ed25519,
                ),
                signer,
                b"alice".to_vec(),
                keys.public_key(),
                None,
                None,
            )
            .await
            .expect("group is created");

        // A fresh group keeps nothing, as on native.
        let before = engine
            .past_epoch_deletion_policy(group.group_id.clone())
            .await
            .expect("policy reads back");
        assert!(!before.keep_all);
        assert_eq!(before.max_epochs, 0);

        engine
            .set_past_epoch_deletion_policy_keep_all(group.group_id.clone())
            .await
            .expect("policy is set");

        // Read back from IndexedDB, not from memory: every call reloads the
        // group. Without the normalization this is `MaxEpochs(4294967295)`.
        let after = engine
            .past_epoch_deletion_policy(group.group_id)
            .await
            .expect("policy reads back");
        assert!(
            after.keep_all,
            "keep-all must survive the Web storage round trip"
        );
    }
}

/// Every group an engine stores shares one database with the others, so two
/// operations can trip over another group's rows: creating or joining a group
/// under an ID that is already stored, and deleting one group out of several.
///
/// Each test runs on the host *and* in the browser, because the two scope a
/// group's rows differently: SQLite by a `group_id` column the engine fills
/// in, IndexedDB by nothing but the storage keys themselves.
#[cfg(test)]
mod group_scope_tests {
    use super::*;
    use crate::api::keys::{serialize_signer, MlsSignatureKeyPair};

    #[cfg(target_arch = "wasm32")]
    use wasm_bindgen_test::{wasm_bindgen_test, wasm_bindgen_test_configure};

    #[cfg(target_arch = "wasm32")]
    wasm_bindgen_test_configure!(run_in_browser);

    const SUITE: MlsCiphersuite = MlsCiphersuite::Mls128DhkemX25519Aes128gcmSha256Ed25519;

    /// Runs each async body as a host test and as a browser test.
    macro_rules! on_both_targets {
        ($($name:ident => $body:ident;)*) => {$(
            #[cfg(not(target_arch = "wasm32"))]
            #[test]
            fn $name() {
                futures::executor::block_on($body());
            }

            #[cfg(target_arch = "wasm32")]
            #[wasm_bindgen_test]
            async fn $name() {
                $body().await;
            }
        )*};
    }

    on_both_targets! {
        a_welcome_into_a_stored_group_id_is_refused => welcome_into_a_stored_group_id;
        creating_a_group_under_a_stored_id_is_refused => creating_under_a_stored_id;
        deleting_a_group_leaves_every_other_group => deleting_leaves_the_other_groups;
        an_external_join_replaces_a_stored_group_only_when_told_and_whole => external_join_into_a_stored_group_id;
        an_external_join_replaces_a_stored_group_that_does_not_load => external_join_into_a_group_that_does_not_load;
        group_ids_lists_exactly_the_stored_groups => group_ids_lists_the_stored_groups;
    }

    /// The Web build finds a group's rows by their keys alone; the host
    /// stores, beside each row, which group wrote it. On the host the two
    /// can be read side by side, so every row a varied run of operations
    /// leaves behind has to be claimed by the key test for exactly the group
    /// its column names — and a global row by none.
    #[cfg(not(target_arch = "wasm32"))]
    #[test]
    fn the_web_key_test_agrees_with_the_host_group_column() {
        use crate::encrypted_db::is_global_key;
        use crate::snapshot_storage::key_belongs_to_group;

        futures::executor::block_on(async {
            let alice = Party::new("alice").await;
            let bob = Party::new("bob").await;
            let carol = Party::new("carol").await;
            let short: &[u8] = b"group";
            let long: &[u8] = b"group-2";

            alice.create_group(Some(short)).await.expect("short ID");
            alice.create_group(Some(long)).await.expect("long ID");
            let other = alice.create_group(None).await.expect("random ID");
            alice.invite(long, &bob).await;
            let key_package = carol.key_package().await;
            alice
                .engine
                .propose_add(long.to_vec(), alice.signer.clone(), key_package)
                .await
                .expect("stored proposal");
            alice
                .engine
                .propose_self_update(short.to_vec(), alice.signer.clone(), None, None)
                .await
                .expect("own leaf node");
            alice
                .engine
                .create_message(other.clone(), alice.signer.clone(), b"hello".to_vec(), None)
                .await
                .expect("message");

            let rows = alice.engine.db().expect("engine is open").rows_with_group_column();
            // The key shapes that are not label + ID alone have to be among
            // what is checked.
            for label in ["QueuedProposal", "ProposalQueueRefs", "EpochKeyPairs", "OwnLeafNodes"] {
                assert!(
                    rows.iter().any(|(key, _)| key.starts_with(label.as_bytes())),
                    "no {label} row to check"
                );
            }

            let groups = [short, long, other.as_slice()];
            for (key, column) in &rows {
                let claimed: Vec<&[u8]> =
                    groups.iter().copied().filter(|id| key_belongs_to_group(key, id)).collect();
                let shown = String::from_utf8_lossy(key);
                match column {
                    None => assert!(
                        claimed.is_empty() && is_global_key(key),
                        "a global row claimed by a group, or a group row with no column: {shown}"
                    ),
                    Some(id) => assert_eq!(claimed, [id.as_slice()], "{shown}"),
                }
            }
        });
    }

    /// One client: its own engine on its own ephemeral database, and its
    /// signing identity.
    struct Party {
        engine: MlsEngine,
        name: &'static str,
        signer: Vec<u8>,
        public_key: Vec<u8>,
    }

    impl Party {
        async fn new(name: &'static str) -> Self {
            let engine = MlsEngine::create(":memory:".to_string(), vec![0x5a; 32])
                .await
                .expect("engine opens");
            let keys = MlsSignatureKeyPair::generate(SUITE).expect("signature key pair");
            let signer = serialize_signer(SUITE, keys.private_key(), keys.public_key())
                .expect("serialized signer");
            Self { engine, name, signer, public_key: keys.public_key() }
        }

        async fn create_group(&self, group_id: Option<&[u8]>) -> Result<Vec<u8>, String> {
            self.engine
                .create_group(
                    MlsGroupConfig::default_config(SUITE),
                    self.signer.clone(),
                    self.name.as_bytes().to_vec(),
                    self.public_key.clone(),
                    group_id.map(<[u8]>::to_vec),
                    None,
                )
                .await
                .map(|created| created.group_id)
        }

        async fn create_group_with_builder(&self, group_id: &[u8]) -> Result<Vec<u8>, String> {
            self.engine
                .create_group_with_builder(
                    MlsGroupConfig::default_config(SUITE),
                    self.signer.clone(),
                    self.name.as_bytes().to_vec(),
                    self.public_key.clone(),
                    Some(group_id.to_vec()),
                    None,
                    None,
                    None,
                    None,
                    None,
                )
                .await
                .map(|created| created.group_id)
        }

        async fn key_package(&self) -> Vec<u8> {
            self.engine
                .create_key_package(
                    SUITE,
                    self.signer.clone(),
                    self.name.as_bytes().to_vec(),
                    self.public_key.clone(),
                    None,
                )
                .await
                .expect("key package")
                .key_package_bytes
        }

        /// Adds `invitee` to `group_id` and returns the Welcome.
        async fn invite(&self, group_id: &[u8], invitee: &Party) -> Vec<u8> {
            let key_package = invitee.key_package().await;
            self.engine
                .add_members(group_id.to_vec(), self.signer.clone(), vec![key_package])
                .await
                .expect("member is added")
                .welcome
        }

        async fn join(&self, welcome: &[u8]) -> Result<Vec<u8>, String> {
            self.engine
                .join_group_from_welcome(
                    MlsGroupConfig::default_config(SUITE),
                    welcome.to_vec(),
                    None,
                    self.signer.clone(),
                )
                .await
                .map(|joined| joined.group_id)
        }

        async fn join_with_options(&self, welcome: &[u8]) -> Result<Vec<u8>, String> {
            self.engine
                .join_group_from_welcome_with_options(
                    MlsGroupConfig::default_config(SUITE),
                    welcome.to_vec(),
                    None,
                    self.signer.clone(),
                    false,
                )
                .await
                .map(|joined| joined.group_id)
        }

        /// The members of `group_id` as this client's engine has it stored.
        async fn members(&self, group_id: &[u8]) -> Vec<String> {
            self.engine
                .group_members(group_id.to_vec())
                .await
                .expect("group loads")
                .into_iter()
                .map(|member| {
                    let credential = Credential::tls_deserialize_exact_bytes(&member.credential)
                        .expect("credential decodes");
                    let basic = BasicCredential::try_from(credential).expect("basic credential");
                    String::from_utf8_lossy(basic.identity()).into_owned()
                })
                .collect()
        }

        async fn epoch(&self, group_id: &[u8]) -> Result<u64, String> {
            self.engine.group_epoch(group_id.to_vec()).await
        }

        /// Joins the group of `group_info` by an external commit, through
        /// the first API or the second.
        async fn join_externally(
            &self,
            v2: bool,
            group_info: &[u8],
            tree: &[u8],
            replace: Option<bool>,
        ) -> Result<ExternalJoinResult, String> {
            let config = MlsGroupConfig::default_config(SUITE);
            let identity = self.name.as_bytes().to_vec();
            if v2 {
                self.engine
                    .join_group_external_commit_v2(
                        config,
                        group_info.to_vec(),
                        Some(tree.to_vec()),
                        self.signer.clone(),
                        identity,
                        self.public_key.clone(),
                        None,
                        false,
                        None,
                        replace,
                    )
                    .await
            } else {
                self.engine
                    .join_group_external_commit(
                        config,
                        group_info.to_vec(),
                        Some(tree.to_vec()),
                        self.signer.clone(),
                        identity,
                        self.public_key.clone(),
                        None,
                        replace,
                    )
                    .await
            }
        }

        async fn pending_proposals(&self, group_id: &[u8]) -> usize {
            self.engine
                .group_pending_proposals(group_id.to_vec())
                .await
                .expect("group loads")
                .len()
        }
    }

    /// The key of `group_id`'s entry under `label`, as this provider writes a
    /// plain group key: the label, the ID as serde_json writes it, `rest`,
    /// and the storage version.
    fn group_key(label: &[u8], group_id: &[u8], rest: &[u8]) -> Vec<u8> {
        let id = serde_json::to_vec(&GroupId::from_slice(group_id)).expect("group ID");
        [label, &id, rest, &openmls_traits::storage::CURRENT_VERSION.to_be_bytes()].concat()
    }

    /// Stores `rows` as the engine stores `group_id`'s: on the host, filed
    /// under that group's column.
    async fn store_rows(party: &Party, group_id: &[u8], rows: Vec<(Vec<u8>, Vec<u8>)>) {
        party
            .engine
            .db()
            .expect("engine is open")
            .save_updates(
                crate::encrypted_db::StorageUpdates { upserts: rows, deletes: Vec::new() },
                Some(group_id),
            )
            .await
            .expect("rows are stored");
    }

    /// Stores rows of `group_id` that OpenMLS's own `delete` does not know
    /// of, shaped as a group's leftovers are: the epoch key pairs of an epoch
    /// long gone, and a queued proposal no queue refers to. Returns their
    /// keys.
    async fn plant_leftovers(party: &Party, group_id: &[u8]) -> Vec<Vec<u8>> {
        let id = GroupId::from_slice(group_id);
        let in_pair = serde_json::to_vec(&serde_json::to_value(&id).expect("group ID"))
            .expect("group ID");
        let version = openmls_traits::storage::CURRENT_VERSION.to_be_bytes();
        let mut queued = b"QueuedProposal[".to_vec();
        queued.extend(&in_pair);
        queued.extend(b",\"leftover\"]");
        queued.extend(version);
        let keys = vec![group_key(b"EpochKeyPairs", group_id, b"[7,3]"), queued];
        store_rows(party, group_id, keys.iter().map(|key| (key.clone(), b"leftover".to_vec())).collect())
            .await;
        keys
    }

    /// Every key `party` stores, whatever group it is filed under: on the
    /// host the whole table, read past the group column; on the Web every
    /// row, which is what any load reads there.
    async fn all_keys(party: &Party) -> Vec<Vec<u8>> {
        let db = party.engine.db().expect("engine is open");
        #[cfg(not(target_arch = "wasm32"))]
        let rows: Vec<Vec<u8>> = db.rows_with_group_column().into_iter().map(|(key, _)| key).collect();
        #[cfg(target_arch = "wasm32")]
        let rows: Vec<Vec<u8>> = db
            .load_for_group(b"")
            .await
            .expect("rows load")
            .into_iter()
            .map(|(key, _)| key)
            .collect();
        rows
    }

    /// How many epoch key pair entries `party` stores for `group_id`, told
    /// apart by their keys, as the Web build tells them apart.
    async fn epoch_key_pair_rows(party: &Party, group_id: &[u8]) -> usize {
        all_keys(party)
            .await
            .iter()
            .filter(|key| {
                key.starts_with(b"EpochKeyPairs")
                    && crate::snapshot_storage::key_belongs_to_group(key, group_id)
            })
            .count()
    }

    /// The refusal a stored group ID has to produce.
    fn assert_refused(result: Result<Vec<u8>, String>, operation: &str) {
        match result {
            Ok(_) => panic!("{operation} went through over the stored group"),
            Err(error) => assert!(
                error.contains("already exists") && error.contains("deleteGroup"),
                "{operation} failed, but not with the refusal: {error}"
            ),
        }
    }

    /// RFC 9420 §12.4.3.1: a joiner must "verify that the group_id is unique
    /// among the groups that the client is currently participating in", and
    /// OpenMLS checks it against storage. Anyone who can hand Bob a Welcome —
    /// a delivery service, anyone holding one of his key packages — could
    /// otherwise put a group of their own under the ID of one he is in.
    async fn welcome_into_a_stored_group_id() {
        let alice = Party::new("alice").await;
        let bob = Party::new("bob").await;
        let mallory = Party::new("mallory").await;
        let group_id: &[u8] = b"team-chat";

        alice.create_group(Some(group_id)).await.expect("alice's group");
        let welcome = alice.invite(group_id, &bob).await;
        bob.join(&welcome).await.expect("bob joins alice's group");

        mallory.create_group(Some(group_id)).await.expect("mallory's group under the same ID");
        let impostor = mallory.invite(group_id, &bob).await;

        let joined = bob.join(&impostor).await;
        if joined.is_ok() {
            panic!(
                "joinGroupFromWelcome replaced the stored group; its members are now {:?}",
                bob.members(group_id).await
            );
        }
        assert_refused(joined, "joinGroupFromWelcome");
        assert_refused(bob.join_with_options(&impostor).await, "joinGroupFromWelcomeWithOptions");
        assert_eq!(bob.members(group_id).await, ["alice", "bob"]);

        // The refusals wrote nothing — the key package the Welcome is
        // addressed to included — so once Bob gives up his copy of the
        // group, the same Welcome goes through.
        bob.engine.delete_group(group_id.to_vec()).await.expect("group is deleted");
        bob.join(&impostor).await.expect("the Welcome is accepted once the ID is free");
        assert_eq!(bob.members(group_id).await, ["mallory", "bob"]);
    }

    /// The creating side of the same check: OpenMLS refuses to build a group
    /// under an ID it already stores.
    async fn creating_under_a_stored_id() {
        let alice = Party::new("alice").await;
        let bob = Party::new("bob").await;
        let group_id: &[u8] = b"team-chat";

        alice.create_group(Some(group_id)).await.expect("first group");
        alice.invite(group_id, &bob).await;

        let created = alice.create_group(Some(group_id)).await;
        if created.is_ok() {
            panic!(
                "createGroup replaced the stored group; its members are now {:?}",
                alice.members(group_id).await
            );
        }
        assert_refused(created, "createGroup");
        assert_refused(alice.create_group_with_builder(group_id).await, "createGroupWithBuilder");
        assert_eq!(alice.members(group_id).await, ["alice", "bob"]);
        assert_eq!(alice.epoch(group_id).await, Ok(1));

        alice.engine.delete_group(group_id.to_vec()).await.expect("group is deleted");
        alice.create_group(Some(group_id)).await.expect("the ID is free again");
        assert_eq!(alice.members(group_id).await, ["alice"]);
    }

    /// `deleteGroup` removes one group. What OpenMLS leaves behind for the
    /// purge is found by the group's ID, and every other group keeps all of
    /// its rows — including a group whose ID merely starts with the deleted
    /// one's, and the other way round.
    async fn deleting_leaves_the_other_groups() {
        let alice = Party::new("alice").await;
        let bob = Party::new("bob").await;
        let carol = Party::new("carol").await;
        let short: &[u8] = b"group";
        let long: &[u8] = b"group-2";

        alice.create_group(Some(short)).await.expect("short ID");
        alice.create_group(Some(long)).await.expect("long ID");
        let other = alice.create_group(None).await.expect("random ID");

        // More than a fresh group's rows: a second epoch and member, and a
        // stored proposal, whose key is the group ID *and* the proposal ref.
        alice.invite(long, &bob).await;
        let key_package = carol.key_package().await;
        alice
            .engine
            .propose_add(long.to_vec(), alice.signer.clone(), key_package)
            .await
            .expect("proposal is stored");
        // And rows OpenMLS's own delete does not know of, for the group that
        // is deleted and for the one whose ID extends it: only the purge
        // removes the first, and it has to keep the second.
        plant_leftovers(&alice, short).await;
        let long_leftovers = plant_leftovers(&alice, long).await;

        alice.engine.delete_group(short.to_vec()).await.expect("short ID is deleted");
        let keys = all_keys(&alice).await;
        assert!(
            !keys.iter().any(|key| crate::snapshot_storage::key_belongs_to_group(key, short)),
            "a row of the deleted group was left"
        );
        for key in &long_leftovers {
            assert!(keys.contains(key), "a row of the group whose ID extends it went");
        }
        assert!(alice.epoch(short).await.is_err(), "the deleted group is gone");
        assert_eq!(alice.epoch(long).await, Ok(1), "a group whose ID extends the deleted one's");
        assert_eq!(alice.members(long).await, ["alice", "bob"]);
        let pending = alice
            .engine
            .group_pending_proposals(long.to_vec())
            .await
            .expect("proposals load");
        assert_eq!(pending.len(), 1, "the stored proposal survives");
        assert_eq!(alice.epoch(&other).await, Ok(0), "an unrelated group");

        alice.create_group(Some(short)).await.expect("short ID again");
        alice.engine.delete_group(long.to_vec()).await.expect("long ID is deleted");
        assert!(alice.epoch(long).await.is_err(), "the deleted group is gone");
        assert_eq!(alice.members(short).await, ["alice"], "a group whose ID the deleted one's extends");
        assert_eq!(alice.epoch(&other).await, Ok(0), "an unrelated group");
    }

    /// An external join is how a client rejoins a group whose state it lost
    /// track of, and OpenMLS does not check its group ID against storage. So
    /// a group stored under that ID is refused, with nothing written, unless
    /// the caller asks for it to be replaced, and then it is replaced whole.
    /// On the global scope alone the join kept the old group's queued
    /// proposal and epoch key pairs under the new group's ID, and the
    /// rejoined client's next commit carried a proposal the group had already
    /// applied ("Duplicate signature key in proposals and group").
    async fn external_join_into_a_stored_group_id() {
        for v2 in [false, true] {
            let alice = Party::new("alice").await;
            let bob = Party::new("bob").await;
            let carol = Party::new("carol").await;
            let group = alice.create_group(None).await.expect("alice's group");
            let welcome = alice.invite(&group, &bob).await;
            alice.engine.merge_pending_commit(group.clone()).await.expect("alice merges");
            bob.join(&welcome).await.expect("bob joins");

            // Bob stores a proposal and misses the commit that applies it.
            let proposal = alice
                .engine
                .propose_add(group.clone(), alice.signer.clone(), carol.key_package().await)
                .await
                .expect("alice proposes carol")
                .proposal_message;
            bob.engine
                .process_message(group.clone(), proposal)
                .await
                .expect("bob stores the proposal");
            alice
                .engine
                .commit_to_pending_proposals(group.clone(), alice.signer.clone())
                .await
                .expect("alice commits it");
            alice.engine.merge_pending_commit(group.clone()).await.expect("alice merges");
            let group_info = alice
                .engine
                .export_group_info(group.clone(), alice.signer.clone())
                .await
                .expect("group info");
            let tree = alice.engine.export_ratchet_tree(group.clone()).await.expect("tree");

            for replace in [None, Some(false)] {
                match bob.join_externally(v2, &group_info, &tree, replace).await {
                    Ok(_) => panic!("v2={v2}: the join replaced the stored group untold"),
                    Err(error) => assert!(
                        error.contains("already exists")
                            && error.contains("replaceStoredGroup")
                            && error.contains(&hex(&group)),
                        "v2={v2}: refused, but not with the refusal: {error}"
                    ),
                }
            }
            // A replacing join that fails keeps the stored group too: here on
            // a GroupInfo whose signature, its last byte, no longer verifies,
            // after the group ID has been read from it.
            let mut forged = group_info.clone();
            *forged.last_mut().expect("group info") ^= 0x01;
            match bob.join_externally(v2, &forged, &tree, Some(true)).await {
                Ok(_) => panic!("v2={v2}: a join on a forged GroupInfo"),
                Err(error) => assert!(
                    !error.contains("deserialize"),
                    "v2={v2}: failed before the stored group was read: {error}"
                ),
            }
            assert_eq!(bob.epoch(&group).await, Ok(1), "v2={v2}: nothing was written");
            assert_eq!(bob.members(&group).await, ["alice", "bob"]);
            assert_eq!(bob.pending_proposals(&group).await, 1);

            let joined = bob
                .join_externally(v2, &group_info, &tree, Some(true))
                .await
                .expect("bob rejoins, replacing what he stored");
            assert_eq!(joined.group_id, group);
            if !v2 {
                bob.engine.merge_pending_commit(group.clone()).await.expect("bob merges");
            }
            alice
                .engine
                .process_message(group.clone(), joined.commit)
                .await
                .expect("alice takes bob's commit");
            assert_eq!(alice.epoch(&group).await, bob.epoch(&group).await, "v2={v2}");
            assert_eq!(bob.pending_proposals(&group).await, 0, "v2={v2}: the old proposal went");
            assert_eq!(
                epoch_key_pair_rows(&bob, &group).await,
                1,
                "v2={v2}: only the new epoch's key pairs are left"
            );
            bob.engine
                .self_update(group.clone(), bob.signer.clone())
                .await
                .expect("bob commits again");

            // Entries under the ID that no group loads from are no stored
            // group: a join goes ahead without being told, and they go.
            let dave = Party::new("dave").await;
            let planted = plant_leftovers(&dave, &group).await;
            assert!(dave.epoch(&group).await.is_err(), "v2={v2}: no group loads");
            let group_info = alice
                .engine
                .export_group_info(group.clone(), alice.signer.clone())
                .await
                .expect("group info");
            let tree = alice.engine.export_ratchet_tree(group.clone()).await.expect("tree");
            dave.join_externally(v2, &group_info, &tree, None)
                .await
                .expect("dave joins, untold");
            let keys = all_keys(&dave).await;
            for key in &planted {
                assert!(!keys.contains(key), "v2={v2}: a leftover stayed");
            }
        }
    }

    /// A stored group that no longer loads cannot be checked, so an external
    /// join refuses it untold, saying so and naming `replaceStoredGroup`, and
    /// told, replaces it without loading it.
    async fn external_join_into_a_group_that_does_not_load() {
        let alice = Party::new("alice").await;
        let bob = Party::new("bob").await;
        let group = alice.create_group(None).await.expect("alice's group");
        let welcome = alice.invite(&group, &bob).await;
        alice.engine.merge_pending_commit(group.clone()).await.expect("alice merges");
        bob.join(&welcome).await.expect("bob joins");

        // Bob's copy of the group context no longer reads.
        let context = group_key(b"GroupContext", &group, b"");
        assert!(all_keys(&bob).await.contains(&context), "the group context's key");
        store_rows(&bob, &group, vec![(context, b"not a group context".to_vec())]).await;
        assert!(bob.epoch(&group).await.is_err(), "the group no longer loads");

        let group_info = alice
            .engine
            .export_group_info(group.clone(), alice.signer.clone())
            .await
            .expect("group info");
        let tree = alice.engine.export_ratchet_tree(group.clone()).await.expect("tree");
        match bob.join_externally(false, &group_info, &tree, None).await {
            Ok(_) => panic!("the join replaced a group it could not check"),
            Err(error) => assert!(
                error.contains("does not load")
                    && error.contains("replaceStoredGroup")
                    && error.contains(&hex(&group)),
                "refused, but not for that reason: {error}"
            ),
        }
        let joined = bob
            .join_externally(false, &group_info, &tree, Some(true))
            .await
            .expect("bob replaces it");
        bob.engine.merge_pending_commit(group.clone()).await.expect("bob merges");
        alice
            .engine
            .process_message(group.clone(), joined.commit)
            .await
            .expect("alice takes bob's commit");
        assert_eq!(bob.epoch(&group).await, alice.epoch(&group).await, "the group loads again");
    }

    /// `groupIds` lists what the engine stores, no more and no less, and
    /// agrees with the check `createGroup` and `joinGroupFromWelcome` make:
    /// every ID it lists loads and is refused as already in use, a group
    /// stays listed while inactive, and an ID drops out exactly when
    /// `deleteGroup` frees it.
    async fn group_ids_lists_the_stored_groups() {
        let alice = Party::new("alice").await;
        let bob = Party::new("bob").await;
        assert_eq!(alice.engine.group_ids().await, Ok(vec![]), "a fresh engine");

        let short: &[u8] = b"group";
        let long: &[u8] = b"group-2";
        alice.create_group(Some(short)).await.expect("short ID");
        alice.create_group(Some(long)).await.expect("long ID");
        let other = alice.create_group(None).await.expect("random ID");
        // Stored as well, and not groups: a key package and the signature
        // key every call above stored.
        alice.key_package().await;

        let mut stored = vec![short.to_vec(), long.to_vec(), other.clone()];
        stored.sort();
        assert_eq!(alice.engine.group_ids().await, Ok(stored.clone()));
        for id in &stored {
            assert!(alice.epoch(id).await.is_ok(), "a listed group loads");
            assert_refused(alice.create_group(Some(id)).await, "createGroup");
        }

        // The joiner lists a group it joined from a Welcome, and keeps it
        // listed once it has been removed — inactive, until deleted.
        let welcome = alice.invite(long, &bob).await;
        bob.join(&welcome).await.expect("bob joins");
        assert_eq!(bob.engine.group_ids().await, Ok(vec![long.to_vec()]));
        let removal = alice
            .engine
            .remove_members(long.to_vec(), alice.signer.clone(), vec![1])
            .await
            .expect("bob is removed")
            .commit;
        bob.engine
            .process_message(long.to_vec(), removal)
            .await
            .expect("bob processes his removal");
        assert_eq!(bob.engine.group_is_active(long.to_vec()).await, Ok(false));
        assert_eq!(bob.engine.group_ids().await, Ok(vec![long.to_vec()]), "an inactive group");
        let again = alice.invite(long, &bob).await;
        assert_refused(bob.join(&again).await, "joinGroupFromWelcome");

        bob.engine.delete_group(long.to_vec()).await.expect("bob deletes it");
        assert_eq!(bob.engine.group_ids().await, Ok(vec![]), "a deleted group");
        bob.join(&again).await.expect("the ID is free again");
        assert_eq!(bob.engine.group_ids().await, Ok(vec![long.to_vec()]));

        alice.engine.delete_group(short.to_vec()).await.expect("alice deletes one");
        stored.retain(|id| id != short);
        assert_eq!(alice.engine.group_ids().await, Ok(stored), "only the deleted one drops out");
    }
}

// MoBook isolated feasibility only. Test-only methods are not exported to Dart.
#[cfg(all(test, not(target_arch = "wasm32")))]
mod mobook_engine_journal_spike {
    use super::*;
    use crate::api::keys::{serialize_signer,MlsSignatureKeyPair};
    use futures::executor::block_on;
    const SUITE: MlsCiphersuite=MlsCiphersuite::Mls128DhkemX25519Aes128gcmSha256Ed25519;
    fn caps()->MlsCapabilities {MlsCapabilities{versions:vec![1],ciphersuites:vec![1],extensions:vec![],proposals:vec![],credentials:vec![1]}}
    impl MlsEngine {
        async fn mobook_send(&self, gid:Vec<u8>, signer:Vec<u8>, id:&str, body:Vec<u8>, fail:bool)->Result<Vec<u8>,String> {
            let session=self.load_for_group(&gid).await?;
            if let Some(bytes)=self.db()?.mobook_spike_journal_get(&gid,id,&body)? {return Ok(bytes);}
            let mut group=load_group(&gid,&session)?;
            let signer=signer_from_bytes(signer)?;
            let msg=group.create_message(&session,&signer,&body).map_err(|e|e.to_string())?;
            let bytes=msg.tls_serialize_detached().map_err(|e|e.to_string())?;
            let OpSession{locks:_locks,provider}=session;
            self.db()?.mobook_spike_commit(provider.into_storage().into_updates(),&gid,id,&body,&bytes,fail)?;
            Ok(bytes)
        }
    }
    impl MlsEngine {
        async fn mobook_receive(&self, gid:Vec<u8>, id:&str, wire:Vec<u8>, fail:bool)->Result<Vec<u8>,String> {
            let session=self.load_for_group(&gid).await?;
            let mut inbox_scope=b"mobook-inbox:".to_vec();inbox_scope.extend_from_slice(&gid);
            if let Some(plain)=self.db()?.mobook_spike_journal_get(&inbox_scope,id,&wire)? {return Ok(plain);}
            let mut group=load_group(&gid,&session)?;
            let msg=MlsMessageIn::tls_deserialize_exact_bytes(&wire).map_err(|e|e.to_string())?.try_into_protocol_message().map_err(|e|e.to_string())?;
            let processed=group.process_message(&session,msg).map_err(|e|e.to_string())?;
            let plain=match processed.into_content() {ProcessedMessageContent::ApplicationMessage(a)=>a.into_bytes(),_=>return Err("application-only-spike".into())};
            let OpSession{locks:_locks,provider}=session;
            // Snapshot rows stay under the MLS group. Inbox rows get their own namespace.
            self.db()?.mobook_spike_receive_commit(provider.into_storage().into_updates(),&gid,&inbox_scope,id,&wire,&plain,fail)?;
            Ok(plain)
        }
    }
    #[test]
    fn mobook_engine_real_mls_atomic_send_and_reopen_retry() {
        block_on(async {
            let path=std::env::temp_dir().join(format!("mobook_engine_journal_{}.db",std::process::id()));
            let _=std::fs::remove_file(&path);
            let a=MlsEngine::create(path.to_str().unwrap().into(),vec![0x5a;32]).await.unwrap();
            let b=MlsEngine::create(":memory:".into(),vec![0x6b;32]).await.unwrap();
            let ak=MlsSignatureKeyPair::generate(SUITE).unwrap();
            let bk=MlsSignatureKeyPair::generate(SUITE).unwrap();
            let a_signer=serialize_signer(SUITE,ak.private_key(),ak.public_key()).unwrap();
            let b_signer=serialize_signer(SUITE,bk.private_key(),bk.public_key()).unwrap();
            let gid=a.create_group_with_builder(MlsGroupConfig::default_config(SUITE),a_signer.clone(),b"alice".to_vec(),ak.public_key(),None,None,None,None,Some(caps()),None).await.unwrap().group_id;
            let kp=b.create_key_package_with_options(SUITE,b_signer.clone(),b"bob".to_vec(),bk.public_key(),KeyPackageOptions{lifetime_seconds:None,last_resort:false,capabilities:Some(caps()),leaf_node_extensions:None,key_package_extensions:None},None).await.unwrap().key_package_bytes;
            let w=a.add_members(gid.clone(),a_signer.clone(),vec![kp]).await.unwrap().welcome;
            b.join_group_from_welcome(MlsGroupConfig::default_config(SUITE),w,None,b_signer).await.unwrap();
            let before=a.db().unwrap().load_for_group(&gid).await.unwrap();
            assert!(a.mobook_send(gid.clone(),a_signer.clone(),"one",b"hello".to_vec(),true).await.is_err());
            let mut after=a.db().unwrap().load_for_group(&gid).await.unwrap();
            let mut before=before;before.sort();after.sort();assert_eq!(before,after);
            let ciphertext=a.mobook_send(gid.clone(),a_signer.clone(),"one",b"hello".to_vec(),false).await.unwrap();
            a.close().await.unwrap();drop(a);
            let a=MlsEngine::create(path.to_str().unwrap().into(),vec![0x5a;32]).await.unwrap();
            assert_eq!(a.mobook_send(gid.clone(),a_signer.clone(),"one",b"hello".to_vec(),false).await.unwrap(),ciphertext);
            assert!(a.mobook_send(gid.clone(),a_signer.clone(),"one",b"changed".to_vec(),false).await.is_err());
            let mut before=b.db().unwrap().load_for_group(&gid).await.unwrap();
            assert!(b.mobook_receive(gid.clone(),"incoming-one",ciphertext.clone(),true).await.is_err());
            let mut after=b.db().unwrap().load_for_group(&gid).await.unwrap();before.sort();after.sort();assert_eq!(before,after);
            assert_eq!(b.mobook_receive(gid.clone(),"incoming-one",ciphertext.clone(),false).await.unwrap(),b"hello");
            assert_eq!(b.mobook_receive(gid.clone(),"incoming-one",ciphertext.clone(),false).await.unwrap(),b"hello");
            assert!(b.mobook_receive(gid.clone(),"incoming-one",vec![1,2,3],false).await.is_err());
            assert!(b.process_message(gid.clone(),ciphertext).await.is_err());
            let next=a.mobook_send(gid.clone(),a_signer,"two",b"next".to_vec(),false).await.unwrap();
            assert_eq!(b.process_message(gid,next).await.unwrap().application_message.unwrap(),b"next");
            a.close().await.unwrap();b.close().await.unwrap();drop(a);drop(b);
            for suffix in ["",".lock","-journal"] {let _=std::fs::remove_file(format!("{}{suffix}",path.display()));}
        });
    }

    #[test]
    fn mobook_engine_crash_child() {
        let Ok(dir)=std::env::var("MOBOOK_CRASH_DIR") else {return;};
        block_on(async {
            let mode=std::env::var("MOBOOK_CRASH_MODE").unwrap();
            let gid=std::fs::read(format!("{dir}/gid")).unwrap();
            if mode=="send" {
                let a=MlsEngine::create(format!("{dir}/alice.db"),vec![0x5a;32]).await.unwrap();
                let signer=std::fs::read(format!("{dir}/signer")).unwrap();
                a.mobook_send(gid,signer,"crash-one",b"synthetic crash text".to_vec(),false).await.unwrap();
            } else {
                let b=MlsEngine::create(format!("{dir}/bob.db"),vec![0x6b;32]).await.unwrap();
                let wire=std::fs::read(format!("{dir}/wire")).unwrap();
                b.mobook_receive(gid,"crash-incoming",wire,false).await.unwrap();
            }
        });
        panic!("child must exit at injected boundary");
    }
    fn crash_child(dir:&std::path::Path,mode:&str,point:&str) {
        let result=std::process::Command::new(std::env::current_exe().unwrap())
            .args(["--exact","api::engine::mobook_engine_journal_spike::mobook_engine_crash_child","--nocapture"])
            .env("MOBOOK_CRASH_DIR",dir).env("MOBOOK_CRASH_MODE",mode).env("MOBOOK_CRASH_POINT",point)
            .output().unwrap();
        assert_eq!(result.status.code(),Some(if point=="before"{81}else{82}),"unexpected child failure: {}",String::from_utf8_lossy(&result.stderr));
    }
    #[test]
    fn mobook_engine_process_exit_send_receive_recovery() {
        block_on(async {
            let dir=std::env::temp_dir().join(format!("mobook_process_crash_{}",std::process::id()));
            let _=std::fs::remove_dir_all(&dir);std::fs::create_dir(&dir).unwrap();
            use std::os::unix::fs::PermissionsExt;
            std::fs::set_permissions(&dir,std::fs::Permissions::from_mode(0o700)).unwrap();
            let a=MlsEngine::create(dir.join("alice.db").to_str().unwrap().into(),vec![0x5a;32]).await.unwrap();
            let b=MlsEngine::create(dir.join("bob.db").to_str().unwrap().into(),vec![0x6b;32]).await.unwrap();
            let ak=MlsSignatureKeyPair::generate(SUITE).unwrap();
            let bk=MlsSignatureKeyPair::generate(SUITE).unwrap();
            let a_signer=serialize_signer(SUITE,ak.private_key(),ak.public_key()).unwrap();
            let b_signer=serialize_signer(SUITE,bk.private_key(),bk.public_key()).unwrap();
            let gid=a.create_group_with_builder(MlsGroupConfig::default_config(SUITE),a_signer.clone(),b"alice".to_vec(),ak.public_key(),None,None,None,None,Some(caps()),None).await.unwrap().group_id;
            let kp=b.create_key_package_with_options(SUITE,b_signer.clone(),b"bob".to_vec(),bk.public_key(),KeyPackageOptions{lifetime_seconds:None,last_resort:false,capabilities:Some(caps()),leaf_node_extensions:None,key_package_extensions:None},None).await.unwrap().key_package_bytes;
            let w=a.add_members(gid.clone(),a_signer.clone(),vec![kp]).await.unwrap().welcome;
            b.join_group_from_welcome(MlsGroupConfig::default_config(SUITE),w,None,b_signer).await.unwrap();

            std::fs::write(dir.join("gid"),&gid).unwrap();
            std::fs::write(dir.join("signer"),&a_signer).unwrap();
            let mut before=a.db().unwrap().load_for_group(&gid).await.unwrap();before.sort();
            a.close().await.unwrap();drop(a);
            crash_child(&dir,"send","before");
            let a=MlsEngine::create(dir.join("alice.db").to_str().unwrap().into(),vec![0x5a;32]).await.unwrap();
            let mut after=a.db().unwrap().load_for_group(&gid).await.unwrap();after.sort();assert_eq!(before,after);
            assert_eq!(a.db().unwrap().mobook_spike_journal_get(&gid,"crash-one",b"synthetic crash text").unwrap(),None);
            a.close().await.unwrap();drop(a);
            crash_child(&dir,"send","after");
            let a=MlsEngine::create(dir.join("alice.db").to_str().unwrap().into(),vec![0x5a;32]).await.unwrap();
            let wire=a.db().unwrap().mobook_spike_journal_get(&gid,"crash-one",b"synthetic crash text").unwrap().unwrap();
            assert_eq!(a.mobook_send(gid.clone(),a_signer.clone(),"crash-one",b"synthetic crash text".to_vec(),false).await.unwrap(),wire);
            std::fs::write(dir.join("wire"),&wire).unwrap();
            let mut before=b.db().unwrap().load_for_group(&gid).await.unwrap();before.sort();
            b.close().await.unwrap();drop(b);
            crash_child(&dir,"receive","before");
            let b=MlsEngine::create(dir.join("bob.db").to_str().unwrap().into(),vec![0x6b;32]).await.unwrap();
            let mut after=b.db().unwrap().load_for_group(&gid).await.unwrap();after.sort();assert_eq!(before,after);
            let mut scope=b"mobook-inbox:".to_vec();scope.extend_from_slice(&gid);
            assert_eq!(b.db().unwrap().mobook_spike_journal_get(&scope,"crash-incoming",&wire).unwrap(),None);
            b.close().await.unwrap();drop(b);
            crash_child(&dir,"receive","after");
            let b=MlsEngine::create(dir.join("bob.db").to_str().unwrap().into(),vec![0x6b;32]).await.unwrap();
            assert_eq!(b.mobook_receive(gid.clone(),"crash-incoming",wire.clone(),false).await.unwrap(),b"synthetic crash text");
            assert!(b.process_message(gid.clone(),wire).await.is_err());
            let next=a.mobook_send(gid.clone(),a_signer,"crash-two",b"next".to_vec(),false).await.unwrap();
            assert_eq!(b.mobook_receive(gid,"incoming-two",next,false).await.unwrap(),b"next");
            a.close().await.unwrap();b.close().await.unwrap();drop(a);drop(b);
            std::fs::remove_dir_all(dir).unwrap();
        });
    }
}

#[cfg(all(feature = "mobook-journal", not(target_arch = "wasm32")))]
mod mobook_private;
#[cfg(all(feature = "mobook-journal", not(target_arch = "wasm32")))]
mod mobook_bridge;
#[cfg(all(feature = "mobook-journal", not(target_arch = "wasm32")))]
mod mobook_roster;
